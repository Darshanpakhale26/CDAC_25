#include<iostream>
using namespace std;
void acceptData(int *arr, int size){
    for(int i=0; i<size; i++){
        cout<<"Enter the element: "<<endl;
        cin>>arr[i];
    }
}

void displayData(int *arr,int size){
    for(int i=0;i<size;i++){
         cout<<arr[i]<<" "<<endl;
    }
}

int findmax(int *arr,int size){
      int max=arr[0];
      for(int i=0;i<size;i++){
          if(max<arr[i]){
              max=arr[i];
             
          }
      }
      return max;
}
int findmin(int *arr,int size){
    int min=arr[0];
    for(int i=0;i<size;i++){
        if(min>arr[i]){
            min=arr[i];        
        }
    }
    return min;
}
int sum(int *arr,int size){
  int sum = 0;
  for(int i=0; i<size; i++){
    sum = sum + arr[i];
  }
  return sum;
}
void search(int *arr,int size,int target){
   bool ispresent=0;
   for(int i = 0; i<size; i++){
     if(arr[i]== target){
         ispresent=1;
     }
   }
     
   
   if(ispresent==1){
      cout<<"Element is present"<<endl;
   }else{
     cout<<"Element not present" <<endl;
   }

   
}
int average(int *arr,int size){
    int sum=0;
    int count=0;
    for(int i=0;i<size;i++){
        if(arr[i]%6==0){
          sum=sum+arr[i];
          count++;
        }
    }
    return sum/count;
}
void divisor(int *arr,int size, int div){
     for(int i=0;i<size;i++){
         if(div%arr[i]==0){
            cout<<arr[i]<<" "<<endl;
         }
       
        
     } 
}

int main(){
     const int size = 5;
     int *arr;
     arr=new int[size];
     acceptData(arr,size);
     displayData(arr,size);
     
     int n;
     do{
        cout<<"1. Find Maximum: " <<endl;
        cout<<"2. Find Minimum: " <<endl;
        cout<<"3. Addition of numbers: " <<endl;
        cout<<"4. Search a element: " <<endl;
        cout<<"5. Divisor: " <<endl;
        cout<<"6. Average: " <<endl;
        cout<<"Enter your Choice"<<endl;
        cin>>n;
        int max,min,add,div,avg;
        switch(n){
       case 1:
          max = findmax(arr,size);
          cout<<"Maximum Element: "<<max<<endl;
          break;
       case 2:
          min = findmin(arr,size);
          cout<<"Minimum Element: "<<min<<endl;
          break;
       case 3:
          add = sum(arr,size);
          cout<<"Addition of Elements: "<<add<<endl;
          break;
       case 4:
          int target;
          cout<<"Enter the target element: "<<endl;
          cin>>target;
          search(arr,size,target);
          break;
       case 5:
          div;
          cout<<"Enter the element: "<<endl;
          cin>>div;
          divisor(arr,size,div);
          break;
       case 6:
          avg = average(arr,size);
          cout<<"Average: "<<avg<<endl;
          break;
       default:
          cout<<"Please enter the valid choice"<<endl;
     }
   }while(n!=0);
     
     delete[] arr;
     return 0;
     
     
}
