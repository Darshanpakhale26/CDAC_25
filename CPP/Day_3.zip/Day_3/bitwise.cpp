#include<iostream>
using namespace std;

int compress(int dd,int mm, int yy){
           int date=0;
           date=date|yy;
           date=date<<4;
           date=date|mm;
           date=date<<5;
           date=date|dd;
           return date;
           
           /*int a=dd<<5;
           int b=mm<<4;
           int c=yy<<11;
           int result=a | b | c;
           return result;
           */
}

void decompress(int date){
           int dd=date&31;
           date=date>>5;
           int mm=date&15;
           date=date>>4;
           int yy=date&2025;
 
           cout<< dd << "/" << mm << "/" << yy<< endl; 
}

int main() {
   int dd, mm, yy;
   cout<<"Enter the date: "<<endl;
   cin>>dd;
   cout<<"Enter the month: "<<endl;
   cin>>mm;
   cout<<"Enter the year: "<<endl;
   cin>>yy;
   
   int res = compress(dd,mm,yy);
   cout<<res<<endl;
   decompress(res);
   return 0;
}
