// Account.cpp
#include "Account.h"
#include <iostream>

// Constructor to initialize an account object
Account::Account(int accountNumber, const std::string& name, const std::string& accountType, double balance)
    : m_accountNumber(accountNumber), m_name(name), m_accountType(accountType), m_balance(balance) {}

// Getter methods
int Account::getAccountNumber() const {
    return m_accountNumber;
}

const std::string& Account::getName() const {
    return m_name;
}

const std::string& Account::getAccountType() const {
    return m_accountType;
}

double Account::getBalance() const {
    return m_balance;
}

// Display method to print account details
void Account::display() const {
    std::cout << "------------------------------------------\n";
    std::cout << "Account Number: " << m_accountNumber << "\n";
    std::cout << "Name: " << m_name << "\n";
    std::cout << "Account Type: " << m_accountType << "\n";
    std::cout << "Balance: $" << m_balance << "\n";
    std::cout << "------------------------------------------\n";
}

