// Student.cpp
#include "Student.h"
#include <iostream>

// Constructor to initialize student details
Student::Student(int id, const std::string& name, const std::string& course, double m1, double m2, double m3)
    : m_id(id), m_name(name), m_course(course), m_m1(m1), m_m2(m2), m_m3(m3) {}

// Getter methods
int Student::getId() const {
    return m_id;
}

const std::string& Student::getName() const {
    return m_name;
}

const std::string& Student::getCourse() const {
    return m_course;
}

double Student::getM1() const {
    return m_m1;
}

double Student::getM2() const {
    return m_m2;
}

double Student::getM3() const {
    return m_m3;
}

// Setter methods
void Student::setM1(double m1) {
    m_m1 = m1;
}

void Student::setM2(double m2) {
    m_m2 = m2;
}

void Student::setM3(double m3) {
    m_m3 = m3;
}

// Display method to print student information
void Student::display() const {
    std::cout << "------------------------------------------\n";
    std::cout << "ID: " << m_id << "\n";
    std::cout << "Name: " << m_name << "\n";
    std::cout << "Course: " << m_course << "\n";
    std::cout << "Marks (M1, M2, M3): " << m_m1 << ", " << m_m2 << ", " << m_m3 << "\n";
    std::cout << "------------------------------------------\n";
}

