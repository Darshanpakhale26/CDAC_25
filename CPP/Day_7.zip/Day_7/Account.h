// Account.h
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

class Account {
private:
    int m_accountNumber;
    std::string m_name;
    std::string m_accountType;
    double m_balance;

public:
    // Constructor
    Account(int accountNumber, const std::string& name, const std::string& accountType, double balance);

    // Getters
    int getAccountNumber() const;
    const std::string& getName() const;
    const std::string& getAccountType() const;
    double getBalance() const;

    // Display account information
    void display() const;
};

#endif // ACCOUNT_H

