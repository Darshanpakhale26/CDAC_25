// TestStudent.cpp
#include <iostream>
#include "StudentService.h"

int main() {
    int choice;
    do {
        // Display the menu
        std::cout << "\n--- Student Management ---\n";
        std::cout << "1. Add new Student\n";
        std::cout << "2. Display All Student\n";
        std::cout << "3. Search by Id\n";
        std::cout << "4. Search by Name\n";
        std::cout << "5. Sort Students by m1 marks\n";
        std::cout << "6. Display All MSC Student\n";
        std::cout << "7. Display All PHD Student\n";
        std::cout << "8. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                // Add a new student
                StudentService::addStudent();
                break;
            }
            case 2: {
                // Display all students
                StudentService::displayAllStudents();
                break;
            }
            case 3: {
                // Search by ID
                int id;
                std::cout << "Enter student ID to search: ";
                std::cin >> id;
                StudentService::searchById(id);
                break;
            }
            case 4: {
                // Search by name
                std::string name;
                std::cout << "Enter student name to search: ";
                std::cin >> name;
                StudentService::searchByName(name);
                break;
            }
            case 5: {
                // Sort students by m1 marks
                StudentService::sortStudentsByM1();
                StudentService::displayAllStudents(); // Display sorted list
                break;
            }
            case 6: {
                // Display all MSC students
                StudentService::displayMSCStudents();
                break;
            }
            case 7: {
                // Display all PHD students
                StudentService::displayPHDStudents();
                break;
            }
            case 8: {
                // Exit the program
                std::cout << "Exiting program. Goodbye!\n";
                break;
            }
            default: {
                std::cout << "Invalid choice. Please try again.\n";
                break;
            }
        }
    } while (choice != 8);

    return 0;
}

