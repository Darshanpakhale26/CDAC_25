// StudentService.cpp
#include "StudentService.h"
#include <iostream>
#include <algorithm>

// Static member initialization
std::vector<Student> StudentService::students;
int StudentService::nextId = 1;

// Function to add a new student
void StudentService::addStudent() {
    std::string name, course;
    double m1, m2, m3;

    std::cout << "Enter student name: ";
    std::cin >> name;
    std::cout << "Enter course (MSC/PHD): ";
    std::cin >> course;
    std::cout << "Enter marks for m1, m2, m3: ";
    std::cin >> m1 >> m2 >> m3;

    students.emplace_back(nextId++, name, course, m1, m2, m3);
    std::cout << "Student added successfully with ID: " << students.back().getId() << std::endl;
}

// Function to display all students
void StudentService::displayAllStudents() {
    if (students.empty()) {
        std::cout << "No students to display.\n";
        return;
    }
    std::cout << "\n--- All Students ---\n";
    for (const auto& student : students) {
        student.display();
    }
}

// Function to search for a student by ID
void StudentService::searchById(int id) {
    std::cout << "Searching for student with ID: " << id << std::endl;
    for (const auto& student : students) {
        if (student.getId() == id) {
            student.display();
            return;
        }
    }
    std::cout << "Student with ID " << id << " not found.\n";
}

// Function to search for students by name
void StudentService::searchByName(const std::string& name) {
    bool found = false;
    std::cout << "Searching for students with name: " << name << std::endl;
    for (const auto& student : students) {
        if (student.getName() == name) {
            student.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No students found with name " << name << ".\n";
    }
}

// Function to sort students by m1 marks
void StudentService::sortStudentsByM1() {
    std::sort(students.begin(), students.end(), [](const Student& a, const Student& b) {
        return a.getM1() < b.getM1();
    });
    std::cout << "Students sorted by M1 marks.\n";
}

// Function to display all MSC students
void StudentService::displayMSCStudents() {
    bool found = false;
    std::cout << "\n--- All MSC Students ---\n";
    for (const auto& student : students) {
        if (student.getCourse() == "MSC") {
            student.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No MSC students to display.\n";
    }
}

// Function to display all PHD students
void StudentService::displayPHDStudents() {
    bool found = false;
    std::cout << "\n--- All PHD Students ---\n";
    for (const auto& student : students) {
        if (student.getCourse() == "PHD") {
            student.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No PHD students to display.\n";
    }
}

