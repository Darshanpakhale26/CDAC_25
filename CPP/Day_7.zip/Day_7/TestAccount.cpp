// TestAccount.cpp
#include <iostream>
#include "AccountService.h"

int main() {
    int choice;
    do {
        // Display the menu
        std::cout << "\n--- Account Management ---\n";
        std::cout << "1. Add new account\n";
        std::cout << "3. Display All Accounts\n";
        std::cout << "4. Search by account number\n";
        std::cout << "5. Search by Name\n";
        std::cout << "6. Sort Accounts by balance\n";
        std::cout << "7. Display All Saving Account\n";
        std::cout << "8. Display All Current Account\n";
        std::cout << "9. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                // Add a new account
                AccountService::addAccount();
                break;
            }
            case 3: {
                // Display all accounts
                AccountService::displayAllAccounts();
                break;
            }
            case 4: {
                // Search by account number
                int accNum;
                std::cout << "Enter account number to search: ";
                std::cin >> accNum;
                AccountService::searchByAccountNumber(accNum);
                break;
            }
            case 5: {
                // Search by name
                std::string name;
                std::cout << "Enter account holder's name to search: ";
                std::cin >> name;
                AccountService::searchByName(name);
                break;
            }
            case 6: {
                // Sort accounts by balance
                AccountService::sortAccountsByBalance();
                AccountService::displayAllAccounts(); // Display sorted list
                break;
            }
            case 7: {
                // Display all Saving accounts
                AccountService::displaySavingAccounts();
                break;
            }
            case 8: {
                // Display all Current accounts
                AccountService::displayCurrentAccounts();
                break;
            }
            case 9: {
                // Exit the program
                std::cout << "Exiting program. Goodbye!\n";
                break;
            }
            default: {
                std::cout << "Invalid choice. Please try again.\n";
                break;
            }
        }
    } while (choice != 9);

    return 0;
}

