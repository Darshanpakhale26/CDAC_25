// AccountService.cpp
#include "AccountService.h"
#include <iostream>
#include <algorithm>

// Static member initialization
std::vector<Account> AccountService::s_accounts;
int AccountService::s_nextAccountNumber = 1001;

// Function to add a new account
void AccountService::addAccount() {
    std::string name, accountType;
    double balance;

    std::cout << "Enter account holder's name: ";
    std::cin >> name;
    std::cout << "Enter account type (Saving/Current): ";
    std::cin >> accountType;
    std::cout << "Enter initial balance: ";
    std::cin >> balance;

    // Create a new Account object and add it to the vector
    s_accounts.emplace_back(s_nextAccountNumber++, name, accountType, balance);
    std::cout << "Account added successfully with account number: " << s_accounts.back().getAccountNumber() << std::endl;
}

// Function to display all accounts
void AccountService::displayAllAccounts() {
    if (s_accounts.empty()) {
        std::cout << "No accounts to display.\n";
        return;
    }
    std::cout << "\n--- All Accounts ---\n";
    for (const auto& account : s_accounts) {
        account.display();
    }
}

// Function to search for an account by account number
void AccountService::searchByAccountNumber(int accountNumber) {
    std::cout << "Searching for account with number: " << accountNumber << std::endl;
    for (const auto& account : s_accounts) {
        if (account.getAccountNumber() == accountNumber) {
            account.display();
            return;
        }
    }
    std::cout << "Account with number " << accountNumber << " not found.\n";
}

// Function to search for accounts by name
void AccountService::searchByName(const std::string& name) {
    bool found = false;
    std::cout << "Searching for accounts with name: " << name << std::endl;
    for (const auto& account : s_accounts) {
        if (account.getName() == name) {
            account.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No accounts found with name " << name << ".\n";
    }
}

// Function to sort accounts by balance
void AccountService::sortAccountsByBalance() {
    std::sort(s_accounts.begin(), s_accounts.end(), [](const Account& a, const Account& b) {
        return a.getBalance() < b.getBalance();
    });
    std::cout << "Accounts sorted by balance.\n";
}

// Function to display all Saving accounts
void AccountService::displaySavingAccounts() {
    bool found = false;
    std::cout << "\n--- All Saving Accounts ---\n";
    for (const auto& account : s_accounts) {
        if (account.getAccountType() == "Saving") {
            account.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No Saving accounts to display.\n";
    }
}

// Function to display all Current accounts
void AccountService::displayCurrentAccounts() {
    bool found = false;
    std::cout << "\n--- All Current Accounts ---\n";
    for (const auto& account : s_accounts) {
        if (account.getAccountType() == "Current") {
            account.display();
            found = true;
        }
    }
    if (!found) {
        std::cout << "No Current accounts to display.\n";
    }
}

