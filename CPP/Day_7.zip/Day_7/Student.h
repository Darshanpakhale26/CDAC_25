// Student.h
#ifndef STUDENT_H
#define STUDENT_H

#include <string>

class Student {
private:
    int m_id;
    std::string m_name;
    std::string m_course;
    double m_m1;
    double m_m2;
    double m_m3;

public:
    // Constructor
    Student(int id, const std::string& name, const std::string& course, double m1, double m2, double m3);

    // Getters
    int getId() const;
    const std::string& getName() const;
    const std::string& getCourse() const;
    double getM1() const;
    double getM2() const;
    double getM3() const;

    // Setters
    void setM1(double m1);
    void setM2(double m2);
    void setM3(double m3);

    // Display student information
    void display() const;
};

#endif // STUDENT_H

