// StudentService.h
#ifndef STUDENT_SERVICE_H
#define STUDENT_SERVICE_H

#include "Student.h"
#include <vector>

class StudentService {
private:
    // Static member to store all student objects
    static std::vector<Student> students;
    static int nextId; // To automatically generate unique student IDs

public:
    // Static function to add a new student
    static void addStudent();

    // Static function to display all students
    static void displayAllStudents();

    // Static function to search for a student by ID
    static void searchById(int id);

    // Static function to search for students by name
    static void searchByName(const std::string& name);

    // Static function to sort students by m1 marks
    static void sortStudentsByM1();

    // Static function to display all MSC students
    static void displayMSCStudents();

    // Static function to display all PHD students
    static void displayPHDStudents();
};

#endif // STUDENT_SERVICE_H

