// AccountService.h
#ifndef ACCOUNT_SERVICE_H
#define ACCOUNT_SERVICE_H

#include "Account.h"
#include <vector>

class AccountService {
private:
    // Static member to store all account objects
    static std::vector<Account> s_accounts;
    // Static member to automatically generate unique account numbers
    static int s_nextAccountNumber;

public:
    // Static function to add a new account
    static void addAccount();

    // Static function to display all accounts
    static void displayAllAccounts();

    // Static function to search for an account by number
    static void searchByAccountNumber(int accountNumber);

    // Static function to search for accounts by name
    static void searchByName(const std::string& name);

    // Static function to sort accounts by balance
    static void sortAccountsByBalance();

    // Static function to display all Saving accounts
    static void displaySavingAccounts();

    // Static function to display all Current accounts
    static void displayCurrentAccounts();
};

#endif // ACCOUNT_SERVICE_H

