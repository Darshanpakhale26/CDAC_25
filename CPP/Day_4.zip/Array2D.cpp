// 1. Write a class Aarray2D to store all functions related to 2D array.
// refer the demo for 2D array
// make all functions within the class static
// Store the class in file Array2D.cpp, write another file TestArray2D.cpp
// store main function in this file.
// Write a menu driven program to do the following,
// result of every function should be displayed in main
// 1. add 2 matrices
// 2. transpose of matric
// 3. multiplication of 2 matrices
// 4. find sum of all values
// 5. find maximum number
// 6. find minimum number
// 7. find rowwise minimum
// 8. find rowwise maximum
// 9. find rowwise sum
// 10. find columnwise maximum
// 11. find columnwise minimum
// 12. find columnwise sum

#include <iostream>
using namespace std;

const int rows = 3;
const int cols = 3;

class Array2D
{
public:
    static void addMatrices(int a[rows][cols], int b[rows][cols], int result[rows][cols])
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                result[i][j] = a[i][j] + b[i][j];
            }
        }
    }
    static void transposeMatrix(int a[rows][cols], int result[cols][rows])
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                result[j][i] = a[i][j];
            }
        }
    }

    static void multiplyMatrices(int a[rows][cols], int b[cols][rows], int result[rows][rows])
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                result[i][j] = 0;
                for (int k = 0; k < cols; k++)
                {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
    }

    static int sumOfElements(int a[rows][cols])
    {
        int sum = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                sum += a[i][j];
            }
        }
        return sum;
    }

    static int findMaximum(int a[rows][cols])
    {
        int max = a[0][0];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (a[i][j] > max)
                {
                    max = a[i][j];
                }
            }
        }
        return max;
    }

    static int findMinimum(int a[rows][cols])
    {
        int min = a[0][0];
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (a[i][j] < min)
                {
                    min = a[i][j];
                }
            }
        }
        return min;
    }

    static void rowWiseMin(int a[rows][cols], int result[rows])
    {
        for (int i = 0; i < rows; i++)
        {
            result[i] = a[i][0];
            for (int j = 1; j < cols; j++)
            {
                if (a[i][j] < result[i])
                {
                    result[i] = a[i][j];
                }
            }
        }
    }

    static void rowWiseMax(int a[rows][cols], int result[rows])
    {
        for (int i = 0; i < rows; i++)
        {
            result[i] = a[i][0];
            for (int j = 1; j < cols; j++)
            {
                if (a[i][j] > result[i])
                {
                    result[i] = a[i][j];
                }
            }
        }
    }

    static void rowWiseSum(int a[rows][cols], int result[rows])
    {
        for (int i = 0; i < rows; i++)
        {
            result[i] = 0;
            for (int j = 0; j < cols; j++)
            {
                result[i] += a[i][j];
            }
        }
    }

    static void colWiseMax(int a[rows][cols], int result[cols])
    {
        for (int j = 0; j < cols; j++)
        {
            result[j] = a[0][j];
            for (int i = 1; i < rows; i++)
            {
                if (a[i][j] > result[j])
                {
                    result[j] = a[i][j];
                }
            }
        }
    }

    static void colWiseMin(int a[rows][cols], int result[cols])
    {
        for (int j = 0; j < cols; j++)
        {
            result[j] = a[0][j];
            for (int i = 1; i < rows; i++)
            {
                if (a[i][j] < result[j])
                {
                    result[j] = a[i][j];
                }
            }
        }
    }

    static void colWiseSum(int a[rows][cols], int result[cols])
    {
        for (int j = 0; j < cols; j++)
        {
            result[j] = 0;
            for (int i = 0; i < rows; i++)
            {
                result[j] += a[i][j];
            }
        }
    }
};