#include <iostream>
#include "Array2D.cpp"
using namespace std;

int main()
{
    int arr1[rows][cols] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int arr2[rows][cols] = {{11, 12, 13}, {14, 15, 16}, {17, 18, 19}};
    int result[rows][cols];
    int choice;

    do
    {
        cout << "\nMenu:\n";
        cout << "1. Add Matrices\n2. Transpose Matrix\n3. Multiply Matrices\n";
        cout << "4. Sum of Elements\n5. Find Maximum\n6. Find Minimum\n";
        cout << "7. Row-wise Minimum\n8. Row-wise Maximum\n9. Row-wise Sum\n";
        cout << "10. Column-wise Maximum\n11. Column-wise Minimum\n12. Column-wise Sum\n";
        cout << "0. Exit\nEnter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            Array2D::addMatrices(arr1, arr2, result);
            cout << "Result of Addition:\n";
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    cout << result[i][j] << " ";
                cout << endl;
            }
            break;

        case 2:
            Array2D::transposeMatrix(arr1, result);
            cout << "Transpose of Matrix:\n";
            for (int i = 0; i < cols; i++)
            {
                for (int j = 0; j < rows; j++)
                    cout << result[i][j] << " ";
                cout << endl;
            }
            break;

        case 3:
            Array2D::multiplyMatrices(arr1, arr2, result);
            cout << "Result of Multiplication:\n";
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    cout << result[i][j] << " ";
                cout << endl;
            }
            break;

        case 4:
            cout << "Sum of Elements: " << Array2D::sumOfElements(arr1) << endl;
            break;

        case 5:
            cout << "Maximum Element: " << Array2D::findMaximum(arr1) << endl;
            break;

        case 6:
            cout << "Minimum Element: " << Array2D::findMinimum(arr1) << endl;
            break;

        case 7:
        {
            int rowMin[rows];
            Array2D::rowWiseMin(arr1, rowMin);
            cout << "Row-wise Minimum: ";
            for (int i = 0; i < rows; i++)
                cout << rowMin[i] << " ";
            cout << endl;
            break;
        }

        case 8:
        {
            int rowMax[rows];
            Array2D::rowWiseMax(arr1, rowMax);
            cout << "Row-wise Maximum: ";
            for (int i = 0; i < rows; i++)
                cout << rowMax[i] << " ";
            cout << endl;
            break;
        }

        case 9:
        {
            int rowSum[rows];
            Array2D::rowWiseSum(arr1, rowSum);
            cout << "Row-wise Sum: ";
            for (int i = 0; i < rows; i++)
                cout << rowSum[i] << " ";
            cout << endl;
            break;
        }

        case 10:
        {
            int colMax[cols];
            Array2D::colWiseMax(arr1, colMax);
            cout << "Column-wise Maximum: ";
            for (int i = 0; i < cols; i++)
                cout << colMax[i] << " ";
            cout << endl;
            break;
        }

        case 11:
        {
            int colMin[cols];
            Array2D::colWiseMin(arr1, colMin);
            cout << "Column-wise Minimum: ";
            for (int i = 0; i < cols; i++)
                cout << colMin[i] << " ";
            cout << endl;
            break;
        }

        case 12:
        {
            int colSum[cols];
            Array2D::colWiseSum(arr1, colSum);
            cout << "Column-wise Sum: ";
            for (int i = 0; i < cols; i++)
                cout << colSum[i] << " ";
            cout << endl;
            break;
        }

        case 0:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);

    return 0;
}
