#include <iostream>
#include <string>
#include <iomanip> // For formatting output
#include <vector> 

using namespace std;


class Account {
protected:
    string fname;
    string lname;
    string mobile;
    string email;
    string account_id;
    double interest_rate;
    double minimum_balance;
    
    static int account_count;

    
    string generate_id() {
        
        string first_part = (fname.length() >= 3) ? fname.substr(0, 3) : fname;
        string last_part = (lname.length() >= 3) ? lname.substr(0, 3) : lname;

        
        string count_str = to_string(account_count);

     
        return first_part + last_part + count_str;
    }

public:
    
    Account(const string& first_name, const string& last_name, const string& mob, const string& mail)
        : fname(first_name), lname(last_name), mobile(mob), email(mail) {
        
        account_count++;
        
        account_id = generate_id();
    }


    virtual void display_info() const {
        cout << "--- Common Account Details ---\n";
        cout << "Account ID: " << account_id << "\n";
        cout << "Name: " << fname << " " << lname << "\n";
        cout << "Mobile: " << mobile << "\n";
        cout << "Email: " << email << "\n";
        cout << fixed << setprecision(2); 
        cout << "Interest Rate: " << interest_rate << "%\n";
        cout << "Minimum Balance: $" << minimum_balance << "\n";
    }

    
    virtual ~Account() {}
};


int Account::account_count = 0;


class SavingAccount : public Account {
private:
    string chequebook_number;

public:
    
    SavingAccount(const string& first_name, const string& last_name, const string& mob,
                  const string& mail, const string& cheque_num)
        : Account(first_name, last_name, mob, mail), chequebook_number(cheque_num) {
       
        interest_rate = 4.0;
        minimum_balance = 20000.0;
    }

    
    void display_info() const override {
        Account::display_info(); 
        cout << "--- Saving Account Specifics ---\n";
        cout << "Chequebook Number: " << chequebook_number << "\n";
    }
};


class CurrentAccount : public Account {
private:
    int transactions_per_day;

public:
  
    CurrentAccount(const string& first_name, const string& last_name, const string& mob,
                   const string& mail, int num_transactions)
        : Account(first_name, last_name, mob, mail), transactions_per_day(num_transactions) {

        interest_rate = 1.0;
        minimum_balance = 1000.0;
    }

   
    void display_info() const override {
        Account::display_info(); 
        cout << "--- Current Account Specifics ---\n";
        cout << "Number of Transactions/Day: " << transactions_per_day << "\n";
        cout << "(Note: This value can change based on average annual balance.)\n";
    }
};

int main() {
    cout << "Setting up bank accounts...\n";
    cout << "========================================\n";

    
    SavingAccount savings_account("Atharva", "Patil", "9876543210", "atharva.patil@gmail.com", "SB-12345");
    savings_account.display_info();

    cout << "\n\nCreating another account...\n";
    cout << "========================================\n";

    CurrentAccount current_account("Darshan", "Pakhale", "0123456789", "darshan.pakhale@gmail.com", 5);
    current_account.display_info();

    return 0;
}

