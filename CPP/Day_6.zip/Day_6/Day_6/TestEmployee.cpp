#include <iostream>
//#include "Employee.h"
//#include "SalariedEmp.h"
#include "ContractEmp.h"

int main() {
    // Corrected instantiation of an Employee object
    Employee ob(10, "Rajan", "Hr", "mgr");
    ob.display();

    // Corrected instantiation of a SalariedEmp object
    // Added semicolon at the end of the line
    SalariedEmp semp(10, "Rajan", "Hr", "mgr", 2345);
    semp.display();

    // Corrected instantiation of a pointer to a SalariedEmp object
    SalariedEmp *semp1 = new SalariedEmp(10, "Atharva", "admin", "CEO", 55555);
    semp1->display();
    delete semp1;

    // Corrected instantiation of a pointer to a SalariedEmp object using polymorphism
    Employee* emp1 = new SalariedEmp(11, "Ajay", "admin", "CEO", 55555);
    emp1->display();
    delete emp1;

    // Corrected instantiation of a ContractEmp object.
    // The conflicting variable 'ob' is renamed to 'ob2'.
    // The constructor call is corrected to have 5 arguments instead of 6.
    ContractEmp ob2(11, "Varsha", "HR", "Programmer", 2456);
    ob2.display();

    // Corrected instantiation of a pointer to a ContractEmp object.
    // The constructor call is corrected to have 5 arguments instead of 6.
    ContractEmp *cemp = new ContractEmp(12, "Sonali", "Admin", "mgr", 1443);
    cemp->display();
    delete cemp;

    // Corrected instantiation of a pointer to a ContractEmp object using polymorphism.
    // The constructor call is corrected to have 5 arguments instead of 6.
    Employee *emp2 = new ContractEmp(13, "Rama", "Admin", "mgr", 1678);
    emp2->display();
    delete emp2;

    return 0;
}
