#include <iostream>
#include <cstring> 
using namespace std;

class Student {
private:

    char student_id[20];
    char name[100];
    char address[256];
    double passing_percentage;
    int m1, m2, m3;
    char degree[50];

public:
    
    Student(const char* id, const char* student_name, const char* student_address,
            double pass_percent, int marks1, int marks2, int marks3, const char* student_degree)
        : passing_percentage(pass_percent), m1(marks1), m2(marks2), m3(marks3) {

        strcpy(student_id, id);
        strcpy(name, student_name);
        strcpy(address, student_address);
        strcpy(degree, student_degree);
    }

   
    virtual void display_info() const {
        cout << "--- Common Student Information ---\n";
        cout << "ID: " << student_id << "\n";
        cout << "Name: " << name << "\n";
        cout << "Address: " << address << "\n";
        cout << "Passing Percentage: " << passing_percentage << "%\n";
        cout << "Marks (M1, M2, M3): " << m1 << ", " << m2 << ", " << m3 << "\n";
        cout << "Degree: " << degree << "\n";
    }
};


class MScStudent : public Student {
private:
    int special_subject_marks;
    int language_marks;

public:
  
    MScStudent(const char* id, const char* student_name, const char* student_address,
               double pass_percent, int marks1, int marks2, int marks3,
               const char* student_degree, int special_marks, int lang_marks)
        : Student(id, student_name, student_address, pass_percent, marks1, marks2, marks3, student_degree),
          special_subject_marks(special_marks), language_marks(lang_marks) {}

    
    void display_info() const override {
        Student::display_info();
        cout << "--- MSc Student Details ---\n";
        cout << "Special Subject Marks: " << special_subject_marks << "\n";
        cout << "Language Marks: " << language_marks << "\n";
    }
};


class PhdStudent : public Student {
private:
    char thesis_name[256];
    int thesis_marks;

public:
    
    PhdStudent(const char* id, const char* student_name, const char* student_address,
               double pass_percent, int marks1, int marks2, int marks3,
               const char* student_degree, const char* thesis, int thesis_score)
        : Student(id, student_name, student_address, pass_percent, marks1, marks2, marks3, student_degree),
          thesis_marks(thesis_score) {
        strcpy(thesis_name, thesis);
    }

   
    void display_info() const override {
        Student::display_info(); 
        cout << "--- PhD Student Details ---\n";
        cout << "Thesis Name: " << thesis_name << "\n";
        cout << "Thesis Marks: " << thesis_marks << "\n";
    }
};

int main() {
    cout << "Testing MSc Student Class...\n";
    cout << "========================================\n";
    
    MScStudent msc_student("MS123", "Atharva", "Jalgaon", 85.5, 90, 88, 92,
                           "Master of Science", 95, 80);
    msc_student.display_info();

    cout << "\n\nTesting PhD Student Class...\n";
    cout << "========================================\n";
    
    PhdStudent phd_student("PHD456", "Darshan", "Dhule", 92.0, 95, 93, 91,
                           "Doctor of Philosophy", "Advanced Quantum Computing", 98);
    phd_student.display_info();

    return 0;
}

