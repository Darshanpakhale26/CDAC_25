#include "SalariedEmp.h"


class ContractEmp:public Employee{
   private:
      double sal;
      double bonus;
      
   public:
      ContractEmp();
      ContractEmp(int eno,const char* nm,const char *dt,const char* ds,double s);
      ~ContractEmp();
      void setSal(double s);
      void setBonus(double b);
      double getBonus();
      double getSal();
      void display();


};
