#include "ContractEmp.h"
#include<iostream>
using namespace std;

ContractEmp::ContractEmp():sal(0.0),bonus(0.0){
cout<<"in default constructor of SalariedEmp";
  //sal=0.0
  //bonus=0.0;
}

ContractEmp::ContractEmp(int eno,const char* nm,const char *dt,const char* ds,double s):Employee(eno,nm,dt,ds){
cout<<"in parametrised constructor of ContractEmp";
  sal=s;
  bonus=s*0.10;
}
ContractEmp::~ContractEmp(){
   cout<<"in contractemp destructor";
}

void ContractEmp::display(){
     Employee::display();
     cout<<"Salary: "<<sal;
     cout<<"bonus: " <<bonus<<endl;

}

