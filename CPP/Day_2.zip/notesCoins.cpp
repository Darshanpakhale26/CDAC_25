// accept amount from user and find the minimum number notes required to get the amount
// amount =512
// Notes: 2000,500,100,50,10,5,2,1
// 500-1 note
// 10  - 1 note
// 2-  1 coin
// amount = 20550
// 2000 – 10 note
// 500 – 1 note
// 50 - 1 note


#include <iostream>
using namespace std;

int main() {
    int amount;
    cout << "Enter amount: ";
    cin >> amount;

    if (amount >= 2000) {
        int n = amount / 2000;
        cout << "2000 - " << n << " note(s)" << endl;
        amount = amount % 2000;
    }

    if (amount >= 500) {
        int n = amount / 500;
        cout << "500 - " << n << " note(s)" << endl;
        amount = amount % 500;
    }

    if (amount >= 100) {
        int n = amount / 100;
        cout << "100 - " << n << " note(s)" << endl;
        amount = amount % 100;
    }

    if (amount >= 50) {
        int n = amount / 50;
        cout << "50 - " << n << " note(s)" << endl;
        amount = amount % 50;
    }

    if (amount >= 10) {
        int n = amount / 10;
        cout << "10 - " << n << " note(s)" << endl;
        amount = amount % 10;
    }

    if (amount >= 5) {
        int n = amount / 5;
        cout << "5 - " << n << " coin(s)" << endl;
        amount = amount % 5;
    }

    if (amount >= 2) {
        int n = amount / 2;
        cout << "2 - " << n << " coin(s)" << endl;
        amount = amount % 2;
    }

    if (amount >= 1) {
        int n = amount / 1;
        cout << "1 - " << n << " coin(s)" << endl;
        amount = amount % 1;
    }

    return 0;
}
