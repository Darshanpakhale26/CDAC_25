// Take integer inputs from user until he/she presses q ( Ask to press q to quit after every integer input ).
// Print average and product of all numbers.

#include <iostream>
using namespace std;

int main()
{
    int num;
    int sum = 0;
    int count = 0;
    long long product = 1;
    char choice;

    while (true)
    {
        cout << "Enter an integer: ";
        cin >> num;

        sum += num;
        product *= num;
        count++;

        cout << "Press 'q' to quit or any other key to continue: ";
        cin >> choice;

        if (choice == 'q' || choice == 'Q')
        {
            break;
        }
    }

    if (count == 0)
    {
        cout << "No numbers entered." << endl;
    }
    else
    {
        double average = (double)sum / count;
        cout << "Average: " << average << endl;
        cout << "Product: " << product << endl;
    }

    return 0;
}
