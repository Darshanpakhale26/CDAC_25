#include "StudenCGPA.cpp"
int main()
{
    Student students[100];
    int count = 0;
    int choice;

    do
    {
        cout << "\n----- Student Menu -----\n";
        cout << "1. Add New Student\n";
        cout << "2. Display All Students\n";
        cout << "3. Search by ID\n";
        cout << "4. Search by Name\n";
        cout << "5. Sort by M1 Marks\n";
        cout << "6. Calculate GPA of a Student\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            students[count].input();
            students[count].calculateGPA();
            count++;
            break;
        }
        case 2:
        {
            for (int i = 0; i < count; i++)
            {
                students[i].display();
                cout << "-------------------\n";
            }
            break;
        }
        case 3:
        {
            int id;
            cout << "Enter ID to search: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < count; i++)
            {
                if (students[i].getId() == id)
                {
                    students[i].display();
                    found = true;
                    break;
                }
            }
            if (!found)
                cout << "Student not found.\n";
            break;
        }
        case 4:
        {
            char nm[100];
            cout << "Enter name to search: ";
            cin.ignore();
            cin.getline(nm, 100);
            bool found = false;
            for (int i = 0; i < count; i++)
            {
                if (strcmp(students[i].getName(), nm) == 0)
                {
                    students[i].display();
                    found = true;
                }
            }
            if (!found)
                cout << "Student not found.\n";
            break;
        }
        case 5:
        {
          
            for (int i = 0; i < count - 1; i++)
            {
                for (int j = 0; j < count - i - 1; j++)
                {
                    if (students[j].getM1() > students[j + 1].getM1())
                    {
                        Student temp = students[j];
                        students[j] = students[j + 1];
                        students[j + 1] = temp;
                    }
                }
            }
            cout << "Sorted by M1 marks.\n";
            break;
        }
        case 6:
        {
            int id;
            cout << "Enter ID to calculate GPA: ";
            cin >> id;
            bool found = false;
            for (int i = 0; i < count; i++)
            {
                if (students[i].getId() == id)
                {
                    students[i].calculateGPA();
                    cout << "GPA calculated.\n";
                    students[i].display();
                    found = true;
                    break;
                }
            }
            if (!found)
                cout << "Student not found.\n";
            break;
        }
        case 7:
            cout << "Exiting program.\n";
            cout << "Thank you for using the Student Management System.\n";
            break;

        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 7);

    return 0;
}
