
#include <iostream>
#include <cstring>
using namespace std;

class Person
{
    int id;
    char name[100];
    char address[200];

public:
    Person()
    {    
        id = 0;
        name[0] = '\0';
        address[0] = '\0';
    }

    Person(int id, const char *nm, const char *addr)
    { 
        this->id = id;
        strncpy(name, nm, sizeof(name)); 
        name[sizeof(name) - 1] = '\0';
        strncpy(address, addr, sizeof(address));
        address[sizeof(address) - 1] = '\0';
    }

    void input()
    {
        cout << "Enter ID: ";
        cin >> id;
        cin.ignore();
        cout << "Enter Name: ";
        cin.getline(name, 100);
        cout << "Enter Address: ";
        cin.getline(address, 200);
    }

    void display() const
    {
        cout << "ID: " << id << ", Name: " << name << ", Address: " << address << endl;
    }

    int getId() const
    {
        return id;
    }
    const char *getName() const
    {
        return name;
    }
    void setAddress(const char *addr)
    {
        strncpy(address, addr, sizeof(address));
        address[sizeof(address) - 1] = '\0';
    }
};
