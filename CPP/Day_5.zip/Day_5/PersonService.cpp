
#include "Person.cpp"

class PersonService
{
    static Person persons[100];
    static int count;

public:
    static void addPerson()
    {
        if (count < 100)
        {
            persons[count].input();
            count++;
        }
        else
        {
            cout << "Storage full!" << endl;
        }
    }

    static void searchById()
    {
        int id;
        cout << "Enter ID to search: ";
        cin >> id;
        bool found = false;
        for (int i = 0; i < count; i++)
        {
            if (persons[i].getId() == id)
            {
                persons[i].display();
                found = true;
                break;
            }
        }
        if (!found)
            cout << "Person not found!" << endl;
    }

    static void displayAll()
    {
        if (count == 0)
        {
            cout << "No persons added yet!" << endl;
            return;
        }
        for (int i = 0; i < count; i++)
        {
            persons[i].display();
        }
    }

    static void searchByName()
    {
        char nm[100];
        cout << "Enter Name to search: ";
        cin.ignore();
        cin.getline(nm, 100);
        bool found = false;
        for (int i = 0; i < count; i++)
        {
            if (strcmp(persons[i].getName(), nm) == 0)
            {
                persons[i].display();
                found = true;
            }
        }
        if (!found)
            cout << "Person not found!" << endl;
    }

    static void sortById()
    {
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (persons[j].getId() > persons[j + 1].getId())
                {
                    Person temp = persons[j];
                    persons[j] = persons[j + 1];
                    persons[j + 1] = temp;
                }
            }
        }
        cout << "Sorted by ID." << endl;
    }

    static void sortByName()
    {
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - i - 1; j++)
            {
                if (strcmp(persons[j].getName(), persons[j + 1].getName()) > 0)
                {
                    Person temp = persons[j];
                    persons[j] = persons[j + 1];
                    persons[j + 1] = temp;
                }
            }
        }
        cout << "Sorted by Name." << endl;
    }

    static void modifyAddressById()
    {
        int id;
        cout << "Enter ID to modify address: ";
        cin >> id;
        cin.ignore();
        char newAddr[200];
        cout << "Enter new address: ";
        cin.getline(newAddr, 200);
        bool found = false;
        for (int i = 0; i < count; i++)
        {
            if (persons[i].getId() == id)
            {
                persons[i].setAddress(newAddr);
                cout << "Address updated successfully!" << endl;
                found = true;
                break;
            }
        }
        if (!found)
            cout << "Person not found!" << endl;
    }
}; 
