#include <cstring>
#include <iostream>
using namespace std;

class Student
{
    int studId;
    char name[100];
    int marks[3];

public:
    Student()
    {
        studId = 0;
        name[0] = '\0';
        marks[0] = marks[1] = marks[2] = 0;
    }
    Student(int id, const char *name, int m1, int m2, int m3)
    {
        studId = id;
        strncpy(this->name, name, sizeof(this->name));
        marks[0] = m1;
        marks[1] = m2;
        marks[2] = m3;
    }

    void input()
    {
        cout << "Enter Student ID: ";
        cin >> studId;
        cout << "Enter Name: ";
        cin.ignore();
        cin.getline(name, 100);
        cout << "Enter marks in 3 subjects: ";
        cin >> marks[0] >> marks[1] >> marks[2];
    }

    void display() const
    {
        cout << "Student Id: " << studId << endl;
        cout << "Name: " << name << endl;
        cout << "M1: " << marks[0] << "  M2: " << marks[1] << "  M3: " << marks[2] << endl;
    }
};

int main()
{
    Student s1;
    s1.input();
    s1.display();

    return 0;
}
