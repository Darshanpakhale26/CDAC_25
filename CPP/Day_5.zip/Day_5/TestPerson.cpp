
#include "PersonService.cpp"


Person PersonService::persons[100];
int PersonService::count = 0;

int main()
{
    int choice;
    do
    {
        cout << "\n----- Person Menu -----\n";
        cout << "1. Add Person\n";
        cout << "2. Search by ID\n";
        cout << "3. Display All\n";
        cout << "4. Search by Name\n";
        cout << "5. Sort by ID\n";
        cout << "6. Sort by Name\n";
        cout << "7. Modify Address by ID\n";
        cout << "8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            PersonService::addPerson();
            break;
        case 2:
            PersonService::searchById();
            break;
        case 3:
            PersonService::displayAll();
            break;
        case 4:
            PersonService::searchByName();
            break;
        case 5:
            PersonService::sortById();
            break;
        case 6:
            PersonService::sortByName();
            break;
        case 7:
            PersonService::modifyAddressById();
            break;
        case 8:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
        }
    } while (choice != 8);

    return 0;
}
