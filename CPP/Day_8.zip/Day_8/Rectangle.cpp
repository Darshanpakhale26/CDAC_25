#include "Rectangle.h"
#include "Shape.h"
#include <iostream>
using namespace std;

Rectangle::Rectangle() {
	l = 0.0;
	b = 0.0;
}

Rectangle::Rectangle(const char* color, double l, double b) : Shape(color) {
	this->l = l;
	this->b = b;
	
}

Rectangle::~Rectangle() {}

double Rectangle::getl() {
	return l;
}

double Rectangle::getb() {
	return b;
}

void Rectangle::setl(double l) {
	this->l=l;
}


void Rectangle::setb(double b) {
	this->b = b;

}

double Rectangle::calcArea() {
	return l*b;
}

double Rectangle::calcPerimeter() {
	return 2*(l+b);
}

void Rectangle::display() const {
	Shape::display();
	cout << "Length: " << l << endl;
	cout << "Breadth: " << b << endl;
	
}
