#include "Square.h"
#include "Shape.h"
#include <iostream>
using namespace std;

Square::Square() {
	s1=0.0;
	
}

Square::Square(const char* color, double s1) : Shape(color) {
	this->s1 = s1;
	
}

Square::~Square() {}

double Square::getS1() {
	return s1;
}

void Square::setS1(double s1) {
	this->s1=s1;
}

double Square::calcArea() {
	return (s1*s1);
}

double Square::calcPerimeter() {
	return s1+s1+s1+s1;
}

void Square::display() const {
	Shape::display();
	cout << "Side-1: " << s1 << endl;
}
