#include "Shape.h"

class Rectangle : public Shape {
	double l;
	double b;
	
	public:
		Rectangle();
		Rectangle(const char* color, double l, double b);
		~Rectangle();
		
		// Getter Methods
		double getl();
		double getb();
	
		
		 // Setter Methods
		 void setl(double l);
		 void setb(double b);
		 
		 // Calculate Functions
		 double calcArea();
		 double calcPerimeter();
		 
		 // Display
		 void display() const;
};
