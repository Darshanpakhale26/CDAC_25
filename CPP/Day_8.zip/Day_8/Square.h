#include "Shape.h"

class Square: public Shape {
	double s1;
	
	public:
		Square();
		Square(const char* color, double s1);
		~Square();
		
		// Getter Methods
		double getS1();
	
		
		 // Setter Methods
		 void setS1(double s1);
		 
		 // Calculate Functions
		 double calcArea();
		 double calcPerimeter();
		 
		 // Display
		 void display() const;
};
