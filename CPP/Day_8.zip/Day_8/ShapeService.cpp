//#include "Circle.h"
//#include "Triangle.h"
#include "ShapeService.h"
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

Shape* ShapeService::sArr[100];
int ShapeService::count = 0;

void ShapeService::addShape(int n) {
	char color[10];
	
	cout << "Enter color: ";
	cin >> color;
	
	if (n == 1) {
		double s1, s2, base, height;
		cout << "Enter S1: ";
		cin >> s1;
		cout << "Enter S2: ";
		cin >> s2;
		cout << "Enter base: ";
		cin >> base;
		cout << "Enter height: ";
		cin >> height;
		
		sArr[count++] = new Triangle(color, s1, s2, base, height);
	}
	
	else if (n == 2) {
		double radius;
		cout << "Enter radius: ";
		cin >> radius;
		
		sArr[count++] = new Circle(color, radius);
	}
	
	else if(n==3){
	        double side;
	        cout<<"Enter side: ";
	        cin>>side;
	        
	        sArr[count++] = new Square(color,side);
	        
	}
	
	else if(n==4){
	        double l,b;
	        cout<<"Enter length and breadth: ";
	        cin>>l>>b;
	        
	        sArr[count++] = new Rectangle(color,l,b);
	        
	}
}

void ShapeService::displayAll() {
	cout << "All shapes are:" << endl;
	for (int i=0; i<count; i++) {
		sArr[i]->display();
	}
}

void ShapeService::displayTriangles() {
	cout << "Triangles are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<Triangle*>(sArr[i]))
			sArr[i]->display();
	}
}

void ShapeService::displayCircles() {
	cout << "Circles are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<Circle*>(sArr[i]))
			sArr[i]->display();
			cout << endl;
	}
}

void ShapeService::displaySquares() {
	cout << "Squares are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<Square*>(sArr[i]))
			sArr[i]->display();
			cout << endl;
	}
}

void ShapeService::displayRectangles() {
	cout << "Rectangles are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<Rectangle*>(sArr[i]))
			sArr[i]->display();
			cout << endl;
	}
}

int ShapeService::searchByColor(const char* color, Shape* result[100]){
	int cnt = -1;
	for (int i=0; i<count; i++) {
		if (strcmp(sArr[i]->getColor(), color) == 0) {
			result[++cnt] = sArr[i];
		}
	}
	return cnt;
}

void ShapeService::sortBycolor() {
      sort(sArr, sArr + count,[](Shape*a,Shape*b)
      {
        return (a->getColor() > b->getColor());
       
        
      });
      cout<<"Colour sorted successsfully"<<endl;
      
}

void ShapeService::calculateAllAreas(){
	for (int i=0; i<count; i++) {
		cout<<"Area is: "<<sArr[i]->calcArea()<<endl;
	}
}

void ShapeService::calculateAllPerimeters(){
	for (int i=0; i<count; i++) {
		cout<<"Perimeter is: "<<sArr[i]->calcPerimeter()<<endl;
	}
}







