#include "MyClass.h"
#include <iostream>

int main() {
    // Creating two MyClass objects to test the operations
    MyClass obj1(10, 20, 30, "first");
    MyClass obj2(5, 10, 30, "second");
    MyClass obj_default; // Using the default constructor

    std::cout << "Original objects:" << std::endl;
    std::cout << "obj1: ";
    obj1.display();
    std::cout << "obj2: ";
    obj2.display();
    std::cout << "obj_default: ";
    obj_default.display();

    // --- Demonstrating Operator Overloads ---
    std::cout << "\n--- Operator Demonstrations ---" << std::endl;

    // Addition operator
    std::cout << "Addition (obj1 + obj2):" << std::endl;
    MyClass obj_sum = obj1 + obj2;
    obj_sum.display();

    // Subtraction operator
    std::cout << "\nSubtraction (obj1 - obj2):" << std::endl;
    MyClass obj_diff = obj1 - obj2;
    obj_diff.display();

    // Multiplication operator
    std::cout << "\nMultiplication (obj1 * obj2):" << std::endl;
    MyClass obj_prod = obj1 * obj2;
    obj_prod.display();

    // Division operator
    std::cout << "\nDivision (obj1 / obj2):" << std::endl;
    try {
        MyClass obj_div = obj1 / obj2;
        obj_div.display();
    } catch (const std::invalid_argument& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    // Equality operator
    std::cout << "\nEquality (obj1 == obj2):" << std::endl;
    if (obj1 == obj2) {
        std::cout << "The objects are equal." << std::endl;
    } else {
        std::cout << "The objects are not equal." << std::endl;
    }

    // Creating a copy to demonstrate the copy constructor and equality operator
    MyClass obj1_copy = obj1;
    std::cout << "\nEquality (obj1 == obj1_copy):" << std::endl;
    std::cout << "obj1: ";
    obj1.display();
    std::cout << "obj1_copy: ";
    obj1_copy.display();
    if (obj1 == obj1_copy) {
        std::cout << "The objects are equal." << std::endl;
    } else {
        std::cout << "The objects are not equal." << std::endl;
    }

    return 0;
}

