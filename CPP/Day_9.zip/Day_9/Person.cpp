#include "Person.h"
#include <cstring>

// Initialize the static counter
int Person::count = 0;

// Default constructor implementation
Person::Person() {
    id = ++count;
    name = nullptr;
}

// Parameterized constructor implementation
Person::Person(const char* nm, const Address& a) : addr(a) {
    id = ++count;
    name = new char[strlen(nm) + 1];
    strcpy(name, nm);
}

// Copy constructor implementation
Person::Person(const Person& other) : addr(other.addr) {
    id = other.id;
    name = new char[strlen(other.name) + 1];
    strcpy(name, other.name);
}

// Destructor implementation
Person::~Person() {
    delete[] name;
}

// Getter methods implementations
int Person::getId() const { return id; }
const char* Person::getName() const { return name; }
Address& Person::getAddr() { return addr; }

// Display method implementation
void Person::display() const {
    std::cout << "ID: " << id << ", Name: " << name << ", ";
    addr.display();
    std::cout << std::endl;
}

