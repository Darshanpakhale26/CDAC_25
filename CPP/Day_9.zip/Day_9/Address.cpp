#include "Address.h"
#include <cstring>

// Default constructor implementation
Address::Address() {
    street = nullptr;
    city = nullptr;
    state = nullptr;
    pin = 0;
}

// Parameterized constructor implementation
Address::Address(const char* str, const char* ci, const char* st, int p) {
    street = new char[strlen(str) + 1];
    strcpy(street, str);

    city = new char[strlen(ci) + 1];
    strcpy(city, ci);

    state = new char[strlen(st) + 1];
    strcpy(state, st);

    pin = p;
}

// Copy constructor implementation
Address::Address(const Address& other) {
    street = new char[strlen(other.street) + 1];
    strcpy(street, other.street);
    city = new char[strlen(other.city) + 1];
    strcpy(city, other.city);
    state = new char[strlen(other.state) + 1];
    strcpy(state, other.state);
    pin = other.pin;
}

// Destructor implementation
Address::~Address() {
    delete[] street;
    delete[] city;
    delete[] state;
}

// Getter methods implementations
const char* Address::getStreet() const { return street; }
const char* Address::getCity() const { return city; }
const char* Address::getState() const { return state; }
int Address::getPin() const { return pin; }

// Mutator methods implementations
void Address::setStreet(const char* newStreet) {
    delete[] street;
    street = new char[strlen(newStreet) + 1];
    strcpy(street, newStreet);
}

void Address::setCity(const char* newCity) {
    delete[] city;
    city = new char[strlen(newCity) + 1];
    strcpy(city, newCity);
}

void Address::setState(const char* newState) {
    delete[] state;
    state = new char[strlen(newState) + 1];
    strcpy(state, newState);
}

void Address::setPin(int newPin) {
    pin = newPin;
}

// Display method implementation
void Address::display() const {
    std::cout << "Street: " << street << ", City: " << city << ", State: " << state << ", Pin: " << pin;
}

