#ifndef ADDRESS_H
#define ADDRESS_H

#include <iostream>

class Address {
private:
    char* street;
    char* city;
    char* state;
    int pin;

public:
    // Default constructor
    Address();

    // Parameterized constructor
    Address(const char* str, const char* ci, const char* st, int p);

    // Copy constructor for deep copying the object's data
    Address(const Address& other);

    // Destructor to free dynamically allocated memory
    ~Address();

    // Getter methods to access private data
    const char* getStreet() const;
    const char* getCity() const;
    const char* getState() const;
    int getPin() const;

    // Mutator methods to modify address details
    void setStreet(const char* newStreet);
    void setCity(const char* newCity);
    void setState(const char* newState);
    void setPin(int newPin);

    // Method to display the full address
    void display() const;
};

#endif // ADDRESS_H

