#ifndef MYCLASS_H
#define MYCLASS_H

#include <iostream>

class MyClass {
private:
    int i, j, k;
    char* name;

public:
    // --- Constructors ---
    
    // Default constructor: Initializes member variables to safe, default values.
    MyClass();

    // Parameterized constructor: Initializes the object with specific values.
    MyClass(int i, int j, int k, const char* name);

    // Copy constructor: Performs a deep copy of the object,
    // which is crucial for handling dynamically allocated memory (like `name`).
    MyClass(const MyClass& other);
    
    // Destructor: Cleans up resources, specifically the dynamically allocated `name` string.
    ~MyClass();

    // --- Operator Overloads ---

    // Overloads the '+' operator to perform member-wise addition and concatenate names.
    MyClass operator+(const MyClass& other) const;

    // Overloads the '-' operator to perform member-wise subtraction and copy the current object's name.
    MyClass operator-(const MyClass& other) const;

    // Overloads the '*' operator to perform member-wise multiplication and copy the current object's name.
    MyClass operator*(const MyClass& other) const;

    // Overloads the '/' operator to perform member-wise division and copy the current object's name.
    // Includes a check to prevent division by zero.
    MyClass operator/(const MyClass& other) const;

    // Overloads the '==' operator to compare two MyClass objects for equality.
    // It returns true if all member variables are identical.
    bool operator==(const MyClass& other) const;
    
    // A utility method to display the object's contents.
    void display() const;
};

#endif // MYCLASS_H

