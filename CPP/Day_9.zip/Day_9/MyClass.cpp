/*Create a class MyClass, to store, int i, int j, int k,char* name
define default,parametrised and copy constructor
overload operators(+,-,*,/,==) == operator return type will be bool(true or false)
add operator will add numbers memberwise and string will be concatenated
subtract operator will subtract numbers memberwise and name of this pointer will be copied
Multiply operator will multiply numbers memberwise and name of this pointer will be copied.
Divide operator will divide numbers memberwise and name of this pointer will be copied.
*/

#include "MyClass.h"
#include <cstring>
#include <stdexcept>

// Default constructor implementation.
// This sets everything to a clean state, ready to be used.
MyClass::MyClass() : i(0), j(0), k(0), name(nullptr) {}

// Parameterized constructor implementation.
// It allocates memory for the name and copies the provided string.
MyClass::MyClass(int i, int j, int k, const char* name) : i(i), j(j), k(k) {
    if (name) {
        this->name = new char[strlen(name) + 1];
        strcpy(this->name, name);
    } else {
        this->name = nullptr;
    }
}

// Copy constructor implementation.
// It's essential for a deep copy, ensuring the new object has its own unique copy of the string.
MyClass::MyClass(const MyClass& other) : i(other.i), j(other.j), k(other.k) {
    if (other.name) {
        name = new char[strlen(other.name) + 1];
        strcpy(name, other.name);
    } else {
        name = nullptr;
    }
}

// Destructor implementation.
// It frees the memory allocated for the `name` to prevent memory leaks.
MyClass::~MyClass() {
    delete[] name;
}

// Overloaded '+' operator.
// It creates a new object and adds the members. The names are concatenated.
MyClass MyClass::operator+(const MyClass& other) const {
    int sum_i = i + other.i;
    int sum_j = j + other.j;
    int sum_k = k + other.k;

    char* new_name = nullptr;
    size_t len1 = name ? strlen(name) : 0;
    size_t len2 = other.name ? strlen(other.name) : 0;
    
    new_name = new char[len1 + len2 + 1];
    
    if (name) strcpy(new_name, name);
    else new_name[0] = '\0';
    
    if (other.name) strcat(new_name, other.name);

    return MyClass(sum_i, sum_j, sum_k, new_name);
}

// Overloaded '-' operator.
// It subtracts members and copies the name of the left-hand side object (this).
MyClass MyClass::operator-(const MyClass& other) const {
    int diff_i = i - other.i;
    int diff_j = j - other.j;
    int diff_k = k - other.k;
    return MyClass(diff_i, diff_j, diff_k, this->name);
}

// Overloaded '*' operator.
// It multiplies members and copies the name of the left-hand side object (this).
MyClass MyClass::operator*(const MyClass& other) const {
    int prod_i = i * other.i;
    int prod_j = j * other.j;
    int prod_k = k * other.k;
    return MyClass(prod_i, prod_j, prod_k, this->name);
}

// Overloaded '/' operator.
// It divides members and copies the name of the left-hand side object (this).
// Includes an exception-handling mechanism for division by zero.
MyClass MyClass::operator/(const MyClass& other) const {
    if (other.i == 0 || other.j == 0 || other.k == 0) {
        throw std::invalid_argument("Division by zero is not allowed.");
    }
    int div_i = i / other.i;
    int div_j = j / other.j;
    int div_k = k / other.k;
    return MyClass(div_i, div_j, div_k, this->name);
}

// Overloaded '==' operator.
// Compares all integer members and the names to check for equality.
bool MyClass::operator==(const MyClass& other) const {
    if (i != other.i || j != other.j || k != other.k) {
        return false;
    }
    // Compare names if both are not null, or check if both are null.
    if ((name && other.name && strcmp(name, other.name) == 0) || (!name && !other.name)) {
        return true;
    }
    return false;
}

// Display method.
// Prints the current state of the object's member variables.
void MyClass::display() const {
    std::cout << "i: " << i << ", j: " << j << ", k: " << k << ", name: " << (name ? name : "NULL") << std::endl;
}

