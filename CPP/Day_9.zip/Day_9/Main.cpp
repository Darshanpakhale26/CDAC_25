#include "Person.h"
#include <iostream>
#include <vector>
#include <limits>
#include <cstring>

using namespace std;

int main() {
    vector<Person*> people; // Using a vector to hold pointers to Person objects
    int choice;

    do {
        cout << "\n--- Person Management System ---" << endl;
        cout << "1. Add new Person" << endl;
        cout << "2. Display All Persons" << endl;
        cout << "3. Search by ID" << endl;
        cout << "4. Search by Name" << endl;
        cout << "5. Modify Address" << endl;
        cout << "6. Find Address by ID of Person" << endl;
        cout << "7. Display All Persons in a given City" << endl;
        cout << "8. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        // Clear input buffer to handle different types of input correctly
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1: {
                // Add a new Person
                char name[100], street[100], city[100], state[100];
                int pin;
                cout << "Enter Name: ";
                cin.getline(name, 100);
                cout << "Enter Street: ";
                cin.getline(street, 100);
                cout << "Enter City: ";
                cin.getline(city, 100);
                cout << "Enter State: ";
                cin.getline(state, 100);
                cout << "Enter Pin: ";
                cin >> pin;

                Address newAddr(street, city, state, pin);
                people.push_back(new Person(name, newAddr));
                cout << "Person added successfully!" << endl;
                break;
            }
            case 2: {
                // Display all Persons
                cout << "\n--- All Persons ---" << endl;
                if (people.empty()) {
                    cout << "No persons to display." << endl;
                } else {
                    for (const auto& p : people) {
                        p->display();
                    }
                }
                break;
            }
            case 3: {
                // Search by ID
                int idToSearch;
                cout << "Enter ID to search: ";
                cin >> idToSearch;
                bool found = false;
                for (const auto& p : people) {
                    if (p->getId() == idToSearch) {
                        p->display();
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "Person with ID " << idToSearch << " not found." << endl;
                }
                break;
            }
            case 4: {
                // Search by Name
                char nameToSearch[100];
                cout << "Enter Name to search: ";
                cin.getline(nameToSearch, 100);
                bool found = false;
                for (const auto& p : people) {
                    if (strcmp(p->getName(), nameToSearch) == 0) {
                        p->display();
                        found = true;
                    }
                }
                if (!found) {
                    cout << "Person with name '" << nameToSearch << "' not found." << endl;
                }
                break;
            }
            case 5: {
                // Modify Address
                int idToModify;
                cout << "Enter ID of the person to modify address: ";
                cin >> idToModify;
                bool found = false;
                for (auto& p : people) {
                    if (p->getId() == idToModify) {
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        char newStreet[100], newCity[100], newState[100];
                        int newPin;
                        cout << "Enter new Street: ";
                        cin.getline(newStreet, 100);
                        cout << "Enter new City: ";
                        cin.getline(newCity, 100);
                        cout << "Enter new State: ";
                        cin.getline(newState, 100);
                        cout << "Enter new Pin: ";
                        cin >> newPin;
                        
                        p->getAddr().setStreet(newStreet);
                        p->getAddr().setCity(newCity);
                        p->getAddr().setState(newState);
                        p->getAddr().setPin(newPin);
                        
                        cout << "Address updated successfully!" << endl;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "Person with ID " << idToModify << " not found." << endl;
                }
                break;
            }
            case 6: {
                // Find Address by ID
                int idToFind;
                cout << "Enter ID to find address: ";
                cin >> idToFind;
                bool found = false;
                for (const auto& p : people) {
                    if (p->getId() == idToFind) {
                        cout << "Address for ID " << idToFind << ": ";
                        p->getAddr().display();
                        cout << endl;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "Person with ID " << idToFind << " not found." << endl;
                }
                break;
            }
            case 7: {
                // Display all Persons in a given City
                char cityToSearch[100];
                cout << "Enter city name to search: ";
                cin.getline(cityToSearch, 100);
                bool found = false;
                cout << "\n--- Persons in " << cityToSearch << " ---" << endl;
                for (const auto& p : people) {
                    if (strcmp(p->getAddr().getCity(), cityToSearch) == 0) {
                        p->display();
                        found = true;
                    }
                }
                if (!found) {
                    cout << "No persons found in '" << cityToSearch << "'." << endl;
                }
                break;
            }
            case 8: {
                cout << "Exiting program. Good Bye!" << endl;
                // Clean up dynamically allocated memory
                for (auto& p : people) {
                    delete p;
                }
                people.clear();
                break;
            }
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }

    } while (choice != 8);

    return 0;
}

