#ifndef PERSON_H
#define PERSON_H

#include "Address.h"
#include <iostream>

class Person {
private:
    static int count; // Static member for auto-incrementing ID
    int id;
    char* name;
    Address addr; // HAS-A relationship: Person has an Address

public:
    // Default constructor
    Person();

    // Parameterized constructor
    Person(const char* nm, const Address& a);
    
    // Copy constructor for deep copying the object's data
    Person(const Person& other);

    // Destructor to free dynamically allocated memory
    ~Person();

    // Getter methods to access private data
    int getId() const;
    const char* getName() const;
    Address& getAddr(); // Returns a reference to the Address object

    // Method to display the person's details
    void display() const;
};

#endif // PERSON_H

