package com.acts;

import java.util.LinkedList;
import java.util.Queue;
import java.util.List;
import java.util.ArrayList;

class AdjListGraph {
	private int numVertices;
	private List<List<Integer>> adj;

	public AdjListGraph(int numVertices) {
		this.numVertices = numVertices;
		this.adj = new ArrayList<>(numVertices);
		for (int i = 0; i < numVertices; i++) {
			adj.add(new LinkedList<>());
		}
	}

	public void addEdge(int u, int v) {
		adj.get(u).add(v);

	}

	public void printBFS() {
		if (numVertices == 0) {
			System.out.println("Graph is empty.");
			return;
		}

		boolean[] visited = new boolean[numVertices];

		Queue<Integer> queue = new LinkedList<>();

		int startVertex = 0;

		// 2. Start Traversal
		visited[startVertex] = true;
		queue.add(startVertex);

		System.out.print("BFS Traversal starting from vertex " + startVertex + ": ");

		while (queue.size() != 0) {

			int u = queue.poll();
			System.out.print(u + " ");

			for (int v : adj.get(u)) {

				if (!visited[v]) {
					visited[v] = true;
					queue.add(v);
				}
			}
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// Create a graph with 6 vertices (0 to 5)
		AdjListGraph graph = new AdjListGraph(6);

		// Add edges (example graph)
		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 3);

		graph.addEdge(2, 4);
		graph.addEdge(3, 5);
		graph.addEdge(4, 5);

		graph.printBFS();

	}

}
