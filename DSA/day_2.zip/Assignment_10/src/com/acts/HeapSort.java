package com.acts;

public class HeapSort {

	public void heapSort(int[] arr) {
		if (arr == null || arr.length < 2) {
			return;
		}

		int n = arr.length;

		for (int i = n / 2 - 1; i >= 0; i--) {
			heapify(arr, n, i);
		}

		for (int i = n - 1; i > 0; i--) {

			swap(arr, 0, i);

			heapify(arr, i, 0);
		}
	}

	private void heapify(int[] arr, int n, int i) {
		int largest = i; // Initialize largest as root
		int left = 2 * i + 1; // left child = 2*i + 1
		int right = 2 * i + 2; // right child = 2*i + 2

		
		if (left < n && arr[left] > arr[largest]) {
			largest = left;
		}

		if (right < n && arr[right] > arr[largest]) {
			largest = right;
		}

		if (largest != i) {

			swap(arr, i, largest);

			heapify(arr, n, largest);
		}
	}

	private void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	
	public static void main(String[] args) {
		HeapSort sorter = new HeapSort();
		int[] data = { 4, 10, 3, 5, 1, 2 };

		System.out.println("Original Array:");
		for (int x : data)
			System.out.print(x + " ");

		sorter.heapSort(data);

		System.out.println("\nSorted Array (Ascending):");
		// Output: 10 5 4 3 2 1
		for (int x : data)
			System.out.print(x + " ");
	}
}
