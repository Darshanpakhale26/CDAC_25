package com.acts;

import java.lang.Math;
import java.lang.StringBuilder;

public class HashTable<K, V> {

   
    static class HashNode<K, V> {
        K key;
        V value;

        public HashNode(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "{" + key + "=" + value + "}";
        }
    }

   
    static class SinglyLinkedList<K, V> {
        
        // Inner node class to structure the list
        private static class Node<K, V> {
            HashNode<K, V> data;
            Node<K, V> next;

            Node(HashNode<K, V> data) {
                this.data = data;
                this.next = null;
            }
        }
        
        private Node<K, V> headNode; 

      
        public void add(K key, V value) {
            HashNode<K, V> newNodeData = new HashNode<>(key, value);

          
            Node<K, V> current = headNode;
            while (current != null) {
                if (current.data.key.equals(key)) {
                    current.data.value = value; 
                }
                current = current.next;
            }

         
            Node<K, V> newNode = new Node<>(newNodeData);
            newNode.next = headNode;
            headNode = newNode;
        }
        
      
        public V get(K key) {
            Node<K, V> current = headNode;
            while (current != null) {
                if (current.data.key.equals(key)) {
                    return current.data.value;
                }
                current = current.next;
            }
            return null; 

     
        public V remove(K key) {
            Node<K, V> current = headNode;
            Node<K, V> previous = null;

            while (current != null) {
                if (current.data.key.equals(key)) {
                    V removedValue = current.data.value;
                    if (previous == null) {
                        headNode = current.next;
                    } else {
                        previous.next = current.next; 
                    }
                    return removedValue;
                }
                previous = current;
                current = current.next;
            }
            return null; // Key not found
        }
        
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            Node<K, V> current = headNode;
            while (current != null) {
                sb.append(current.data).append(" -> ");
                current = current.next;
            }
            sb.append("NULL");
            return sb.toString();
        }
    }
    
 

  
    @SuppressWarnings("unchecked")
    private SinglyLinkedList<K, V>[] table; 
    private int capacity;

   
    public ChainingHashTable(int capacity) {
        this.capacity = capacity;
        table = (SinglyLinkedList<K, V>[]) new SinglyLinkedList[capacity];
    }
    
    /** * Simple hash function to get the bucket index. */
    private int hash(K key) {
        return Math.abs(key.hashCode()) % capacity;
    }

    /** * Inserts a key-value pair into the hash table. */
    public void put(K key, V value) {
        int index = hash(key);

        if (table[index] == null) {
            table[index] = new SinglyLinkedList<>();
        }

        table[index].add(key, value);
    }

    /** * Retrieves the value associated with the given key. */
    public V get(K key) {
        int index = hash(key);

        if (table[index] == null) {
            return null;
        }

        return table[index].get(key);
    }

    /** * Removes the key-value pair associated with the given key. */
    public V remove(K key) {
        int index = hash(key);

        if (table[index] == null) {
            return null;
        }

        return table[index].remove(key);
    }
    
    /** Utility for visualizing the hash table structure. */
    public void printTable() {
        System.out.println("\n--- Hash Table State (Capacity: " + capacity + ") ---");
        for (int i = 0; i < capacity; i++) {
            System.out.printf("Bucket %d: ", i);
            if (table[i] != null) {
                System.out.println(table[i]);
            } else {
                System.out.println("NULL");
            }
        }
        System.out.println("------------------------------------");
    }

    // --- Example Usage ---
    public static void main(String[] args) {
        ChainingHashTable<String, Integer> ht = new ChainingHashTable<>(5);

        System.out.println("Putting initial values (some collisions expected in capacity 5)...");
        ht.put("Apple", 100);
        ht.put("Banana", 200);
        ht.put("Cherry", 300);
        ht.put("Grape", 400); // Collision example
        ht.put("Lemon", 500);
        ht.put("Durian", 600); // Another collision example

        ht.printTable();

        System.out.println("\n*** Operations ***");
        System.out.println("Getting Apple: " + ht.get("Apple")); 
        System.out.println("Getting Durian: " + ht.get("Durian")); 
        System.out.println("Removing Cherry: " + ht.remove("Cherry")); 
        
        System.out.println("\n*** After Removal ***");
        ht.printTable();
        
        System.out.println("Getting Cherry (Should be null): " + ht.get("Cherry")); 
    }
}
