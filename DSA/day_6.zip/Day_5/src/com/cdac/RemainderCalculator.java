package com.cdac;

public class RemainderCalculator {
	private static int remainderRecursivePositive(int a, int b) {
		if (a < b) {

			return a;
		}

		return remainderRecursivePositive(a - b, b);
	}

	public static int remainder(int a, int b) {
		if (b == 0) {
			System.err.println("Error: Division by zero for remainder calculation.");
			return 0;
		}

		boolean isNegativeDividend = a < 0;

		int absA = Math.abs(a);
		int absB = Math.abs(b);

		int positiveRemainder = remainderRecursivePositive(absA, absB);

		if (isNegativeDividend) {
			return -positiveRemainder;
		} else {
			return positiveRemainder;
		}
	}

	public static void main(String[] args) {
		int a1 = 17, b1 = 5;
		System.out.println("17 % 5 = " + remainder(a1, b1));

		int a2 = 17, b2 = -5;
		System.out.println("17 % -5 = " + remainder(a2, b2));

		int a3 = -17, b3 = 5;
		System.out.println("-17 % 5 = " + remainder(a3, b3));

		int a4 = -17, b4 = -5;
		System.out.println("-17 % -5 = " + remainder(a4, b4));
	}

}
