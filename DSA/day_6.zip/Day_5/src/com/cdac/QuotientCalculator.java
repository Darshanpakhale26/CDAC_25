package com.cdac;

class QuotientCalculator {

    private static int quotientRecursivePositive(int a, int b) {
        if (a < b) {
            return 0;
        }
        return 1 + quotientRecursivePositive(a - b, b);
    }

    public static int quotient(int a, int b) {
        if (b == 0) {
            System.err.println("Error: Division by zero.");
            return 0;
        }

        boolean isNegativeResult = (a < 0) ^ (b < 0);

        int absA = Math.abs(a);
        int absB = Math.abs(b);

        int positiveQuotient = quotientRecursivePositive(absA, absB);

        if (isNegativeResult) {
            return -positiveQuotient;
        } else {
            return positiveQuotient;
        }
    }

    public static void main(String[] args) {
        int a1 = 17, b1 = 5;
        System.out.println("17 / 5 = " + quotient(a1, b1));

        int a3 = -17, b3 = 5;
        System.out.println("-17 / 5 = " + quotient(a3, b3));

        int a5 = -17, b5 = -5;
        System.out.println("-17 / -5 = " + quotient(a5, b5));
    }
}

