package com.cdac;

public class MultiplyCalculator {

	private static int multiplyRecursivePositive(int a, int b) {

		if (b == 0) {
			return 0;
		}

		return a + multiplyRecursivePositive(a, b - 1);
	}

	public static int multiply(int a, int b) {

		if (Math.abs(a) < Math.abs(b)) {
			return multiply(b, a); // Swap roles
		}

		boolean isNegativeResult = (a < 0) ^ (b < 0);

		// Get absolute values
		int absA = Math.abs(a);
		int absB = Math.abs(b);

		int positiveProduct = multiplyRecursivePositive(absA, absB);

		if (isNegativeResult) {
			return -positiveProduct;
		} else {
			return positiveProduct;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a1 = 7, b1 = 5;
		System.out.println("7 * 5 = " + multiply(a1, b1));
		int a2 = -7, b2 = 5;
		System.out.println("-7 * 5 = " + multiply(a2, b2));
		int a3 = 7, b3 = -5;
		System.out.println("7 * -5 = " + multiply(a3, b3));
		int a4 = -7, b4 = -5;
		System.out.println("-7 * -5 = " + multiply(a4, b4));

	}

}
