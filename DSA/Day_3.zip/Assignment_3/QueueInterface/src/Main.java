public class Main {
    public static void main(String[] args) {
        Queue<Integer> q = new LinkedQueue<>();
        try {
            q.enqueue(10);
            q.enqueue(20);
            System.out.println("Front: " + q.front()); // 10
            System.out.println("Dequeued: " + q.dequeue()); // 10
            System.out.println("Front after dequeue: " + q.front()); // 20
            q.dequeue(); // Should empty the queue
            System.out.println("Is empty? " + q.isEmpty());
            q.dequeue(); // This will throw an exception
        } catch (EmptyQueueException e) {
            System.out.println(e.getMessage());
        }
    }
}
