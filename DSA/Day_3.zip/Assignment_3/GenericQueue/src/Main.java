public class Main {
    public static void main(String[] args) {
        Queue<Integer> q = new GenericQueue<>(5);

        try {
            q.enqueue(10);
            q.enqueue(20);
            q.enqueue(30);
            System.out.println("Front: " + q.front()); // 10
            System.out.println("Dequeued: " + q.dequeue()); // 10
            System.out.println("Front after dequeue: " + q.front()); // 20
            q.enqueue(40);
            q.enqueue(50);
            q.enqueue(60); // will throw FullQueueException
        } catch (FullQueueException | EmptyQueueException e) {
            System.out.println(e.getMessage());
        }
    }
}
