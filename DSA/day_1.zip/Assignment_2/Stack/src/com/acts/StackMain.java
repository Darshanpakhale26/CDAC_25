package com.acts;

//Java Program demonstrating the use of 
//ResizableArray

//import ResizableArrayPackage.ResizableArray;

public class StackMain
{
 public static void main(String[] args) 
 {
   	
   
     ResizableArray<Integer> arr = new ResizableArray<>();

   
     System.out.println("Array Size Initial : "+arr.size());
     System.out.println("");

    
     for (int i = 0; i < 3; i++) {
         arr.add((int)(Math.random()*10));
     }
     
   	
     System.out.println("Array Size after Addition : "+arr.size());
     System.out.println("Array Elements : " + arr.toString() );
     System.out.println("");

   	
     arr.remove(1);
     
		
     System.out.println("Array Size after Removal : "+arr.size());
     System.out.println("Array Elements : " + arr.toString() );

 }
 
}
