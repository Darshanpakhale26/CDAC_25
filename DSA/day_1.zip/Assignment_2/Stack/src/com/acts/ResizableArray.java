package com.acts;

//package ResizableArrayPackage;
import java.util.Arrays;

// ResizableArray Class
public class ResizableArray<T> {
    
    // Default capacity for the array
    private int capacity;
    private Object[] array;
    private int size;

    // Constructor 
    public ResizableArray() {
        this.capacity=2;
        this.array = new Object[capacity];
        this.size = 0;
    }

    // Add Element in Resizeable Array
    public void add(T element) {
        ensureCapacity();
        array[size++] = element;
    }

    // Remove Element from the index
    public void remove(int index) {
        
        // Index out bound Exception
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(
                "Array Index OutOfBound Exception occurred");
        }

        // Use arraycopy to shift elements 
        // and remove the specified element
        System.arraycopy(array, index + 1, array, index, size - index - 1);
        
        // Set the last element to 
        // null and decrement the size
        array[--size] = null;

        if (size > 0 && size == capacity / 4) {
            resize(capacity / 2); // Shrink the array if too empty
        }
        
    }

    // Method to get the current size of the array
    public int size() {
        return size;
    }

    // Method to Ensure the Capacity of the Array
    private void ensureCapacity() {

        // If the size equals the 
        // array length, double the capacity
        if (size == array.length) {
            resize(capacity*2);
        }
    }

    // Resize the internal array
    private void resize(int newCapacity) {
        Object[] newArray = new Object[newCapacity];

        // Copy elements to the new array
        for(int i = 0; i < size; i++) {
            newArray[i] = array[i]; 
        }

        // Replace the old array with the new one
        array = newArray; 

        // Update the capacity
        capacity = newCapacity; 
    }

    // Get an element by index
    public Object get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(
                "Index out of bounds");
        }
        return array[index];
    }

    // Override toString method to
    // display the contents of the array
    @Override
    public String toString() {
        // Use Arrays.toString to create
        // a string representation of the array
        return Arrays.toString(Arrays.copyOf(array, size));
    }
}