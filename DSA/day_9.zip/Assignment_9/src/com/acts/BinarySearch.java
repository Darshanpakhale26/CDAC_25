package com.acts;

import java.util.Scanner;

public class BinarySearch {

	private static boolean findUsingBinarySearch(int[] arr, int element) {

		int low = 0;
		int high = arr.length - 1;

		while (low < high) {
			int mid = low + (high - low) / 2;

			if (arr[mid] == element) {
				return true;
			}
			if (arr[mid] < element) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
		return false;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		int[] nums = { 10, 20, 30, 40, 50, 60 };

		System.out.println("Enter element: ");
		int element = sc.nextInt();

		boolean result = findUsingBinarySearch(nums, element);

		if (result) {
			System.out.println("Element is found");
		} else {
			System.out.println("Element is not found");
		}
		sc.close();

	}

}

//
//3. Implement the following function to sort the given array in descending order, using Bubble Sort
//void bubbleSort(int[] arr);
//Use the algorithm described in class to start from left side of array, to move smallest element towards the right end.
//
//4. Implement the following function to sort the given array in descending order, using Insertion Sort
//void insertionSort(int[] arr);
//
//5. Implement the following function to check if given array elements are sorted or not.
//boolean isArraySorted(int[] arr);
//Hint: Use logic used in bubble sort.
