//5. Implement the following function to check if given array elements are sorted or not.
//boolean isArraySorted(int[] arr);
//Hint: Use logic used in bubble sort.

package com.acts;

public class IsArraySorted {

	private static boolean isArraySorted(int[] arr) {

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < arr[i + 1]) {
				return true;
			}
		}
		return false;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int[] nums = { 10, 5, 15, 2, 40, 8 };
		int[] nums = { 10,20,30,40,50,60};

		boolean result = isArraySorted(nums);

		if (result) {
			System.out.println("Array is sorted");
		} else {
			System.out.println("Array is not sorted");
		}

	}

}
