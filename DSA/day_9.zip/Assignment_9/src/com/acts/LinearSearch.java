package com.acts;

import java.util.Scanner;

public class LinearSearch {

	private static boolean findUsingLinearSearch(int[] arr, int element) {
//		boolean isFound = false;
		
	

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == element) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc  = new Scanner(System.in);
		
		int[] nums = { 10, 5, 15, 2, 40, 8 };
		
		System.out.println("Enter element: ");
		int element = sc.nextInt();

		boolean result = findUsingLinearSearch(nums, element );

		if (result) {
			System.out.println("Element is found");
		} else {
			System.out.println("Element is not found");
		}
		sc.close();

	}

}
