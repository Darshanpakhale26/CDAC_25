//3. Implement the following function to sort the given array in descending order, using Bubble Sort
//void bubbleSort(int[] arr);
//Use the algorithm described in class to start from left side of array, to move smallest element towards the right end.

package com.acts;

public class BubbleSort {
	public static void bubbleSort(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] < arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
			System.out.print(arr[i]);
			System.out.print(" ");

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] nums = { 10, 5, 15, 2, 40, 8 };
		bubbleSort(nums);

	}

}
