public class Main {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);

        System.out.print("List elements: ");
        list.print();

        System.out.println("Is 20 present? " + list.search(20)); // true
        System.out.println("Is 50 present? " + list.search(50)); // false
    }
}
