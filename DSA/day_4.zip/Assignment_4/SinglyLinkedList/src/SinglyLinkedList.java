public class SinglyLinkedList {
    private Node head;

    public void add(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void delete(int element) {
        Node current = head, prev = null;
        while (current != null) {
            if (current.data == element) {
                if (prev == null) {
                    head = current.next;
                } else {
                    prev.next = current.next;
                }
                return;
            }
            prev = current;
            current = current.next;
        }
    }

    public void deleteAll(int element) {
        while (head != null && head.data == element) {
            head = head.next;
        }
        Node current = head, prev = null;
        while (current != null) {
            if (current.data == element) {
                prev.next = current.next;
            } else {
                prev = current;
            }
            current = current.next;
        }
    }

    public boolean search(int element) {
        Node current = head;
        while (current != null) {
            if (current.data == element)
                return true;
            current = current.next;
        }
        return false;
    }

    public void print() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
