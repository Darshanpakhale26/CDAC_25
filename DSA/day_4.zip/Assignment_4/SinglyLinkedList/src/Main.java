public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.add(2);
        list.add(3);
        list.add(2);
        list.add(4);
        list.add(2);

        System.out.print("Original list: ");
        list.print();

        list.delete(4);
        System.out.print("After deleting 4: ");
        list.print();

        list.deleteAll(2);
        System.out.print("After deleting all 2s: ");
        list.print();

        System.out.println("Is 3 present? " + list.search(3));
        System.out.println("Is 8 present? " + list.search(8));
    }
}
