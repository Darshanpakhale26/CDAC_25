package org.cdac;

class DoublyLinkedList {
	Node head;
	Node tail;

	public DoublyLinkedList() {
		this.head = null;
		this.tail = null;
	}

   //add data
	public void add(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
		}
	}

   // Print List
	public void printList() {
		Node current = head;
		while (current != null) {
			System.out.print(current.data + " <-> ");
			current = current.next;
		}
		System.out.println("null");
	}

	// delete specific element
	public void delete(int element) {
		Node current = head;

		while (current != null) {
			if (current.data == element) {

				if (current == head) {
					head = current.next;
					if (head != null) {
						head.prev = null;
					} else {
						tail = null;
					}
				}

				else if (current == tail) {
					tail = current.prev;
					if (tail != null) {
						tail.next = null;
					} else {
						head = null;
					}
				}

				else {
					current.prev.next = current.next;
					current.next.prev = current.prev;
				}

				return;
			}
			current = current.next;
		}
	}

	// delete all occurrences of element
	public void deleteAll(int element) {
		Node current = head;
		Node nextNode;

		while (current != null) {
			nextNode = current.next;

			if (current.data == element) {

				if (current == head) {
					head = nextNode;
					if (head != null) {
						head.prev = null;
					} else {
						tail = null;
					}
				}

				else if (current == tail) {
					tail = current.prev;
					if (tail != null) {
						tail.next = null;
					} else {
						head = null;
					}
				}

				else {
					current.prev.next = current.next;
					current.next.prev = current.prev;
				}
			}
			current = nextNode;
		}
	}
}