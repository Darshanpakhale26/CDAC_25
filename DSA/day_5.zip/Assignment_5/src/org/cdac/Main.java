package org.cdac;

public class Main {
	public static void main(String[] args) {
		DoublyLinkedList list = new DoublyLinkedList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(2);
		list.add(4);
		list.add(2);

		System.out.println("list:");
		list.printList();

		list.delete(3);
		System.out.println("After deleting 3: ");
		list.printList();

//		list.delete(1);
//		System.out.println("After deleting 1:");
//		list.printList();
//
//		list.delete(2);
//		System.out.println("After deleting 2 :");
//		list.printList();

		
		// Add element into list
		
		list = new DoublyLinkedList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(2);
		list.add(4);
		list.add(2);
		System.out.println("\nOriginal list:");
		list.printList();

		list.deleteAll(2);
		System.out.println("After deleting all occurrences of 2:");
		list.printList();

//		list.deleteAll(1);
//		System.out.println("After deleting all occurrences of 1:");
//		list.printList();
//
//		list.deleteAll(5);
//		System.out.println("After deleting non-existent element 5:");
//		list.printList();
	}
}