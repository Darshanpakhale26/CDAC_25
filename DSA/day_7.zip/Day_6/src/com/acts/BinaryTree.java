package com.acts;

public class BinaryTree {
    Node root;

    public BinaryTree() {
        root = null;
    }

    // --- 1. Insertion (Implemented using standard Binary Search Tree logic) ---

    public void insert(int data) {
        root = insertRec(root, data);
    }

    private Node insertRec(Node root, int data) {
        // If the tree is empty, return a new node
        if (root == null) {
            root = new Node(data);
            return root;
        }

        // Otherwise, recur down the tree
        if (data < root.data) {
            root.left = insertRec(root.left, data);
        } else if (data > root.data) {
            root.right = insertRec(root.right, data);
        }
        // Note: Duplicates are ignored for simplicity in this BST implementation

        return root;
    }

    // --- 2. Traversal Methods (Requested in point 1 and for menu) ---

    // Public method for Preorder traversal
    public void printUsingPreorder() {
        System.out.print("Preorder Traversal: ");
        preorderRec(root);
        System.out.println();
    }

    // Private recursive helper for Preorder (Root -> Left -> Right)
    private void preorderRec(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }

    // Public method for Postorder traversal (Requested in point 1)
    public void printUsingPostorder() {
        System.out.print("Postorder Traversal: ");
        postorderRec(root);
        System.out.println();
    }

    // Private recursive helper for Postorder (Left -> Right -> Root)
    private void postorderRec(Node root) {
        if (root != null) {
            postorderRec(root.left);
            postorderRec(root.right);
            System.out.print(root.data + " ");
        }
    }
    
    // Public method for Inorder traversal (for menu completeness)
    public void printUsingInorder() {
        System.out.print("Inorder Traversal: ");
        inorderRec(root);
        System.out.println();
    }

    // Private recursive helper for Inorder (Left -> Root -> Right)
    private void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }


    // --- 3. Count Nodes (Requested in point 2) ---

    /**
     * @return The total number of nodes in the binary tree.
     */
    public int CountNodes() {
        return countNodesRec(root);
    }

    // Private recursive helper to count all nodes
    private int countNodesRec(Node node) {
        if (node == null) {
            return 0;
        }
        // Count 1 for the current node + recursive counts from left and right children
        return 1 + countNodesRec(node.left) + countNodesRec(node.right);
    }

    // --- 4. Count Leaf Nodes (Requested in point 3) ---

    /**
     * @return The number of leaf nodes (nodes with no children) in the tree.
     */
    public int CountLeafNodes() {
        return countLeafNodesRec(root);
    }

    // Private recursive helper to count leaf nodes
    private int countLeafNodesRec(Node node) {
        if (node == null) {
            return 0;
        }
        // A node is a leaf if both left and right are null
        if (node.left == null && node.right == null) {
            return 1;
        }
        // Otherwise, return the sum of leaf nodes in the left and right subtrees
        return countLeafNodesRec(node.left) + countLeafNodesRec(node.right);
    }

    // --- 5. Count Nodes with Specific Value (Requested in point 4) ---

    /**
     * @param value The specific data value to search for.
     * @return The number of nodes in the tree that contain the given value.
     */
    public int CountNodesWithValue(int value) {
        return countNodesWithValueRec(root, value);
    }

    // Private recursive helper to count nodes with a specific value
    private int countNodesWithValueRec(Node node, int value) {
        if (node == null) {
            return 0;
        }
        
        int count = 0;
        // Check if the current node matches the value
        if (node.data == value) {
            count = 1;
        }

        // Add counts from left and right subtrees
        count += countNodesWithValueRec(node.left, value);
        count += countNodesWithValueRec(node.right, value);
        
        return count;
    }
}