package com.acts;

import java.util.Scanner;

public class BinaryTreeApp {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		BinaryTree tree = new BinaryTree();
		int choice;

		System.out.println("--- Binary Tree Operations Menu ---");

		do {
			System.out.println("\nSelect an operation:");
			System.out.println("1. Add Node Data (BST Insertion)");
			System.out.println("2. Traversal: Preorder");
			System.out.println("3. Traversal: Inorder");
			System.out.println("4. Traversal: Postorder");
			System.out.println("5. Count All Nodes");
			System.out.println("6. Count Leaf Nodes");
			System.out.println("7. Count Nodes with Specific Value");
			System.out.println("8. Exit");
			System.out.print("Enter your choice (1-8): ");

			if (scanner.hasNextInt()) {
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					System.out.print("Enter integer value to add: ");
					if (scanner.hasNextInt()) {
						int data = scanner.nextInt();
						tree.insert(data);
						System.out.println("Node with value " + data + " added.");
					} else {
						System.out.println("Invalid input. Please enter an integer.");
						scanner.next(); // Consume invalid input
					}
					break;
				case 2:
					tree.printUsingPreorder();
					break;
				case 3:
					tree.printUsingInorder();
					break;
				case 4:
					tree.printUsingPostorder();
					break;
				case 5:
					System.out.println("Total Nodes in Tree: " + tree.CountNodes());
					break;
				case 6:
					System.out.println("Total Leaf Nodes in Tree: " + tree.CountLeafNodes());
					break;
				case 7:
					System.out.print("Enter the value to count: ");
					if (scanner.hasNextInt()) {
						int valueToCount = scanner.nextInt();
						int count = tree.CountNodesWithValue(valueToCount);
						System.out.println("Nodes with value " + valueToCount + ": " + count);
					} else {
						System.out.println("Invalid input. Please enter an integer.");
						scanner.next(); // Consume invalid input
					}
					break;
				case 8:
					System.out.println("Exiting program. Goodbye!");
					break;
				default:
					System.out.println("Invalid choice. Please enter a number between 1 and 8.");
				}
			} else {
				System.out.println("Invalid input. Please enter a number.");
				scanner.next(); // Consume invalid input
				choice = 0; // Set choice to an invalid number to continue loop
			}

		} while (choice != 8);

		scanner.close();
	}
}
