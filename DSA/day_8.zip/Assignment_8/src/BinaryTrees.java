// BinarySearchTree.java
import java.util.NoSuchElementException;

public class BinaryTrees {
    TreeElement root;

    public void insert(int key) {
        root = insertRec(root, key);
    }

    private TreeElement insertRec(TreeElement root, int key) {
        if (root == null) {
            return new TreeElement(key);
        }
        if (key < root.key) {
            root.left = insertRec(root.left, key);
        } else if (key > root.key) {
            root.right = insertRec(root.right, key);
        }
        return root;
    }

    private TreeElement findInorderPredecessor(TreeElement node) {
        TreeElement current = node.left;
        while (current.right != null) {
            current = current.right;
        }
        return current;
    }

    private TreeElement deleteNode(TreeElement root, int key) {
        if (root == null) {
            return null;
        }
        if (key < root.key) {
            root.left = deleteNode(root.left, key);
        } else if (key > root.key) {
            root.right = deleteNode(root.right, key);
        } else {
            if (root.left == null && root.right == null) {
                return null;
            } else if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            } else {
                TreeElement pred = findInorderPredecessor(root);
                root.key = pred.key;
                root.left = deleteNode(root.left, pred.key);
            }
        }
        return root;
    }

    public void delete(int key) {
        root = deleteNode(root, key);
    }

    public void inorderTraversal(TreeElement root) {
        if (root != null) {
            inorderTraversal(root.left);
            System.out.print(root.key + " ");
            inorderTraversal(root.right);
        }
    }

    public static void main(String[] args) {
        BinaryTrees tree = new BinaryTrees();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        System.out.print("Original BST (inorder): ");
        tree.inorderTraversal(tree.root);
        System.out.println();

        tree.delete(50);

        System.out.print("BST after deleting 50 (inorder): ");
        tree.inorderTraversal(tree.root);
        System.out.println();
    }
}
