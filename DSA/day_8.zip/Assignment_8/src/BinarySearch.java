// BinarySearchTree.java
import java.util.NoSuchElementException;

public class BinarySearch {
    BSTNode root;

    // Insert method
    public void insert(int key) {
        root = insertRec(root, key);
    }

    private BSTNode insertRec(BSTNode root, int key) {
        if (root == null) {
            root = new BSTNode(key);
            return root;
        }
        if (key < root.key)
            root.left = insertRec(root.left, key);
        else if (key > root.key)
            root.right = insertRec(root.right, key);
        return root;
    }

    // Find smallest element
    public int findSmallest() {
        if (root == null) {
            throw new NoSuchElementException("The tree is empty");
        }
        BSTNode current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current.key;
    }

    // Find largest element
    public int findLargest() {
        if (root == null) {
            throw new NoSuchElementException("The tree is empty");
        }
        BSTNode current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current.key;
    }

    public static void main(String[] args) {
        BinarySearch tree = new BinarySearch();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);
        
        System.out.println("Smallest element in the BST is: " + tree.findSmallest());
        System.out.println("Largest element in the BST is: " + tree.findLargest());
    }
}
