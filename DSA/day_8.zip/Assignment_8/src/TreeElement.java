// TreeElement.java
public class TreeElement {
    int key;
    TreeElement left, right;

    public TreeElement(int item) {
        key = item;
        left = right = null;
    }
}
