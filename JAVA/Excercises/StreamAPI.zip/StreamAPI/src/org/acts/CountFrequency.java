package org.acts;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountFrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String text = "apple banana apple orange apple";
		Map<String, Long> wordFrequencies = Arrays.stream(text.toLowerCase().split("\\s+"))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		wordFrequencies
				.forEach((word, count) -> System.out.println("Word: '" + word + "' appears " + count + " time(s)."));

	}

}
