package org.acts;

import java.util.Arrays;

public class RepeatedCharEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "fullstackjavadeveloer";

		char arr[] = str.toLowerCase().toCharArray();
		System.out.println(arr);
		Arrays.sort(arr);

		System.out.println(arr);

		for (int i = 0; i < arr.length; i++) {
			int count = 1;
			char temp = arr[i];

			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
					i++;
				}
			}

			if (count > 1) {
				System.out.println(temp + ": " + count);
			}

		}

	}

}
