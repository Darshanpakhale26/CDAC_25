package org.acts;

public class StringBascis {
	public static void main(String[] args) {
		String s1 = "CDAC";
		String s2 =  new String("CDAC");
		
		System.out.println(s1 == s2);
		
		System.out.println(s1.equals(s2));
		
		System.out.println(s1.length());
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(s1.charAt(2));
		System.out.println(s1.concat(s2));
		System.out.println(s1.compareTo(s2));
		
		
		
		
		
		
	}

}
