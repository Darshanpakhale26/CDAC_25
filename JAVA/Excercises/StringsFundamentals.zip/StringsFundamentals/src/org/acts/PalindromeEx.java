package org.acts;

public class PalindromeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String originalStr = "Naman";
		
		String reverseStr = "";
		
		for (int iTemp = originalStr.length() - 1; iTemp >= 0; iTemp--) {

			reverseStr = reverseStr + originalStr.charAt(iTemp);
		}
		
		System.out.println(reverseStr);
		
		
		if(originalStr.equalsIgnoreCase(reverseStr)) {
			System.out.println("String is Palindrome");
		}
		else {
			System.out.println("String is not palindrome");
		}

	}

}
