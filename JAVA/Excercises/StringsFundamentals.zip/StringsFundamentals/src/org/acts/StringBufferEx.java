package org.acts;

public class StringBufferEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer b1 = new StringBuffer("java");
		StringBuffer b2 = new StringBuffer("java");
		
		b1.append(b2);  // muable
		System.out.println(b1);
		

	}

}
