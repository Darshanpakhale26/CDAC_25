package org.acts;

public class StringBuilderEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuilder b1 = new StringBuilder("React");
		StringBuilder b2 = new StringBuilder("React");
		
		b1.append(b2);
		
		System.out.println(b1);
		System.out.println(b2.reverse());
		

	}

}
