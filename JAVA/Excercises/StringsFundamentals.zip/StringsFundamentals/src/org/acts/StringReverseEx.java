package org.acts;

public class StringReverseEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "Darshan";

		for (int iTemp = name.length() - 1; iTemp >= 0; iTemp--) {

			System.out.print(name.charAt(iTemp));
		}

	}

}
