/**
 * 
 */
/**
 * 
 */
module StringsFundamentals {
}