package org.acts;

import java.util.Scanner;

public class FoodBillingSystem {

    // Hard-coded prices for the food items
    private static final double PRICE_DOSA = 50.00;
    private static final double PRICE_SAMOSA = 15.00;
    private static final double PRICE_IDLI = 40.00;
    private static final double PRICE_VADAPAV = 20.00;
    private static final double PRICE_COFFEE = 35.00;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalBill = 0.0;
        int choice;

        System.out.println("=========================================");
        System.out.println("      🍔 Welcome to the Cafe! ☕");
        System.out.println("=========================================");

        // Loop to continuously display the menu and take orders
        do {
            displayMenu();
            
            // Check if the input is an integer
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                
                // If the user enters an item choice (1-5)
                if (choice >= 1 && choice <= 5) {
                    System.out.print("Enter quantity for item " + choice + ": ");
                    if (scanner.hasNextInt()) {
                        int quantity = scanner.nextInt();
                        if (quantity > 0) {
                            double itemCost = calculateItemCost(choice, quantity);
                            totalBill += itemCost;
                            System.out.printf("✅ Added %d item(s). Subtotal: ₹%.2f\n", quantity, totalBill);
                        } else {
                            System.out.println("⚠️ Quantity must be greater than zero.");
                        }
                    } else {
                        System.out.println("❌ Invalid quantity input. Please try again.");
                        scanner.next(); // Consume the invalid input
                    }
                } else if (choice == 10) {
                    // Option 10: Generate Bill
                    break; // Exit the do-while loop
                } else {
                    System.out.println("❌ Invalid choice. Please select a valid menu number or 10 to generate bill.");
                }
            } else {
                // Handle non-integer input for the menu choice
                System.out.println("❌ Invalid input. Please enter a number from the menu.");
                scanner.next(); // Consume the invalid input
                choice = -1; // Set choice to an invalid number to continue the loop
            }

            System.out.println("-----------------------------------------");

        } while (true); // Loop runs indefinitely until 'break' is called

        // --- Generate Bill Section (Executed after the loop breaks) ---
        
        System.out.println("\n\n=========================================");
        System.out.println("          🧾 FINAL BILL 🧾");
        System.out.println("=========================================");
        System.out.printf("Your Total Payable Amount is: **₹%.2f**\n", totalBill);
        System.out.println("Thank you for visiting! Have a great day!");
        System.out.println("=========================================");

        scanner.close();
    }

    /**
     * Displays the fixed food menu to the user.
     */
    private static void displayMenu() {
        System.out.println("\n--- Menu ---");
        System.out.printf("1. Dosa \t\t\t (₹%.2f)\n", PRICE_DOSA);
        System.out.printf("2. Samosa \t\t\t (₹%.2f)\n", PRICE_SAMOSA);
        System.out.printf("3. Idli \t\t\t (₹%.2f)\n", PRICE_IDLI);
        System.out.printf("4. Vada Pav \t\t\t (₹%.2f)\n", PRICE_VADAPAV);
        System.out.printf("5. Coffee \t\t\t (₹%.2f)\n", PRICE_COFFEE);
        System.out.println("-----------------------------------------");
        System.out.println("10. **Generate Bill** and Exit");
        System.out.println("-----------------------------------------");
        System.out.print("Enter your choice (1-5 or 10): ");
    }

    /**
     * Calculates the cost of the selected item(s).
     * @param itemChoice The menu number selected by the user.
     * @param quantity The number of items ordered.
     * @return The total cost for the item(s) ordered.
     */
    private static double calculateItemCost(int itemChoice, int quantity) {
        double price = 0.0;
        String itemName = "";

        // Use a switch statement to look up the price
        switch (itemChoice) {
            case 1:
                price = PRICE_DOSA;
                itemName = "Dosa";
                break;
            case 2:
                price = PRICE_SAMOSA;
                itemName = "Samosa";
                break;
            case 3:
                price = PRICE_IDLI;
                itemName = "Idli";
                break;
            case 4:
                price = PRICE_VADAPAV;
                itemName = "Vada Pav";
                break;
            case 5:
                price = PRICE_COFFEE;
                itemName = "Coffee";
                break;
        }

        double cost = price * quantity;
        System.out.printf("Added: %d x %s @ ₹%.2f each. Cost: ₹%.2f\n", quantity, itemName, price, cost);
        return cost;
    }
}
