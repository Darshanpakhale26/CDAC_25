package com.date;

public class ConsoleInput {

	// Read string from console
	public static String getString() {
		try {
			byte[] arrInput = new byte[100];
			int length = System.in.read(arrInput);

			// Remove newline characters
			byte[] arrFinal = new byte[length - 2];
			System.arraycopy(arrInput, 0, arrFinal, 0, length - 2);

			return new String(arrFinal);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// Read integer from console
	public static int getInt() {
		return Integer.parseInt(getString());
	}
}
