package com.date;

public class MyDate {
	private int day, month, year;

	// Constructor
	public MyDate(int day, int month, int year) {
		if (isValidDate(day, month, year)) {
			this.day = day;
			this.month = month;
			this.year = year;
		} else {
			System.out.println("Invalid date, setting default 01/01/2025");
			this.day = 1;
			this.month = 1;
			this.year = 2025;
		}
	}

	// Check if leap year
	public boolean isLeapYear(int y) {
		return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
	}

	// Days in a month
	private int daysInMonth(int m, int y) {
		switch (m) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		case 2:
			return (isLeapYear(y) ? 29 : 28);
		default:
			return 0;
		}
	}

	// Validate date
	private boolean isValidDate(int d, int m, int y) {
		if (y < 1 || m < 1 || m > 12 || d < 1)
			return false;
		return d <= daysInMonth(m, y);
	}

	// Set new date
	public void setDate(int d, int m, int y) {
		if (isValidDate(d, m, y)) {
			this.day = d;
			this.month = m;
			this.year = y;
		} else {
			System.out.println("Invalid date!");
		}
	}

	// Add days
	public void addDays(int d) {
		this.day += d;
		while (this.day > daysInMonth(this.month, this.year)) {
			this.day -= daysInMonth(this.month, this.year);
			this.month++;
			if (this.month > 12) {
				this.month = 1;
				this.year++;
			}
		}
	}

	// Add months
	public void addMonths(int m) {
		this.month += m;
		while (this.month > 12) {
			this.month -= 12;
			this.year++;
		}
		if (this.day > daysInMonth(this.month, this.year)) {
			this.day = daysInMonth(this.month, this.year);
		}
	}

	// Add years
	public void addYears(int y) {
		this.year += y;
		if (this.month == 2 && this.day == 29 && !isLeapYear(this.year)) {
			this.day = 28; // adjust if leap year lost
		}
	}

	// Show date
	public String toString() {
		return day + "/" + month + "/" + year;
	}
}
