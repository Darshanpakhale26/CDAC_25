package com.date;

public class DateApplication {
	public static void main(String[] args) {
		MyDate date = new MyDate(1, 1, 2025);
		int choice;

		do {
			System.out.println("\n===== DATE MENU =====");
			System.out.println("1. Set Date");
			System.out.println("2. Show Date");
			System.out.println("3. Add Days");
			System.out.println("4. Add Months");
			System.out.println("5. Add Years");
			System.out.println("6. Exit");
			System.out.print("Enter choice: ");

			choice = ConsoleInput.getInt();

			switch (choice) {
			case 1:
				System.out.print("Enter day: ");
				int d = ConsoleInput.getInt();
				System.out.print("Enter month: ");
				int m = ConsoleInput.getInt();
				System.out.print("Enter year: ");
				int y = ConsoleInput.getInt();
				date.setDate(d, m, y);
				break;

			case 2:
				System.out.println("Current Date: " + date);
				break;

			case 3:
				System.out.print("Enter days to add: ");
				date.addDays(ConsoleInput.getInt());
				break;

			case 4:
				System.out.print("Enter months to add: ");
				date.addMonths(ConsoleInput.getInt());
				break;

			case 5:
				System.out.print("Enter years to add: ");
				date.addYears(ConsoleInput.getInt());
				break;

			case 6:
				System.out.println("Exiting...");
				break;

			default:
				System.out.println("Invalid choice!");
			}
		} while (choice != 0);
	}
}
