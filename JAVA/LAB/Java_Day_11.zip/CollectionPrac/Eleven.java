package CollectionPrac;

import java.util.TreeSet;

public class Eleven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set = new TreeSet<>();
		set.add("Black");
		set.add("Blue");
		set.add("Yellow");
		set.add("Red");
		
		for(String str : set) {
			System.out.println(str);
		}
	}

}
