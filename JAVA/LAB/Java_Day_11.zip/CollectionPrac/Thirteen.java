package CollectionPrac;

import java.util.NavigableSet;
import java.util.TreeSet;

public class Thirteen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set = new TreeSet<>();
		set.add("Black");
		set.add("Blue");
		set.add("Yellow");
		set.add("Red");
		for(String str : set) {
			System.out.println(str);
			
		}
		System.out.println("---------------------");
		
		NavigableSet<String> reverseSet=set.descendingSet();
		for(String str : reverseSet) {
			System.out.println(str);
		}
		
	}

}
