package CollectionPrac;


import java.util.TreeSet;

public class Twelth {

	public static void main(String[] args) {
	
		TreeSet<String> set = new TreeSet<>();
		set.add("Black");
		set.add("Blue");
		set.add("Yellow");
		set.add("Red");
		for(String str : set) {
			System.out.println(str);
		}
		TreeSet<String> newSet = null;
		try {
			@SuppressWarnings("unchecked")
			TreeSet<String> clonedSet = (TreeSet<String>) set.clone();
			newSet = clonedSet;
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		System.out.println("--------------");
		for(String str : newSet) {
			System.out.println(str);
		}
		
	}

}

