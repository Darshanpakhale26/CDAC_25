package CollectionPrac;

import java.util.Scanner;
import java.util.TreeSet;

public class Fifteen {

    public static void main(String[] args) {
        TreeSet<String> set = new TreeSet<>();

        Scanner scanner = new Scanner(System.in);

        // Adding elements to the TreeSet
        set.add("Black");
        set.add("Blue");
        set.add("Yellow");
        set.add("Red");

        System.out.println("TreeSet elements:");
        for (String str : set) {
            System.out.println(str);
        }

        System.out.println("---------------------");
        System.out.println("Enter String to check:");
        String str1 = scanner.next();

        // Using ceiling method to get element greater than or equal to str1
        String checkString = set.ceiling(str1);

        if (checkString != null) {
            System.out.println("Element greater than or equal to " + str1 + " is " + checkString);
        } else {
            System.out.println("There is no element greater than or equal to " + str1 + " in the TreeSet");
        }

        scanner.close();
    }
}
