package CollectionPrac;

import java.util.ArrayList;
import java.util.Scanner;

public class Third {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		arrayList.add("White");
		arrayList.add("Black");
		arrayList.add("Blue");
		arrayList.add("Green");
		arrayList.add("Red");
		
		System.out.println("enter the position of the element : ");
		int idx = sc.nextInt();
		
		System.out.println(arrayList.get(idx));
		System.out.println("------------------");
		for(String data:arrayList) {
			System.out.println(data+" ");
		}
		
		
		
		sc.close();
}
}
