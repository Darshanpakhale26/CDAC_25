package Assignment_3;


public class SalesPerson extends Employee {

	protected float comission;

    //parameterized constructor
    public SalesPerson(String name,String address,int age,boolean gender,float basicSalary,float comission){
        
        super(name,address,age,gender,basicSalary);

        this.comission = comission;

    }

    //getters
    public float getComission(){
        return comission;
    }

    //setters
    public void setComission(float comission){
    	if(comission < 0) {
    		return ;
    	}
        this.comission = comission;
    }
    
    //calculate salary
    @Override
    public float calculateSalary(){
        return basicSalary + comission;
    }

    @Override
    public String toString() {
        return String.format(
            "***********************************\n" +
            "Salesman Information:\n" +
            "Name         : %s\n" +
            "Address      : %s\n" +
            "Age          : %d\n" +
            "Gender       : %s\n" +
            "Basic Salary : %.2f\n" +
            "comission     : %.2f\n" +
            "Net Salary   : %.2f\n" +
            "***********************************",
            name,
            address,
            age,
            gender ? "Male" : "Female",
            basicSalary,
            comission,
            calculateSalary()
        );
    }

    // Display method
    @Override
    public String display() {
        return toString();
    }

}
