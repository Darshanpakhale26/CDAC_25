package Assignment_3;

import Assignment_1.ConsoleInput;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedList;
//import java.util.Iterator;

public class EmployeeService {
    private LinkedList<Employee> empList = new LinkedList<>();

    // Adding employee to the LinkedList
    public void addEmployee(int choice) {
        System.out.println("enter your name : ");
        String name = ConsoleInput.getString();
        
        System.out.println("enter your address : ");
        String address = ConsoleInput.getString();
        
        System.out.println("enter your age : ");
        int age = ConsoleInput.getInt();
        
        System.out.println("enter your gender : ");
        boolean gender = ConsoleInput.getBoolean();
        
        System.out.println("enter your basic salary : ");
        float basicSalary = ConsoleInput.getFloat();

        Employee employee = null;

        if (choice == 1) {
            System.out.println("enter the HRA : ");
            float hra = ConsoleInput.getFloat();
            employee = new Manager(name, address, age, gender, basicSalary, hra);
            System.out.println("Manager added successfully.");
        } else if (choice == 2) {
            System.out.println("enter the overtime : ");
            float overtime = ConsoleInput.getFloat();
            employee = new Engineer(name, address, age, gender, basicSalary, overtime);
            System.out.println("Engineer added successfully.");
        } else {
            System.out.println("enter the Commission : ");
            float commission = ConsoleInput.getFloat();
            employee = new SalesPerson(name, address, age, gender, basicSalary, commission);
            System.out.println("Salesperson added successfully.");
        }

        empList.add(employee);
    }

    // Display employees by designation
    public void display(int choice) {
        if (empList.isEmpty()) {
            System.out.println("No employees to display.");
            return;
        }

        boolean found = false;
        for (Employee emp : empList) {
            if (
                (choice == 1 && emp instanceof Manager) ||
                (choice == 2 && emp instanceof Engineer) ||
                (choice == 3 && emp instanceof SalesPerson)
            ) {
                System.out.println(emp.toString());
                found = true;
            } else if (choice == 4) {
                System.out.println(emp.toString());
                found = true;
            }
        }
        if (!found) {
            System.out.println("Employee not found.");
        }
    }

    // Sort by name
    public void sortByName(boolean ascending) {
        if (empList.size() <= 1) {
            System.out.println("Not enough employees to sort.");
            return;
        }

        empList.sort((e1, e2) -> {
            String name1 = e1.getName().toLowerCase();
            String name2 = e2.getName().toLowerCase();
            int cmp = name1.compareTo(name2);
            return ascending ? cmp : -cmp;
        });

        System.out.println("Employees sorted by name.");
    }

    // Sort only by designation (local sort for matching designation)
    public void sortByDesignation(int choice) {
        if (empList.isEmpty()) {
            System.out.println("No employees to sort.");
            return;
        }

        empList.sort((e1, e2) -> {
            boolean m1 = matchesDesignation(e1, choice);
            boolean m2 = matchesDesignation(e2, choice);
            if (m1 && m2) {
                return e1.getName().toLowerCase().compareTo(e2.getName().toLowerCase());
            }
            // Non-matching-designations don't swap places
            return 0;
        });
        System.out.println("Employees of chosen designation sorted by name.");
    }

    private boolean matchesDesignation(Employee e, int choice) {
        return (choice == 1 && e instanceof Manager) ||
                (choice == 2 && e instanceof Engineer) ||
                (choice == 3 && e instanceof SalesPerson);
    }

    // Save to CSV
    public void saveToCSV(String filename) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            for (Employee emp : empList) {
                if (emp instanceof Manager) {
                    Manager m = (Manager) emp;
                    pw.printf("Manager,%s,%s,%d,%b,%.2f,%.2f%n",
                        m.getName(), m.getAddress(), m.getAge(), m.getGender(), m.getBasicSalary(), m.getHra());
                } else if (emp instanceof Engineer) {
                    Engineer e = (Engineer) emp;
                    pw.printf("Engineer,%s,%s,%d,%b,%.2f,%.2f%n",
                        e.getName(), e.getAddress(), e.getAge(), e.getGender(), e.getBasicSalary(), e.getOvertime());
                } else if (emp instanceof SalesPerson) {
                    SalesPerson s = (SalesPerson) emp;
                    pw.printf("SalesPerson,%s,%s,%d,%b,%.2f,%.2f%n",
                        s.getName(), s.getAddress(), s.getAge(), s.getGender(), s.getBasicSalary(), s.getComission());
                }
            }
            System.out.println("Employee list saved to CSV.");
        } catch (IOException e) {
            System.out.println("Error saving CSV: " + e.getMessage());
        }
    }

    // Load from CSV
    public void loadFromCSV(String filename) {
        empList.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(",");
                String type = tokens[0];
                String name = tokens[1];
                String address = tokens[2];
                int age = Integer.parseInt(tokens[3]);
                boolean gender = Boolean.parseBoolean(tokens[4]);
                float basicSalary = Float.parseFloat(tokens[5]);
                if ("Manager".equals(type)) {
                    float hra = Float.parseFloat(tokens[6]);
                    empList.add(new Manager(name, address, age, gender, basicSalary, hra));
                } else if ("Engineer".equals(type)) {
                    float overtime = Float.parseFloat(tokens[6]);
                    empList.add(new Engineer(name, address, age, gender, basicSalary, overtime));
                } else if ("SalesPerson".equals(type)) {
                    float commission = Float.parseFloat(tokens[6]);
                    empList.add(new SalesPerson(name, address, age, gender, basicSalary, commission));
                }
            }
            System.out.println("Employee list loaded from CSV.");
        } catch (IOException e) {
            System.out.println("Error loading CSV: " + e.getMessage());
        }
    }
}
