package CollectionPrac;
import java.util.ArrayList;
public class First {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<>();
		
		arrayList.add("White");
		arrayList.add("Black");
		arrayList.add("Blue");
		arrayList.add("Green");
		arrayList.add("Red");
		
		for(String data:arrayList) {
			System.out.println(data+" ");
		}
}
}