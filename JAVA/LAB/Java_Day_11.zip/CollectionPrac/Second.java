package CollectionPrac;
import java.util.Scanner;
import java.util.ArrayList;
public class Second {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		arrayList.add("White");
		arrayList.add("Black");
		arrayList.add("Blue");
		arrayList.add("Green");
		arrayList.add("Red");
		
		for(String data:arrayList) {
			System.out.println(data+" ");
		}
		System.out.println("enter the string : ");
		String str = sc.next();
		arrayList.add(0, str);
		
		for(String data:arrayList) {
			System.out.println(data+" ");
		}
		
		sc.close();
}
}
