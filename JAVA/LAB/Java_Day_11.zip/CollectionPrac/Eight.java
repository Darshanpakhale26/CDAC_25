package CollectionPrac;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Eight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<>();
		ArrayList<String> newArrayList = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		arrayList.add("White");
		arrayList.add("Pink");
		arrayList.add("Black");
		arrayList.add("Blue");
		arrayList.add("Green");
		for(String data:arrayList) {
			System.out.println(data+" ");
		}
		for (int i = 0; i < arrayList.size(); i++) {
	            newArrayList.add("");  
	    }
		Collections.copy(newArrayList, arrayList);
		System.out.println("------------------");
		for(String data:newArrayList) {
			System.out.println(data+" ");
		}
		
		
		
		sc.close();
	}

}
