package org.cdac;

class Entry
{
 
 public static void main (String[] args)
 {
 
   
	 EqualsHashEx g1 = new EqualsHashEx("aa", 1);
	 EqualsHashEx g2 = new EqualsHashEx("aa", 1);
     
     
     if(g1.hashCode() == g2.hashCode())
     {

         if(g1.equals(g2))
             System.out.println("Both Objects are equal. ");
         else
             System.out.println("Both Objects are not equal. ");
 
     }
     else
     System.out.println("Both Objects are not equal. "); 
     
     
     System.out.println(g1.toString());
     System.out.println(g2.toString());
     
     System.out.println(g1.hashCode());
     System.out.println(g2.hashCode());
     
     
     
     
 }
 
 
 
}

