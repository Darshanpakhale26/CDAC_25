package org.cdac;

class EqualsHashEx {

	public String name;
	public int id;

	EqualsHashEx(String name, int id) {

		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	

	@Override
	public String toString() {
		return "EqualsHashEx [name=" + name + ", id=" + id + "]";
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;

		if (obj == null || obj.getClass() != this.getClass())
			return false;

		EqualsHashEx example = (EqualsHashEx) obj;

		
		return (example.name == this.name && example.id == this.id);
	}

	@Override
	public int hashCode() {

		return this.id;
	}

}
