package com.example.helloworld;

public class CommandLineArgs {

	 public static void main(String[] args) {
	        System.out.println("Total Command Line Arguments: " + args.length);
	        for (int i = 0; i < args.length; i++) {
	            System.out.println("Argument " + i + ": " + args[i]);
	        }
	    }

}
