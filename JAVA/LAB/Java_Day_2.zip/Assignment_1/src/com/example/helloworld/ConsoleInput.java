package com.example.helloworld;

public class ConsoleInput {

    // Method to read string input
    public static String getString() {
        try {
            byte[] arrInput = new byte[100];
            int length = System.in.read(arrInput);

            // Remove newline characters (\r\n or \n)
            byte[] arrFinal = new byte[length - 2];
            System.arraycopy(arrInput, 0, arrFinal, 0, length - 2);

            return new String(arrFinal);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    // Method to read integer input
    public static int getInt() {
        return Integer.parseInt(getString());
    }

    // Method to read float input
    public static float getFloat() {
        return Float.parseFloat(getString());
    }
}

