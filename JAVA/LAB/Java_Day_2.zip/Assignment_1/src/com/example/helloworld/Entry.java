package com.example.helloworld;

public class Entry {
    public static void main(String[] args) {
        System.out.print("Enter a string: ");
        String str = ConsoleInput.getString();
        System.out.println("You entered: " + str);

        System.out.print("Enter an integer: ");
        int num = ConsoleInput.getInt();
        System.out.println("You entered: " + num);

        System.out.print("Enter a float: ");
        float f = ConsoleInput.getFloat();
        System.out.println("You entered: " + f);
    }
}

