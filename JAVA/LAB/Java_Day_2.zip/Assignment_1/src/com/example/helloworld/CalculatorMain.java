package com.example.helloworld;

public class CalculatorMain {
	public static void main(String[] args) {
		int choice;
		do {
			System.out.println("\n===== SIMPLE CALCULATOR =====");
			System.out.println("1. Addition");
			System.out.println("2. Subtraction");
			System.out.println("3. Multiplication");
			System.out.println("4. Division");
			System.out.println("5. Exit");
			System.out.print("Enter your choice: ");

			choice = ConsoleInput.getInt();

			if (choice >= 1 && choice <= 4) {
				System.out.print("Enter first number: ");
				int num1 = ConsoleInput.getInt();

				System.out.print("Enter second number: ");
				int num2 = ConsoleInput.getInt();

				switch (choice) {
				case 1:
					System.out.println("Result = " + (num1 + num2));
					break;
				case 2:
					System.out.println("Result = " + (num1 - num2));
					break;
				case 3:
					System.out.println("Result = " + (num1 * num2));
					break;
				case 4:
					if (num2 != 0)
						System.out.println("Result = " + (num1 / num2));
					else
						System.out.println("Error! Division by zero.");
					break;
				}
			} else if (choice == 5) {
				System.out.println("Exiting program...");
			} else {
				System.out.println("Invalid choice! Try again.");
			}
		} while (choice != 5);
	}
}
