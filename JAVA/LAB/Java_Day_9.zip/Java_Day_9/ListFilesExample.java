package Assignment_9;

import java.io.File;

public class ListFilesExample {
    public static void main(String[] args) {
        File dir = new File("C:\\Users\\Atharva Naik\\OneDrive\\Desktop\\core_java");
        String[] names = dir.list();
        if (names != null) {
            for (String name : names) System.out.println(name);
        }
    }
}
