package Assignment_9;

import java.io.*;

public class FileExistsCheck {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\Atharva Naik\\OneDrive\\Desktop\\core_java");
        System.out.println(f.exists() ? "Exists" : "Does not Exist");
    }
}

