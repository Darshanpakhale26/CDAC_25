package Assignment_3;
public abstract class Employee {
	 	protected String name;

	    protected String address;

	    protected int age;

	    protected boolean gender;

	    protected float basicSalary;

	    //parameterized constructor
	    public Employee(String name,String address,int age,boolean gender,float basicSalary){
	        super();

	        this.name = name;
	        this.address = address;
	        this.age = age;
	        this.gender = gender;
	        this.basicSalary = basicSalary;

	    }
	    //getters
	    public String getName(){
	    	
	        return name;
	    } 

	    public String getAddress(){
	        return address;
	    }

	    public int getAge(){
	        return age;
	    }

	    public boolean getGender(){
	        return gender;
	    }

	    public float getBasicSalary(){
	        return basicSalary;
	    }

	    //setters
	    public void setName(String name){
	    	 if (name == null || name.trim().isEmpty()) {
	    		 return ;
	         }
	         this.name = name.trim();
	    }

	    public void setAddress(String address){
	    	 if (address == null || address.trim().isEmpty()) {
	    		 return ;
	         }
	         this.address = address.trim();
	    }

	    public void setAge(int age){
	    	 if (age <= 0 || age > 120) {
	    		 return ;
	         }
	         this.age = age;
	    }

	    public void setGender(boolean gender){
	    	if(gender != true || gender != false) {
	    		return ;
	    	}
	         this.gender = gender;
	    }

	    public void setBasicSalary(float basicSalary){
	    	if (basicSalary < 0) {
	    		return ;
	        }
	        this.basicSalary = basicSalary;
	    }
	    
	    //calculate salary 
	    public abstract float calculateSalary();
	    
		//display method
	     @Override
    	public String toString() {
        	return String.format(
           		"Employee Information:\n" +
            	"Name         : %s\n" +
            	"Address      : %s\n" +
            	"Age          : %d\n" +
            	"Gender       : %s\n" +
            	"Basic Salary : %.2f\n" +
            	"Net Salary   : %.2f",
            	name,
            	address,
            	age,
            	gender ? "Male" : "Female",
            	basicSalary,
            	calculateSalary()
        );
    }

    	// Display method using toString
   		public String display() {
        	return toString();
    	}
}
