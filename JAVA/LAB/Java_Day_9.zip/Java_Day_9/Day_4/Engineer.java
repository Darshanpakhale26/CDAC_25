package Assignment_3;
public class Engineer extends Employee {

	 protected float overtime;

	 	//parameterized constructor
	    public Engineer(String name,String address,int age,boolean gender,float basicSalary,float overtime){
	        
	        super(name,address,age,gender,basicSalary);

	        this.overtime = overtime;

	    }

	    //getters
	    public float getOvertime(){
	        return overtime;
	    }

	    //setters
	    public void setOvertime(float overtime){
	    	if(overtime < 0) {
	    		return ;
	    	}
	        this.overtime = overtime;
	    }
	    
	    //calculate salary
	    @Override
	    public float calculateSalary(){
	        return basicSalary + overtime;
	    }

		@Override
    	public String toString() {
        	return String.format(
            	"***********************************\n" +
            	"Engineer Information:\n" +
            	"Name         : %s\n" +
            	"Address      : %s\n" +
            	"Age          : %d\n" +
            	"Gender       : %s\n" +
            	"Basic Salary : %.2f\n" +
            	"Overtime     : %.2f\n" +
            	"Net Salary   : %.2f\n" +
            	"***********************************",
            	name,
            	address,
            	age,
            	gender ? "Male" : "Female",
            	basicSalary,
            	overtime,
            	calculateSalary()
        	);
    	}

    	// Display method
    	@Override
    	public String display() {
        	return toString();
    	}
}
