package Assignment_3;
import Assignment_1.ConsoleInput;

public class Entry {
    public static void main(String[] args) {
        EmployeeService es = new EmployeeService();
        int choice;
        do {
            System.out.println("\n--- Employee Management ---");
            System.out.println("1 Add");
            System.out.println("2 Display");
            System.out.println("3 Save");
            System.out.println("4 Load");
            System.out.println("5 Sort");
            System.out.println("0 Exit");
            System.out.print("Enter your choice: ");
            choice = ConsoleInput.getInt();

            switch(choice) {
            case 1:
                System.out.println("Add: 1 Manager 2 Engineer 3 Salesman (0 to exit)");
                int addChoice = ConsoleInput.getInt();
                if (addChoice > 0 && addChoice <= 3) {
                    es.addEmployee(addChoice);
                } else if (addChoice != 0) {
                    System.out.println("Invalid add choice.");
                }
                break;

            case 2:
                System.out.println("Display: 1 Manager 2 Engineer 3 Salesman 4 Display All (0 to exit)");
                int dispChoice = ConsoleInput.getInt();
                if (dispChoice > 0 && dispChoice <= 4) {
                    es.display(dispChoice);
                } else if (dispChoice != 0) {
                    System.out.println("Invalid display choice.");
                }
                break;

            case 3:
                es.saveToCSV("employees.csv");
                break;

            case 4:
                es.loadFromCSV("employees.csv");
                break;

            case 5:
                System.out.println("Sort: 1 Name Ascending 2 Name Descending 3 Manager Ascending 4 Engineer Ascending 5 Salesperson Ascending (0 to exit)");
                int sortChoice = ConsoleInput.getInt();
                if (sortChoice == 1) {
                    es.sortByName(true);
                } else if (sortChoice == 2) {
                    es.sortByName(false);
                } else if (sortChoice == 3) {
                    es.sortByDesignation(1);
                } else if (sortChoice == 4) {
                    es.sortByDesignation(2);
                } else if (sortChoice == 5) {
                    es.sortByDesignation(3);
                } else if (sortChoice != 0) {
                    System.out.println("Invalid sort choice.");
                }
                break;

            case 0:
                System.out.println("Thanks for visiting!");
                break;

            default:
                System.out.println("Invalid main menu choice.");
            }
        } while (choice != 0);
    }
}
