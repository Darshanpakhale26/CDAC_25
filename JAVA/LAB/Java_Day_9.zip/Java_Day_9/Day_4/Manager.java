package Assignment_3;

public class Manager extends Employee {
	
	 protected float hra;
	 	
	 
	 	//parameterized constructor
	    public Manager(String name,String address,int age,boolean gender,float basicSalary,float hra){
	        
	        super(name,address,age,gender,basicSalary);

	        this.hra = hra;

	    }

	    //getters
	    public float getHra(){
	        return hra;
	    }

	    //setters
	    public void setHra(float hra){
	    	if(hra < 0) {
	    		return ;
	    	}
	        this.hra = hra;
	    }
	    
	    //calculate salary
	    @Override
	    public float calculateSalary(){
	        return basicSalary + hra;
	    }

		@Override
    	public String toString() {
        	return String.format(
            	"***********************************\n" +
            	"Manager Information:\n" +
            	"Name         : %s\n" +
				"Address      : %s\n" +
            	"Age          : %d\n" +
            	"Gender       : %s\n" +
            	"Basic Salary : %.2f\n" +
            	"hra          : %.2f\n" +
            	"Net Salary   : %.2f\n" +
            	"***********************************",
            	name,
            	address,
            	age,
            	gender ? "Male" : "Female",
            	basicSalary,
            	hra,
            	calculateSalary()
        	);
    	}

    	// Display method
    	@Override
    	public String display() {
        	return toString();
    	}
}
