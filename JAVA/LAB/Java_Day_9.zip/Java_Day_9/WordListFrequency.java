package Assignment_9;

import java.io.*;
import java.util.*;

public class WordListFrequency {
    public static void main(String[] args) throws IOException {
        // Input/output files
        String inputFile = "input.txt"; // Change path as needed
        String outputFile = "output.txt";
        
        // Read words and count occurrences
        Map<String, Integer> wordCounts = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        String line, longestWord = "";
        while ((line = reader.readLine()) != null) {
            String[] words = line.split("\\W+");
            for (String word : words) {
                if (word.isEmpty()) continue;
                word = word.toLowerCase();
                wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
                if(word.length() > longestWord.length()) longestWord = word;
            }
        }
        reader.close();

        // Alphabetical sorting
        List<String> alphaList = new ArrayList<>(wordCounts.keySet());
        Collections.sort(alphaList);

        // Frequency sorting
        List<Map.Entry<String, Integer>> freqList = new ArrayList<>(wordCounts.entrySet());
        freqList.sort((a, b) -> b.getValue().compareTo(a.getValue()));
        
        // Write to output file
        PrintWriter writer = new PrintWriter(new FileWriter(outputFile));
        writer.println("Words in Alphabetical Order (with frequency):");
        for (String word : alphaList) {
            writer.println(word + ": " + wordCounts.get(word));
        }
        
        writer.println("\nWords Sorted By Frequency:");
        for (Map.Entry<String, Integer> entry : freqList) {
            writer.println(entry.getKey() + ": " + entry.getValue());
        }
        writer.println("\nLongest word: " + longestWord);
        writer.close();
    }
}
