package Assignment_9;

import java.io.*;

public class PathTypeCheck {
    public static void main(String[] args) {
        File f = new File("C:\\Users\\Atharva Naik\\OneDrive\\Desktop\\core_java");
        System.out.println(f.isDirectory() ? "Directory" : "Not a Directory");
        System.out.println(f.isFile() ? "File" : "Not a File");
    }
}
