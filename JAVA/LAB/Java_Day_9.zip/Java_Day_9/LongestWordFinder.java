package Assignment_9;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class LongestWordFinder {
    public static void main(String [] args) throws FileNotFoundException {
        String longestWord = "", current;
        Scanner sc = new Scanner(new File("C:\\Users\\Atharva Naik\\OneDrive\\Desktop\\core_java\\Assignment_9\\sample.txt"));
        while (sc.hasNext()) {
            current = sc.next();
            if (current.length() > longestWord.length()) longestWord = current;
        }
        sc.close();
        System.out.println("Longest word: " + longestWord);
    }
}
