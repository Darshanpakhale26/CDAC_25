package Assignment_9;

import java.io.*;
import java.util.*;

public class JavaClassGenerator {
    static class Field {
        String access;
        String type;
        String name;
        Field(String access, String type, String name) {
            this.access = access;
            this.type = type;
            this.name = name;
        }
    }

    static class Method {
        String access;
        String returnType;
        String name;
        List<String> params; // List of "type name"
        Method(String access, String returnType, String name, List<String> params) {
            this.access = access;
            this.returnType = returnType;
            this.name = name;
            this.params = params;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String packageName, className;
        String classAccess;
        List<Field> fields = new ArrayList<>();
        List<Method> methods = new ArrayList<>();

        // Get package name
        System.out.print("Enter package name: ");
        packageName = sc.nextLine();

        // Get class name
        System.out.print("Enter class name: ");
        className = sc.nextLine();

        // Get class access specifier
        System.out.println("Choose class access specifier:\n1. public\n2. default");
        int classAccessOpt = sc.nextInt();
        sc.nextLine();
        classAccess = (classAccessOpt == 1) ? "public" : "";

        // Menu
        while (true) {
            System.out.println("\nMenu:\n1. Add Field\n2. Add Method\n3. Generate Class & Exit");
            int menu = sc.nextInt();
            sc.nextLine();
            if (menu == 1) {
                // Add Field
                System.out.print("Enter data type: ");
                String type = sc.nextLine();
                System.out.println("Choose access specifier:\n1. public\n2. private\n3. protected\n4. default");
                int accOpt = sc.nextInt(); sc.nextLine();
                String access;
                switch (accOpt) {
                    case 1: access = "public"; break;
                    case 2: access = "private"; break;
                    case 3: access = "protected"; break;
                    default: access = ""; break;
                }
                System.out.print("Enter field name: ");
                String name = sc.nextLine();
                fields.add(new Field(access, type, name));
            } else if (menu == 2) {
                // Add Method
                System.out.print("Enter return type: ");
                String returnType = sc.nextLine();
                System.out.println("Choose access specifier:\n1. public\n2. private\n3. protected\n4. default");
                int accOpt = sc.nextInt(); sc.nextLine();
                String access;
                switch (accOpt) {
                    case 1: access = "public"; break;
                    case 2: access = "private"; break;
                    case 3: access = "protected"; break;
                    default: access = ""; break;
                }
                System.out.print("Enter method name: ");
                String methodName = sc.nextLine();
                
                List<String> params = new ArrayList<>();
                System.out.print("Enter number of parameters: ");
                int pCount = sc.nextInt(); sc.nextLine();
                for (int i = 0; i < pCount; i++) {
                    System.out.print("Parameter " + (i+1) + " type: ");
                    String pType = sc.nextLine();
                    System.out.print("Parameter " + (i+1) + " name: ");
                    String pName = sc.nextLine();
                    params.add(pType + " " + pName);
                }
                methods.add(new Method(access, returnType, methodName, params));
            } else if (menu == 3) {
                break;
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }

        // Build class content
        StringBuilder sb = new StringBuilder();
        sb.append("package ").append(packageName).append(";\n\n");
        if (!classAccess.isEmpty()) {
            sb.append(classAccess).append(" ");
        }
        sb.append("class ").append(className).append(" {\n");
        // Fields
        for (Field f : fields) {
            sb.append("    ");
            if (!f.access.isEmpty()) sb.append(f.access).append(" ");
            sb.append(f.type).append(" ").append(f.name).append(";\n");
        }
        sb.append("\n");
        // Methods
        for (Method m : methods) {
            sb.append("    ");
            if (!m.access.isEmpty()) sb.append(m.access).append(" ");
            sb.append(m.returnType).append(" ").append(m.name).append("(");
            for (int i = 0; i < m.params.size(); i++) {
                sb.append(m.params.get(i));
                if (i != m.params.size()-1) sb.append(", ");
            }
            sb.append(") {\n        // TODO: implement\n");
            if (!m.returnType.equals("void")) sb.append("        return;\n");
            sb.append("    }\n");
        }
        sb.append("}\n");

        // Write file
        try {
            String fileName = className + ".java";
            FileWriter fw = new FileWriter(fileName);
            fw.write(sb.toString());
            fw.close();
            System.out.println("Class file '" + fileName + "' generated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        sc.close();
    }
}

