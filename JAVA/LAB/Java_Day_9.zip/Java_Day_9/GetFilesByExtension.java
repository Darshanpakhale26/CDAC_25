package Assignment_9;

import java.io.*;

public class GetFilesByExtension {
    public static void main(String[] args) {
        File dir = new File("C:\\Users\\Atharva Naik\\OneDrive\\Desktop\\core_java");
        String[] extensions = {".java", ".txt"}; // specify desired extensions
        for (String ext : extensions) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(ext));
            if(files != null) for(File f : files) System.out.println(f.getName());
        }
    }
}

