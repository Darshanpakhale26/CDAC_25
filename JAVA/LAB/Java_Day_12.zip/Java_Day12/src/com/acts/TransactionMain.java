package com.acts;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TransactionMain {

	public static void main(String[] args) {

		Collection<Transaction> transactions = new ArrayList<>();
		transactions.add(new Transaction(101, LocalDate.of(2025, 1, 15), 6200.50f, false, true));
		transactions.add(new Transaction(102, LocalDate.of(2025, 2, 20), 4500.00f, true, false));
		transactions.add(new Transaction(103, LocalDate.of(2025, 3, 10), 12500.75f, false, false));
		transactions.add(new Transaction(104, LocalDate.of(2025, 4, 05), 3500.00f, true, true));
		transactions.add(new Transaction(105, LocalDate.of(2025, 5, 25), 8800.25f, false, true));

		System.out.println("All Transactions Loaded:");
		transactions.forEach(System.out::println);
		System.out.println("\n" + "-".repeat(60) + "\n");

		// 1. Getting all Transactions where the txAmount is > 5000
		System.out.println("1. Transactions with Amount > 5000:");

		transactions.stream().filter(t -> t.getTxAmount() > 5000.0f).collect(Collectors.toList())
				.forEach(System.out::println);
		System.out.println();

		// 2. Getting all Transactions where the txStatus is false (Pending)
		System.out.println("2. Transactions with Status = Pending (false):");

		transactions.stream().filter(t -> !t.isTxStatus()).collect(Collectors.toList()).forEach(System.out::println);
		System.out.println();

		Function<Transaction, Float> calculateAmountDue = t -> {
			float amount = t.getTxAmount();
			if (t.isTxArrears()) {
				float arrearsCharge = 500.0f;
				float interest = amount * 0.18f;
				return amount + arrearsCharge + interest;
			} else {
				return amount;
			}
		};

		System.out.println("3. Amount Due Calculation:");
		for (Transaction t : transactions) {
			float amountDue = calculateAmountDue.apply(t);
			System.out.printf("  %s -> Amount Due: %.2f%n", t.toString(), amountDue);
		}
		System.out.println("\n" + "-".repeat(60) + "\n");

		System.out.println("--- Predefined Functional Interface Demonstrations ---");

		String[] colors = { "Blue", "apple", "Zebra", "Cat", "dog" };

		Comparator<String> caseInsensitiveSort = (s1, s2) -> s1.compareToIgnoreCase(s2);
		Arrays.sort(colors, caseInsensitiveSort);
		System.out.println("1. Sorted String Array (Case Insensitive): " + Arrays.toString(colors));

		System.out.println("\n" + "-".repeat(60) + "\n");

		int[] numbers = { 15, 8, 42, 1, 99, 23 };

		Function<int[], Integer> findLargest = arr -> {
			return IntStream.of(arr).max().orElse(Integer.MIN_VALUE);
		};
		System.out.println("2. Largest Number in " + Arrays.toString(numbers) + ": " + findLargest.apply(numbers));

		System.out.println("\n" + "-".repeat(60) + "\n");

		Function<int[], Integer> findSmallest = arr -> {
			return IntStream.of(arr).min().orElse(Integer.MAX_VALUE);
		};
		System.out.println("3. Smallest Number in " + Arrays.toString(numbers) + ": " + findSmallest.apply(numbers));

		System.out.println("\n" + "-".repeat(60) + "\n");

		Supplier<Integer> random3Digit = () -> new Random().nextInt(900) + 100; // Range: 100 to 999
		System.out.println("4. Generated 3-Digit Random Number: " + random3Digit.get());

		System.out.println("\n" + "-".repeat(60) + "\n");

		Function<int[], int[]> reverseArray = arr -> {
			int[] reversed = new int[arr.length];
			for (int i = 0; i < arr.length; i++) {
				reversed[i] = arr[arr.length - 1 - i];
			}
			return reversed;
		};
		int[] originalArray = { 1, 2, 3, 4, 5 };
		int[] reversedArray = reverseArray.apply(originalArray);
		System.out.println(
				"5. Reversed Array of " + Arrays.toString(originalArray) + ": " + Arrays.toString(reversedArray));

		System.out.println("\n" + "-".repeat(60) + "\n");

		Runnable printDate = () -> System.out.println("6. Current Date: " + LocalDate.now());
		printDate.run();

		System.out.println("\n" + "-".repeat(60) + "\n");

		Predicate<Integer> isPrime = n -> {
			if (n <= 1)
				return false;
			for (int i = 2; i <= Math.sqrt(n); i++) {
				if (n % i == 0)
					return false;
			}
			return true;
		};
		int testNumber = 17;
		System.out.println("7. Is " + testNumber + " a Prime Number? " + isPrime.test(testNumber));
		testNumber = 15;
		System.out.println("   Is " + testNumber + " a Prime Number? " + isPrime.test(testNumber));

		System.out.println("\n" + "-".repeat(60) + "\n");

		BiFunction<String, String, String> stringConcatenator = (str1, str2) -> str1 + " " + str2;
		String s1 = "Hello";
		String s2 = "Lambdas";
		System.out.println(
				"8. Concatenated String of '" + s1 + "' and '" + s2 + "': " + stringConcatenator.apply(s1, s2));

		System.out.println("----------OTP Generator-------");

		Supplier<String> generateOTP = () -> {
			String vowels = "AEIOU";
			Random random = new Random();

			// 1. Get a random vowel from the list
			char firstChar = vowels.charAt(random.nextInt(vowels.length()));

			// 2. Generate 4 random digits (0-9)
			StringBuilder otpBuilder = new StringBuilder();
			otpBuilder.append(firstChar);
			for (int i = 0; i < 4; i++) {
				// Append a random digit (0 to 9)
				otpBuilder.append(random.nextInt(10));
			}
			return otpBuilder.toString();
		};
		System.out.println("9. Generated 5-character OTP (Vowel + 4 Digits): " + generateOTP.get());
		System.out.println("   Another example: " + generateOTP.get());

	}
}
