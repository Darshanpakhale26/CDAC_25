package com.acts;

import java.time.LocalDate;

class Transaction {
    private int txId;
    private LocalDate txDate;
    private float txAmount;
    private boolean txStatus; // true for paid, false for pending
    private boolean txArrears; // true if late payment/arrears are present

    public Transaction(int txId, LocalDate txDate, float txAmount, boolean txStatus, boolean txArrears) {
        this.txId = txId;
        this.txDate = txDate;
        this.txAmount = txAmount;
        this.txStatus = txStatus;
        this.txArrears = txArrears;
    }

    // Getters
    public int getTxId() { return txId; }
    public LocalDate getTxDate() { return txDate; }
    public float getTxAmount() { return txAmount; }
    public boolean isTxStatus() { return txStatus; }
    public boolean isTxArrears() { return txArrears; }

    @Override
    public String toString() {
        return String.format("Tx[ID=%d, Date=%s, Amount=%.2f, Status=%s, Arrears=%s]",
                             txId, txDate, txAmount, txStatus ? "Paid" : "Pending", txArrears ? "YES" : "NO");
    }
}