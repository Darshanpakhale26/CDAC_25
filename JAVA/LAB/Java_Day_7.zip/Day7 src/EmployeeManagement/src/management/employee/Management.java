package management.employee;

import java.util.ArrayList;
import java.util.Comparator;
import link.list.LinkedList;
import console.input.Input;

public class Management
{	

	
	public static Employee addEmployee(LinkedList<Employee> listEmployee, int empChoice)
	{
		
		Employee objEmployee=null;
		
		// Taking input for different employees
		System.out.print("Enter Name: ");
		String name = Input.getString();
		
		System.out.print("Enter Address: ");
		String address = Input.getString();
		
		System.out.print("Enter Age: ");
		int age = Input.getInteger();
		
		// Age Validation
		if (age > 80 || age < 18) 
		{
			System.out.println("\nInvalid Age");
			return null;
		}
		
		// Gender Validation
		System.out.print("Enter Gender(M/F): ");
		char gender = Input.getCharacter();
		
		if( gender != 'M' && gender != 'm' && gender != 'F' && gender != 'f' )
		{
			System.out.println("\nInvalid Gender");
			return null;
		}
		
		System.out.print("Enter Basic Salary: ");
		float basicSalary = Input.getFloat();
		
		if(empChoice == 1) //Choice 1 is Manager
		{
			System.out.print("Enter HRA: ");
			float hra = Input.getFloat();
			objEmployee = new Manager(name,address,age,gender,basicSalary,hra);
			
		}
		
		else if(empChoice == 2) //Choice 2 is Engineer
		{
			System.out.print("Enter OverTime: ");
			float overTime = Input.getFloat();
			objEmployee = new Engineer(name,address,age,gender,basicSalary,overTime);
		}
		
		else if(empChoice==3) //Choice 3 is Salesman
		{
			System.out.print("Enter Commission: ");
			float commission = Input.getFloat();
			objEmployee = new Salesman(name,address,age,gender,basicSalary,commission);
		}
		
		System.out.println("\nEmployee added Successfully");
		System.out.println("----------------------------------");
		
		return objEmployee;
	}
	
	// Function to display all the objects in the array
	public static void displayAll(LinkedList<Employee> listEmployee)
	{
		Employee objTemp=listEmployee.getFirst();
		
		while(objTemp!= null) {
			System.out.println(objTemp.display());
			objTemp=listEmployee.getNext();
		}
	}
	
	// Function to sort the objects in the array based on user input
	public static void sortEmployee(LinkedList<Employee> listEmployee, int sortChoice)
	{
		if (listEmployee.getMaxCount() == 0) {
            System.out.println("\nNo employees to sort.");
            return;
        }
        
        // Use a temporary ArrayList for sorting
        ArrayList<Employee> tempList = new ArrayList<>();
        Employee objTemp = listEmployee.getFirst();
        while (objTemp != null) {
            tempList.add(objTemp);
            objTemp = listEmployee.getNext();
        }
        
        if (sortChoice == 1) { // for sorting name in Ascending
            tempList.sort(Comparator.comparing(Employee::getName));
            System.out.println("\n--- Sorted by Name (Ascending) ---");
            for (Employee emp : tempList) {
            	System.out.println(emp.display());
            }
        } else if (sortChoice == 2) { // for sorting name in Descending
            tempList.sort(Comparator.comparing(Employee::getName).reversed());
            System.out.println("\n--- Sorted by Name (Descending) ---");
            for (Employee emp : tempList) {
            	System.out.println(emp.display());
            }
        } else if (sortChoice == 3) { // for sort by designation
            System.out.println("\n-----SORT-BY-DESIGNATION-MENU-----");
            System.out.println("1. Sort by Manager");
            System.out.println("2. Sort by Engineer");
            System.out.println("3. Sort by Salesman");
            System.out.println("\n----------------------------------");
            System.out.print("Enter your Choice: ");
            int desgChoice = Input.getInteger();
            
            System.out.println("\n--- Sorted by Designation ---");
            for (Employee emp : tempList) {
                if (desgChoice == 1 && emp instanceof Manager) {
                    emp.display();
                } else if (desgChoice == 2 && emp instanceof Engineer) {
                    emp.display();
                } else if (desgChoice == 3 && emp instanceof Salesman) {
                    emp.display();
                }
            }
        } else {
            System.out.println("Invalid Choice");
        }
		
	}
}
