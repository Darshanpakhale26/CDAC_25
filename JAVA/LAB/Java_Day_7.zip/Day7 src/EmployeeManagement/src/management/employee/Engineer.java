package management.employee;

public class Engineer extends Employee
{
	
	protected float overTime;
	
	public Engineer(String name, String address, int age, char gender, float basicSalary, float overTime)
	{
		super(name, address, age, gender, basicSalary);
		this.overTime = overTime;
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + overTime;
	}

	@Override
	public String display()
	{
		StringBuffer display=new StringBuffer();
		display.append(super.display());
		display.append("\nOverTime: ").append(this.overTime);
		display.append("\nTotal Salary: ").append(this.calculateSalary());
		display.append("\n------------------------");
		
		return display.toString();
	}

}