package management.employee;

public class Manager extends Employee
{
	
	protected float hra;
	
	public Manager(String name, String address, int age, char gender, float basicSalary, float hra)
	{
		super(name, address, age, gender, basicSalary);
		this.hra = hra;
		
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + hra;
	}

	@Override
	public String display()
	{
		StringBuffer display=new StringBuffer();
		display.append(super.display());
		display.append("\nHRA: ").append(this.hra);
		display.append("\nTotal Salary: ").append(this.calculateSalary());
		display.append("\n------------------------");
		
		return display.toString();
	}

}
