package org.cdac;

public class Entry {
	public static void main(String[] args) {
		RegularPolygon triangle = new EquilateralTriangle(5);
		RegularPolygon square = new Square(4);

		System.out.println("Triangle perimeter = " + triangle.getPerimeter());
		System.out.println("Triangle interior angle (radians) = " + triangle.getInteriorAngle());

		System.out.println("Square perimeter = " + square.getPerimeter());
		System.out.println("Square interior angle (radians) = " + square.getInteriorAngle());

		RegularPolygon[] shapes = { triangle, square };
		System.out.println("Total sides = " + Entry.totalSides(shapes));
	}

	// calculate total sides of elements
	public static int totalSides(RegularPolygon[] polygons) {
		int total = 0;
		for (RegularPolygon rp : polygons) {
			total += rp.getNumSides();
		}
		return total;
	}
}
