package org.acts;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Original string
        String str = "The quick brown fox jumps";

        // Print original string
        System.out.println("The given string is: " + str);
        
        String reversed = new StringBuilder(str).reverse().toString();
        
        // Print reversed string
        System.out.print("The string in reverse order is:");
        System.out.println(reversed);
        
        

	}

}
