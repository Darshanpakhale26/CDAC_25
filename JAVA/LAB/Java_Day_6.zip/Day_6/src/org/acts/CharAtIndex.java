package org.acts;

public class CharAtIndex {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
    	
        // Original string
        String str = "Java Exercises!";

        // Print original string
        System.out.println("Original String = " + str);

        // Get character at position 0
        char ch1 = str.charAt(0);
        System.out.println("The character at position 0 is " + ch1);

        // Get character at position 10
        char ch2 = str.charAt(10);
        System.out.println("The character at position 10 is " + ch2);
    }
}
