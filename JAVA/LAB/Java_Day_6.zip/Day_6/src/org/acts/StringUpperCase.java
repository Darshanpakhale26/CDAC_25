package org.acts;

public class StringUpperCase {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
    	
        // Original string
        String str = "The Quick BroWn FoX!";

        // Print original string
        System.out.println("Original String: " + str);

        // Convert to uppercase
        String upperStr = str.toUpperCase();

        // Print the uppercase string
        System.out.println("String in uppercase: " + upperStr);
    }
}

