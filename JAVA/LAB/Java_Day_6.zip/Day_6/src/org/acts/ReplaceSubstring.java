package org.acts;

public class ReplaceSubstring {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
    	
        // Original string
        String str = "The quick brown fox jumps over the lazy dog.";

        // Print original string
        System.out.println("Original string: " + str);

        // Replace "fox" with "cat"
        String newStr = str.replaceAll("fox", "cat");

        // Print the new string
        System.out.println("New String: " + newStr);
    }
}

