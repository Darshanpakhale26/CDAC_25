package org.acts;

public class StringEndsWith {
	// TODO Auto-generated method stub
	
    public static void main(String[] args) {
        // Define the strings
        String str1 = "Python Exercises";
        String str2 = "Python Exercise";
        String suffix = "se";

        // Print original strings
        System.out.println("\"" + str1 + "\" ends with \"" + suffix + "\"? " + str1.endsWith(suffix));
        System.out.println("\"" + str2 + "\" ends with \"" + suffix + "\"? " + str2.endsWith(suffix));
    }
}

