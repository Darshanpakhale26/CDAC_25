package org.acts;

public class AlphabetIndex {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "The quick brown fox jumps over the lazy dog.";
		str = str.toLowerCase();

		System.out.println("Sample string of all alphabet: \"" + str + "\"\n");

		// Print first row: a-j
		printIndexes(str, 'a', 'z');

	}

	public static void printIndexes(String str, char start, char end) {
		// Print characters
		for (char ch = start; ch <= end; ch++) {
			System.out.println(ch + "  " + str.indexOf(ch));
		}
	}
}
