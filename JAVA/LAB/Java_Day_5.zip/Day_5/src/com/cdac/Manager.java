package com.cdac;


public class Manager extends Employee {

	protected float hra;

	public Manager(String name, String address, int age, int gender, float basicSalary, float hra) {
		super(name, address, age, gender, basicSalary);
		this.hra = hra;
	}

	@Override
	public float computeSalary() {
		// TODO Auto-generated method stub
		return 0;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

}

