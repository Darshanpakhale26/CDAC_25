package com.cdac;


public class Console {
    public static String getString() {
        try {
            byte [] arrInput = new byte[100];
            int length = System.in.read(arrInput);
            byte [] arrFinal = new byte[length - 2];
            
            System.arraycopy(arrInput, 0, arrFinal, 0, length - 2);
            
            String objString = new String(arrFinal);
            return objString;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static int getInt() {
       
        try {
            return Integer.parseInt(getString());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number input. Please try again.");
            return 0;
        }
    }

    public static float getFloat() {
        try {
            String objString = getString();
            float value = Float.parseFloat(objString);
            return value;
        } catch (NumberFormatException e) {
            System.out.println("Invalid float input. Please try again.");
            return 0.0f; 
        }
    }
    
    
    

}
