package com.cdac;


public abstract class Employee {

	protected String name;
	protected String address;
	protected int age;
	protected int gender;
	protected float basicSalary;

	public Employee(String name, String address, int age, int gender2, float basicSalary) {
		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.gender = gender2;
		this.basicSalary = basicSalary;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int isGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public float getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

	public abstract float computeSalary();

	

}

