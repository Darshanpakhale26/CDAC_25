package com.cdac;


public class Engineer extends Employee {

	protected float overTime;

	public Engineer(String name, String address, int age, int gender, float basicSalary, float overTime) {
		super(name, address, age, gender, basicSalary);
		// TODO Auto-generated constructor stub

		this.overTime = overTime;

	}

	public float getOverTime() {
		return overTime;
	}

	public void setOverTime(float overTime) {
		this.overTime = overTime;
	}

	@Override
	public float computeSalary() {
		// TODO Auto-generated method stub
		return 0;
	}

}

