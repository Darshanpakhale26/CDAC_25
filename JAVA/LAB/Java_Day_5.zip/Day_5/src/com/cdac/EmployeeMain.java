package com.cdac;

public class EmployeeMain {

	private static Employee[] newEmp = new Employee[5];
	private static int count = 0;

	public static void main(String[] args) {

		System.out.println("--- Employee Management System ---");
		int choice;

		do {
			System.out.println("\n1. Add Employee");
			System.out.println("2. Display All");
			System.out.println("3. Save");
			System.out.println("4. Load");
			System.out.println("5. Sort");
			System.out.println("6. Exit");

			System.out.print("Enter your choice: ");
			choice = Console.getInt();

			switch (choice) {
			case 1:
				addEmployee();
				break;

			case 2:
				displayAllEmployees();
				break;

			case 3:
				System.out.println("Save");
				break;

			case 4:
				System.out.println("Load");
				break;

			case 5:
				System.out.println("Sort");
				break;

			case 6:
				System.out.println("Exiting...");
				break;

			default:
				System.err.println("Invalid choice. Please select 1-6.");
			}

		} while (choice != 6);
	}

	private static void displayAllEmployees() {
		// TODO Auto-generated method stub
		
	}

	// Add employee with dynamic array resizing
	private static void addEmployee() {
		int choice1;
		do {
			System.out.println("\n--- Add Employee Sub Menu ---");
			System.out.println("1. Add Manager");
			System.out.println("2. Add Engineer");
			System.out.println("3. Add SalesPerson");
			System.out.println("4. Back to Main Menu");

			System.out.print("Enter employee type choice: ");
			choice1 = Console.getInt();

			if (choice1 >= 1 && choice1 <= 3) {
				// Check if array is full
				if (count == newEmp.length) {
					Employee[] newArray = new Employee[newEmp.length + 5]; // increase size by 5
					System.arraycopy(newEmp, 0, newArray, 0, newEmp.length);
					newEmp = newArray;
					System.out.println("Array size increased!");
				}

				// Add employee
				switch (choice1) {
				case 1:
					newEmp[count++] = createManager();
					break;
				case 2:
					newEmp[count++] = createEngineer();
					break;
				case 3:
					newEmp[count++] = createSalesPerson();
					break;
				}
			} else if (choice1 == 4) {
				System.out.println("Back to main menu.");
			} else {
				System.out.println("Invalid Input. Try again!");
			}

		} while (choice1 != 4);
	}

	// Helper methods to create employees
	private static Manager createManager() {
		System.out.print("Enter name: ");
		String name = Console.getString();
		System.out.print("Enter address: ");
		String address = Console.getString();
		System.out.print("Enter age: ");
		int age = Console.getInt();
		System.out.print("Enter gender (1-Male, 2-Female): ");
		int gender = Console.getInt();
		System.out.print("Enter basic salary: ");
		float basicSalary = Console.getFloat();
		System.out.print("Enter HRA: ");
		float hra = Console.getFloat();
		return new Manager(name, address, age, gender, basicSalary, hra);
	}

	private static Engineer createEngineer() {
		System.out.print("Enter name: ");
		String name = Console.getString();
		System.out.print("Enter address: ");
		String address = Console.getString();
		System.out.print("Enter age: ");
		int age = Console.getInt();
		System.out.print("Enter gender (1-Male, 2-Female): ");
		int gender = Console.getInt();
		System.out.print("Enter basic salary: ");
		float basicSalary = Console.getFloat();
		System.out.print("Enter OverTime: ");
		float overtime = Console.getFloat();
		return new Engineer(name, address, age, gender, basicSalary, overtime);
	}

	private static SalesPerson createSalesPerson() {
		System.out.print("Enter name: ");
		String name = Console.getString();
		System.out.print("Enter address: ");
		String address = Console.getString();
		System.out.print("Enter age: ");
		int age = Console.getInt();
		System.out.print("Enter gender (1-Male, 2-Female): ");
		int gender = Console.getInt();
		System.out.print("Enter basic salary: ");
		float basicSalary = Console.getFloat();
		System.out.print("Enter commission: ");
		float commission = Console.getFloat();
		return new SalesPerson(name, address, age, gender, basicSalary, commission);
	}

	// Display all employees
	private static void displayAllEmployees(Employee[] employees) {
		for (Employee emp : employees) {
			if (emp != null) {
				String name = emp.getName();
				String address = emp.getAddress();
				int age = emp.getAge();
				float basic = emp.getBasicSalary();
				int gender = emp.isGender();
				System.out.println("\nName: " + name);
				System.out.println("Address: " + address);
				System.out.println("Age: " + age);
				System.out.println("Gender: " + gender);
				System.out.println("Basic Salary: " + basic);
				if (emp instanceof Manager) {
					System.out.println("HRA: " + ((Manager) emp).getHra());
				} else if (emp instanceof Engineer) {
					System.out.println("OverTime: " + ((Engineer) emp).getOverTime());
				} else if (emp instanceof SalesPerson) {
					System.out.println("Commission: " + ((SalesPerson) emp).getCommission());
				}
			}
		}
	}
}
