package application.employee;

public class Salesman extends Employee
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2233923971238191198L;
	/**
	 * 
	 */
	
	protected float commission;
	
	public Salesman(String name, String address, int age, char gender, float basicSalary,float commission)
	{
		super(name, address, age, gender, basicSalary);
		this.commission = commission;
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + commission;
	}

	@Override
	public String display()
	{
		StringBuffer display=new StringBuffer();
		display.append(super.display());
		display.append("\nCommission: ").append(this.commission);
		display.append("\nTotal Salary: ").append(this.calculateSalary());
		display.append("\n------------------------");
		
		return display.toString();
	}

}
