package application.employee;

public class Manager extends Employee
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2278322794372195786L;
	/**
	 * 
	 */
	
	protected float hra;
	
	public Manager(String name, String address, int age, char gender, float basicSalary, float hra)
	{
		super(name, address, age, gender, basicSalary);
		this.hra = hra;
		
	}

	@Override
	public float calculateSalary()
	{
		return basicSalary + hra;
	}

	@Override
	public String display()
	{
		StringBuffer display=new StringBuffer();
		display.append(super.display());
		display.append("\nHRA: ").append(this.hra);
		display.append("\nTotal Salary: ").append(this.calculateSalary());
		display.append("\n------------------------");
		
		return display.toString();
	}

}
