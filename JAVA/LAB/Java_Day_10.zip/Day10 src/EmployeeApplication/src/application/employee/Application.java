package application.employee;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import linked.list.LinkedList;

public class Application
{	
	
	public static Employee addEmployee(LinkedList<Employee> listEmployee, int empChoice, Scanner sc) 
	{
		Employee objEmployee=null;
		
		// Taking input for different employees
		System.out.print("Enter Name: ");
		String name = sc.next();
		
		System.out.print("Enter Address: ");
		String address = sc.next();
		
		System.out.print("Enter Age: ");
		int age = sc.nextInt();
		
		// Age Validation
		if (age > 80 || age < 18) 
		{
			System.out.println("\nInvalid Age. Employee not added.");
			return null;
		}
		
		// Gender Validation
		System.out.print("Enter Gender(M/F): ");
		char gender = sc.next().charAt(0);
		
		if( gender != 'M' && gender != 'm' && gender != 'F' && gender != 'f' )
		{
			System.out.println("\nInvalid Gender. Employee not added.");
			return null;
		}
		
		System.out.print("Enter Basic Salary: ");
		float basicSalary = sc.nextFloat();
		
		if(empChoice == 1) //Choice 1 is Manager
		{
			System.out.print("Enter HRA: ");
			float hra = sc.nextFloat();
			objEmployee = new Manager(name,address,age,gender,basicSalary,hra);
			
		}
		
		else if(empChoice == 2) //Choice 2 is Engineer
		{
			System.out.print("Enter OverTime: ");
			float overTime = sc.nextFloat();
			objEmployee = new Engineer(name,address,age,gender,basicSalary,overTime);
		}
		
		else if(empChoice==3) //Choice 3 is Salesman
		{
			System.out.print("Enter Commission: ");
			float commission = sc.nextFloat();
			objEmployee = new Salesman(name,address,age,gender,basicSalary,commission);
		}
		
		System.out.println("\nEmployee added Successfully");
		System.out.println("----------------------------------");
		
		return objEmployee;
	}
	
	public static void displayAll(LinkedList<Employee> listEmployee)
	{
		Employee objTemp=listEmployee.getFirst();
		
		while(objTemp!= null) {
			System.out.println(objTemp.display());
			objTemp=listEmployee.getNext();
		}
	}
	
	public static void sortEmployee(LinkedList<Employee> listEmployee, int sortChoice, Scanner sc) 
	{
		if (listEmployee.getMaxCount() == 0) {
		    System.out.println("\nNo employees to sort.");
		    return;
		}
		
		// Use a temporary ArrayList for sorting
		ArrayList<Employee> tempList = new ArrayList<>();
		Employee objTemp = listEmployee.getFirst();
		while (objTemp != null) {
		    tempList.add(objTemp);
		    objTemp = listEmployee.getNext();
		}
		
		if (sortChoice == 1) { // for sorting name in Ascending
		    tempList.sort(Comparator.comparing(Employee::getName));
		    System.out.println("\n--- Sorted by Name (Ascending) ---");
		    for (Employee emp : tempList) {
		    	System.out.println(emp.display());
		    }
		} else if (sortChoice == 2) { // for sorting name in Descending
		    tempList.sort(Comparator.comparing(Employee::getName).reversed());
		    System.out.println("\n--- Sorted by Name (Descending) ---");
		    for (Employee emp : tempList) {
		    	System.out.println(emp.display());
		    }
		} else if (sortChoice == 3) { // for sort by designation
		    System.out.println("\n-----SORT-BY-DESIGNATION-MENU-----");
		    System.out.println("1. Sort by Manager");
		    System.out.println("2. Sort by Engineer");
		    System.out.println("3. Sort by Salesman");
		    System.out.println("\n----------------------------------");
		    System.out.print("Enter your Choice: ");
		    int desgChoice = sc.nextInt();
		    
		    System.out.println("\n--- Sorted by Designation ---");
		    for (Employee emp : tempList) {
		        if (desgChoice == 1 && emp instanceof Manager) {
		            System.out.println(emp.display()); 
		        } else if (desgChoice == 2 && emp instanceof Engineer) {
		            System.out.println(emp.display()); 
		        } else if (desgChoice == 3 && emp instanceof Salesman) {
		            System.out.println(emp.display()); 
		        }
		    }
		} else {
		    System.out.println("Invalid Choice");
		}
	}

}