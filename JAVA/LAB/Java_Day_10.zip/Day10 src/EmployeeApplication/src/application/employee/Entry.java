package application.employee;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import linked.list.LinkedList;

public class Entry
{

	public static void main(String[] args) 
	{
		
		try (Scanner sc = new Scanner(System.in)) {
			LinkedList<Employee> listEmployee=new LinkedList<>();
			
			int choice = 0;
			
			do {
				System.out.println("\n---------------MENU---------------");
				System.out.println("1. Add Employee");
				System.out.println("2. Display All");
				System.out.println("3. Save");
				System.out.println("4. Load");
				System.out.println("5. Sort");
				System.out.println("6. Exit");
				System.out.println("\n----------------------------------");
				System.out.print("\nEnter your Choice: ");
				
				if(sc.hasNextInt()) {
				    choice = sc.nextInt();
				} else {
				   
				    System.out.println("\nInvalid input. Please enter a number.");
				    sc.next(); 
				    continue; 
				}

				switch(choice)
				{ 
					case 1:
					{
						int empChoice=0;
						do {
							try {
								System.out.println("\n----------EMPLOYEE-MENU-----------");
								System.out.println("1. Add Manager");
								System.out.println("2. Add Engineer");
								System.out.println("3. Add Salesman");
								System.out.println("Press any other number to exit.");
								System.out.println("\n----------------------------------");
								System.out.print("\nEnter your Choice: ");
								
								if(sc.hasNextInt()) {
								    empChoice = sc.nextInt();
								} else {
								    System.out.println("\nInvalid input. Returning to main menu.");
								    sc.next(); 
								    break; 
								}
								
								if(empChoice >= 1 && empChoice <= 3) {
								    
								    Employee newEmployee = Application.addEmployee(listEmployee, empChoice, sc);
								    if (newEmployee != null) {
								        listEmployee.add(newEmployee);
								    }
								}
							} catch (Exception e) {
								
								e.printStackTrace();
							}
						}while(empChoice >= 1 && empChoice <= 3);
						break;
					}
					
					case 2:
					{
						Application.displayAll(listEmployee);
						System.out.println("\n----------------------------------");
						break;
					}
					
					case 3:
					{
						
						try(ObjectOutputStream objStream = new ObjectOutputStream(new FileOutputStream("Employee.txt")))
						{
							objStream.writeObject(listEmployee);
							System.out.println("\nEmployee data saved successfully to Employee.txt");
						} 
						catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						break;
					}
					
					case 4:
					{
						
						try(ObjectInputStream objStream = new ObjectInputStream(new FileInputStream("Employee.txt")))
						{
							
							listEmployee = (LinkedList<Employee>) objStream.readObject();
							System.out.println("\nEmployee data loaded successfully from Employee.txt"+listEmployee);
						} 
						catch (FileNotFoundException e) {
							System.out.println("\nSave file (Employee.txt) not found. Starting with an empty list.");
						} catch (IOException e) {
							System.out.println("\nError reading file: " + e.getMessage());
						} catch (ClassNotFoundException e) {
							System.out.println("\nError: Class not found during deserialization.");
						}
						break;
					}
					
					case 5:
					{
						System.out.println("\n------------SORT-MENU-------------");
						System.out.println("1. Sort by Name in Ascending");
						System.out.println("2. Sort by Name in Descending");
						System.out.println("3. Sort by Designation");
						System.out.println("\n----------------------------------");
						System.out.print("\nEnter your Choice: ");
						
						int sortChoice = 0;
						if(sc.hasNextInt()) {
						    sortChoice = sc.nextInt();
						} else {
						    System.out.println("\nInvalid input. Returning to main menu.");
						    sc.next();
						    break;
						}
						
						if(sortChoice >= 1 && sortChoice <= 3)
							
							Application.sortEmployee(listEmployee, sortChoice, sc); 
						else
							System.out.println("Invalid Choice");
						System.out.println("\n----------------------------------");
						break;
					}
					
					case 6:
					{
						System.out.println("Thank You for Visiting");
						System.out.println("\n----------------------------------");
						break;
					}
					
					default:
					{
						System.out.println("\nInvalid Choice");
						System.out.println("----------------------------------");
						break;
					}
						
				}
			} while(choice != 6);
		} 
		
	}

}
