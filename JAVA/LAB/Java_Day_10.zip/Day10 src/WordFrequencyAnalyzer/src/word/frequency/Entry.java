package word.frequency;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Entry {

	public static void main(String[] args) {
		
		String inputFile = "E:\\CDAC\\Batch 1\\JAVA\\Day10\\WordFrequencyAnalyzer\\Input.txt";
        String outputFile = "E:\\CDAC\\Batch 1\\JAVA\\Day10\\WordFrequencyAnalyzer\\Output.txt";

        // Map to store word counts
        Map<String, Integer> wordCountMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.replaceAll("[^a-zA-Z ]", " ").toLowerCase();
                String[] words = line.split("\\s+");
                
                for (String word : words) {
                    if (!word.isEmpty()) {
                        wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading input file: " + e.getMessage());
            return;
        }

        List<String> alphabeticalList = new ArrayList<>(wordCountMap.keySet());
        Collections.sort(alphabeticalList);

        List<Map.Entry<String, Integer>> frequencyList = new ArrayList<>(wordCountMap.entrySet());
        frequencyList.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            writer.write("Words in Alphabetical Order:\n");
            writer.write("------------------------------\n");
            for (String word : alphabeticalList) {
                writer.write(String.format("%s: %d\n", word, wordCountMap.get(word)));
            }

            writer.write("\nWords by Frequency (Descending):\n");
            writer.write("----------------------------------\n");
            for (Map.Entry<String, Integer> entry : frequencyList) {
                writer.write(String.format("%s: %d\n", entry.getKey(), entry.getValue()));
            }

            System.out.println("Word analysis complete. Output written to: " + outputFile);
        } catch (IOException e) {
            System.err.println("Error writing to output file: " + e.getMessage());
        }

	}

}
