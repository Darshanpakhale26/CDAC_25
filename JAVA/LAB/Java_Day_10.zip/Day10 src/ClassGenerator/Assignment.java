public class Assignment {

    private int data;

    public void getData()
    {
    }

}