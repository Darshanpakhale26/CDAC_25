package generator.Class;

import java.util.ArrayList;
import java.util.List;

public class ClassStructure
{


	 private static class Field
	 {
	     String access;
	     String type;
	     String name;
	
	     public Field(String access, String type, String name)
	     {
	         this.access = access;
	         this.type = type;
	         this.name = name;
	     }
	
	     @Override
	     public String toString()
	     {
	         return String.format("    %s %s %s;", access, type, name);
	     }
	 }
	
	 private static class Method
	 {
	     String access;
	     String returnType;
	     String name;
	     String parameters;
	
	     public Method(String access, String returnType, String name, String parameters)
	     {
	         this.access = access;
	         this.returnType = returnType;
	         this.name = name;
	         this.parameters = parameters;
	     }
	
	     @Override
	     public String toString()
	     {
	        
	         String body = String.format("    {\n    }\n", name);
	         return String.format("    %s %s %s(%s)\n%s", access, returnType, name, parameters, body);
	     }
	 }
	
	
	 private String packageName;
	 private String className;
	 private String classAccess;
	 private List<Field> fields;
	 private List<Method> methods;
	
	 public ClassStructure() {
	     this.fields = new ArrayList<>();
	     this.methods = new ArrayList<>();
	     this.classAccess = "public";
	 }
	
	
	 public void setPackageName(String packageName)
	 {
	     this.packageName = packageName;
	 }
	
	 public void setClassName(String className)
	 {
	     this.className = className;
	 }
	
	 public void setClassAccess(String access)
	 {
	     this.classAccess = access;
	 }
	
	
	 public void addField(String access, String type, String name)
	 {
	     this.fields.add(new Field(access, type, name));
	 }
	
	 public void addMethod(String access, String returnType, String name, String parameters)
	 {
	     this.methods.add(new Method(access, returnType, name, parameters));
	 }
	
	
	 public String generateClassContent()
	 {
	     StringBuilder sb = new StringBuilder();
	
	
	     if (packageName != null && !packageName.trim().isEmpty())
	     {
	         sb.append("package ").append(packageName).append(";\n\n");
	     }
	
	 
	     sb.append(classAccess).append(" class ").append(className);
	     sb.append(" {\n\n");
	
	    
	     if (!fields.isEmpty())
	     {
	         for (Field field : fields)
	         {
	             sb.append(field.toString()).append("\n");
	         }
	         sb.append("\n");
	     }
	     
	     
	     if (!methods.isEmpty())
	     {
	         for (Method method : methods)
	         {
	             sb.append(method.toString()).append("\n");
	         }
	     }
	     
	 
	     sb.append("}");
	
	     return sb.toString();
	 }
	 
	 
	 public String getClassName()
	 {
	     return className;
	 }
}
