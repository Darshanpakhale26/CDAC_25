package generator.Class;

import java.util.Scanner;

public class Entry
{
	 public static void main(String[] args)
	 {
	     
	     try (Scanner mainScanner = new Scanner(System.in))
	     {
	         
	         
	         ClassStructure classData = new ClassStructure();
	         FileGenerator fileGenerator = new FileGenerator();
	         
	         
	         ConsoleMenu menu = new ConsoleMenu(classData, mainScanner, fileGenerator);
	         
	         System.out.println("--- Java Class Code Generator ---");
	
	         
	         menu.setupClass();
	         
	         
	         menu.startMenu();
	         
	     } catch (Exception e) {
	         System.err.println("The application encountered an unexpected error and has terminated.");
	         e.printStackTrace();
	     }
	 }
}
