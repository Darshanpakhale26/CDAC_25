package generator.Class;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileGenerator
{

	 public boolean generateFile(String fileName, String content)
	 {
	     String fullFileName = fileName.trim() + ".java";
	     
	     try (BufferedWriter writer = new BufferedWriter(new FileWriter(fullFileName)))
	     {
	         writer.write(content);
	         return true;
	     } catch (IOException e)
	     {
	         System.err.println("Error writing file " + fullFileName + ": " + e.getMessage());
	         return false;
	     }
	 }
}
