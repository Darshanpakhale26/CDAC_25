package generator.Class;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ConsoleMenu
{

	 private ClassStructure classData;
	 private Scanner scanner;
	 private FileGenerator fileGenerator;
	
	 public ConsoleMenu(ClassStructure classData, Scanner scanner, FileGenerator fileGenerator)
	 {
	     this.classData = classData;
	     this.scanner = scanner;
	     this.fileGenerator = fileGenerator;
	 }
	 
	 
	 private String getAccessSpecifier(String prompt)
	 {
	     String access = "";
	     System.out.println(prompt);
	     System.out.println("a. public");
	     System.out.println("b. private");
	     System.out.println("c. protected");
	     System.out.println("d. default (no keyword)");
	     System.out.print("Enter choice (a/b/c/d): ");
	     String choice = scanner.nextLine().trim().toLowerCase();
	     
	     switch (choice)
	     {
	         case "a": access = "public"; break;
	         case "b": access = "private"; break;
	         case "c": access = "protected"; break;
	         case "d": access = ""; break; // Default access
	         default:
	             System.out.println("Invalid choice. Defaulting to public.");
	             access = "public";
	     }
	     return access;
	 }
	 
	
	
	 public void setupClass()
	 {
	     
	     System.out.print("\nEnter the Package Name (or leave blank for none): ");
	     String pkg = scanner.nextLine().trim();
	     classData.setPackageName(pkg);
	
	     
	     System.out.print("Enter the Class Name: ");
	     String name = scanner.nextLine().trim();
	     classData.setClassName(name);
	
	    
	     System.out.println("\nChoose Class Access Specifier:");
	     System.out.println("a. public");
	     System.out.println("b. default (no keyword)");
	     System.out.print("Enter choice (a/b): ");
	     String accessChoice = scanner.next().trim().toLowerCase();
	     classData.setClassAccess(accessChoice.equals("a") ? "public" : "");
	 }
	 
	
	
	 public void startMenu()
	 {
	     int choice = 0;
	     do {
	         try {
	             System.out.println("\n----------------- BUILDER MENU -----------------");
	             System.out.println("1. Add Field");
	             System.out.println("2. Add Method");
	             System.out.println("3. Generate Class File and Exit");
	             System.out.println("------------------------------------------------");
	             System.out.print("Enter your choice: ");
	             
	             choice = scanner.nextInt();
	             scanner.nextLine(); 
	
	             switch (choice) {
	                 case 1:
	                     addField();
	                     break;
	                 case 2:
	                     addMethod();
	                     break;
	                 case 3:
	                     generateAndExit();
	                     break;
	                 default:
	                     System.out.println("Invalid choice. Please try again.");
	             }
	         } catch (InputMismatchException e) {
	             System.out.println("\nInvalid input. Please enter a number.");
	             scanner.nextLine(); 
	             choice = 0;
	         } catch (Exception e) {
	             System.out.println("\nAn unexpected error occurred: " + e.getMessage());
	         }
	
	     } while (choice != 3);
	 }
	 
	 
	 
	 private void addField()
	 {
	     System.out.println("\n--- ADD FIELD ---");
	     
	    
	     System.out.print("Enter the data type (e.g., int, String, double): ");
	     String type = scanner.nextLine().trim();
	     
	     
	     String access = getAccessSpecifier("Choose Field Access Specifier:");
	
	     
	     System.out.print("Enter the name of the variable: ");
	     String name = scanner.nextLine().trim();
	     
	     classData.addField(access, type, name);
	     System.out.println("Field '" + name + "' added successfully.");
	 }
	
	 private void addMethod()
	 {
	     System.out.println("\n--- ADD METHOD ---");
	
	    
	     System.out.print("Enter the return type (e.g., void, int, String): ");
	     String returnType = scanner.nextLine().trim();
	     
	     
	     String access = getAccessSpecifier("Choose Method Access Specifier:");
	
	     
	     System.out.print("Enter the name of the method: ");
	     String name = scanner.nextLine().trim();
	
	     
	     System.out.print("Enter parameters (e.g., String name, int id) or leave blank: ");
	     String parameters = scanner.nextLine().trim();
	
	     classData.addMethod(access, returnType, name, parameters);
	     System.out.println("Method '" + name + "()' added successfully.");
	 }
	
	 private void generateAndExit()
	 {
	     String content = classData.generateClassContent();
	     String className = classData.getClassName();
	     if (className == null || className.trim().isEmpty()) {
	          System.out.println("\nERROR: Class Name is missing. Cannot generate file.");
	          return;
	     }
	     
	     boolean success = fileGenerator.generateFile(className, content);
	     
	     if (success) {
	         System.out.println("\n------------------------------------------------");
	         System.out.println("SUCCESS: File '" + className + ".java' generated.");
	         System.out.println("------------------------------------------------");
	     } else {
	         System.out.println("\n------------------------------------------------");
	         System.out.println("FAILURE: Could not generate file.");
	         System.out.println("------------------------------------------------");
	     }
	 }
}
