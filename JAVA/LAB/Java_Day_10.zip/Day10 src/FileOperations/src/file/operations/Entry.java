package file.operations;

import java.util.Scanner;

public class Entry {
	static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- File Operations Menu ---");
            System.out.println("1. List all files and directories");
            System.out.println("2. Get specific files by extension");
            System.out.println("3. Check if path exists");
            System.out.println("4. Check if path is file or directory");
            System.out.println("5. Get file size in bytes, KB, MB");
            System.out.println("6. Find the longest word in a text file");
            System.out.println("7. Copy contents of one file to another");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear newline

            switch (choice) {
                case 1: 
                	FileUtils.listFilesAndDirectories(scanner);
                	break;
                case 2: 
                	FileUtils.getFilesByExtension(scanner);
                	break;
                case 3: 
                	FileUtils.checkIfPathExists(scanner);
                	break;
                case 4: 
                	FileUtils.checkIfFileOrDirectory(scanner);
                	break;
                case 5: 
                	FileUtils.getFileSize(scanner);
                	break;
                case 6: 
                	WordUtils.findLongestWord(scanner);
                	break;
                case 7: 
                	CopyUtils.copyFileContents(scanner);
                	break;
                case 0: {
                    System.out.println("Exiting...");
                    return;
                }
                default: System.out.println("Invalid choice!");
            }
        }
    }
}
