package file.operations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class WordUtils {
	public static void findLongestWord(Scanner scanner) {
        System.out.print("Enter text file path: ");
        String path = scanner.nextLine();
        File file = new File(path);
        if (!file.exists() || !file.isFile()) {
            System.out.println("Invalid file path.");
            return;
        }

        String longest = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    word = word.replaceAll("[^a-zA-Z]", "");
                    if (word.length() > longest.length()) {
                        longest = word;
                    }
                }
            }
            System.out.println("Longest word: " + longest);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
