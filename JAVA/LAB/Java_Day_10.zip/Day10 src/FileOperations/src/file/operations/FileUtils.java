package file.operations;

import java.io.File;
import java.util.Scanner;

public class FileUtils {
	 public static void listFilesAndDirectories(Scanner scanner) {
	        System.out.print("Enter directory path: ");
	        String path = scanner.nextLine();
	        File dir = new File(path);
	        if (dir.exists() && dir.isDirectory()) {
	            String[] items = dir.list();
	            if (items != null && items.length > 0) {
	                System.out.println("Contents:");
	                for (String name : items) {
	                    System.out.println(name);
	                }
	            } else {
	                System.out.println("Directory is empty.");
	            }
	        } else {
	            System.out.println("Invalid directory path.");
	        }
	    }

	    public static void getFilesByExtension(Scanner scanner) {
	        System.out.print("Enter directory path: ");
	        String path = scanner.nextLine();
	        System.out.print("Enter file extension (e.g., .txt): ");
	        String ext = scanner.nextLine();

	        File dir = new File(path);
	        if (dir.exists() && dir.isDirectory()) {
	            File[] files = dir.listFiles((d, name) -> name.endsWith(ext));
	            if (files != null && files.length > 0) {
	                System.out.println("Files with extension '" + ext + "':");
	                for (File file : files) {
	                    System.out.println(file.getName());
	                }
	            } else {
	                System.out.println("No files with extension " + ext);
	            }
	        } else {
	            System.out.println("Invalid directory path.");
	        }
	    }

	    public static void checkIfPathExists(Scanner scanner) {
	        System.out.print("Enter file or directory path: ");
	        String path = scanner.nextLine();
	        File file = new File(path);
	        System.out.println(file.exists() ? "The path exists." : "The path does not exist.");
	    }

	    public static void checkIfFileOrDirectory(Scanner scanner) {
	        System.out.print("Enter file or directory path: ");
	        String path = scanner.nextLine();
	        File file = new File(path);
	        if (file.exists()) {
	            if (file.isDirectory()) {
	                System.out.println("It is a directory.");
	            } else if (file.isFile()) {
	                System.out.println("It is a file.");
	            }
	        } else {
	            System.out.println("Path does not exist.");
	        }
	    }

	    public static void getFileSize(Scanner scanner) {
	        System.out.print("Enter file path: ");
	        String path = scanner.nextLine();
	        File file = new File(path);
	        if (file.exists() && file.isFile()) {
	            long bytes = file.length();
	            double kb = bytes / 1024.0;
	            double mb = kb / 1024.0;

	            System.out.printf("Size: %d bytes (%.2f KB, %.2f MB)%n", bytes, kb, mb);
	        } else {
	            System.out.println("Invalid file path.");
	        }
	    }
}
