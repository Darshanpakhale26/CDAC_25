// server.js
import express from 'express';

// Initialize the Express application
const app = express();
const PORT = 3000;

// Middleware to parse URL-encoded bodies (sent by HTML forms)
// This is crucial for accessing form data via req.body
app.use(express.urlencoded({ extended: true }));

// Middleware to serve static files (like the HTML page) from the 'public' directory
app.use(express.static('public'));

// Define the POST route to handle the form submission
app.post('/register', (req, res) => {
    // req.body contains the form data
    const userData = req.body;

    // Log the received data to the server console
    console.log('--- Received Registration Data ---');
    console.log(userData);
    console.log('--------------------------------');

    // Respond back to the client
    res.send('<h1>Got data</h1><p>Data received successfully on the server.</p><a href="/">Go back</a>');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server listening at http://localhost:${PORT}`);
    console.log(`Open http://localhost:${PORT}/form.html in your browser`);
});