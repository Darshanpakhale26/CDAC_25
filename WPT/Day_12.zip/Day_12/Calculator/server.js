const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static(__dirname));

app.post('/calculate', (req, res) => {
    const { operation, num1, num2 } = req.body;

    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Invalid input. Please provide valid numbers.' });
    }

    let result;
    let operationSymbol;

    switch (operation) {
        case 'add':
            result = num1 + num2;
            operationSymbol = '+';
            break;
        case 'subtract':
            result = num1 - num2;
            operationSymbol = '-';
            break;
        case 'multiply':
            result = num1 * num2;
            operationSymbol = '×';
            break;
        case 'divide':
            if (num2 === 0) {
                return res.status(400).json({ error: 'Cannot divide by zero.' });
            }
            result = num1 / num2;
            operationSymbol = '÷';
            break;
        default:
            return res.status(400).json({ error: 'Invalid operation specified.' });
    }

    res.json({
        result: result,
        equation: `${num1} ${operationSymbol} ${num2} = ${result}`
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
    console.log(`Access Addition: http://localhost:${port}/addition.html`);
    console.log(`Access Subtraction: http://localhost:${port}/subtraction.html`);
    console.log(`Access Multiplication: http://localhost:${port}/multiplication.html`);
    console.log(`Access Division: http://localhost:${port}/division.html`);
});