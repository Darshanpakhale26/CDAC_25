import "./App.css";

function App() {
  const yourName = "Darshan";

  return (
    <div className="App">
      <header className="App-header">
        <h1>Hello {yourName}</h1>
      </header>
    </div>
  );
}

export default App;
