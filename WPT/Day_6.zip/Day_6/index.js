document.getElementById('pizzaOrderForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Stop the default form submission
    
    // Clear previous errors
    document.getElementById('nameError').textContent = '';
    document.getElementById('toppingError').textContent = '';
    document.getElementById('instructionError').textContent = '';

    let isValid = true;
    
    // 1. **Validation: Name must be 5 chars**
    const customerName = document.getElementById('customerName').value.trim();
    if (customerName.length < 5) {
        document.getElementById('nameError').textContent = 'Name must be at least 5 characters long.';
        isValid = false;
    }

    // 2. **Validation: Tomato Pizza sauce cannot have Supreme Pizza toppings**
    const pizzaSauce = document.getElementById('pizzaSauce').value;
    const supremeTopping = document.getElementById('toppingSupreme');

    if (pizzaSauce === 'Tomato' && supremeTopping.checked) {
        document.getElementById('toppingError').textContent = 'Supreme Toppings cannot be selected with Tomato Pizza Sauce.';
        isValid = false;
    }
    
    // 3. **Validation: Delivery Instruction must have at least 5 words**
    const instructions = document.getElementById('deliveryInstructions').value.trim();
    // Use a regex to count words (split by whitespace)
    const wordCount = instructions ? instructions.split(/\s+/).length : 0; 
    
    if (wordCount < 5) {
        document.getElementById('instructionError').textContent = 'Delivery Instructions must contain at least 5 words.';
        isValid = false;
    }

    // If all validations pass
    if (isValid) {
        alert('Order Placed Successfully!');
        displayOrderData(customerName, pizzaSauce, instructions);
        this.reset(); // Clear the form
    }
});


/**
 * Function to collect form data and display it in a Bootstrap table.
 */
function displayOrderData(name, sauce, instructions) {
    const tableContainer = document.getElementById('orderTableContainer');
    
    // Get selected size (radio button)
    const selectedSize = document.querySelector('input[name="pizzaSize"]:checked');
    const size = selectedSize ? selectedSize.value : 'N/A';

    // Get selected toppings (checkboxes)
    const selectedToppings = Array.from(document.querySelectorAll('input[name="toppings"]:checked'))
                                  .map(cb => cb.value)
                                  .join(', ');
    
    const tableHTML = `
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Field</th>
                    <th>Value</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Customer Name</td>
                    <td>${name}</td>
                </tr>
                <tr>
                    <td>Pizza Size</td>
                    <td>${size}</td>
                </tr>
                <tr>
                    <td>Pizza Sauce</td>
                    <td>${sauce}</td>
                </tr>
                <tr>
                    <td>Toppings</td>
                    <td>${selectedToppings || 'None'}</td>
                </tr>
                <tr>
                    <td>Delivery Instructions</td>
                    <td>${instructions}</td>
                </tr>
            </tbody>
        </table>
    `;
    
    tableContainer.innerHTML = tableHTML;
}