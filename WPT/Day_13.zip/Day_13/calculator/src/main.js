const express=require('express')
const path=require('path')
const app=express();
const port=3000;

app.use(express.static(path.jsom(_dirname)));
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.post('/add'),(req,res)=>{
    const num1=parseFloat(req.body.num1);
    const num2=parseFloat(req.body.num2);

   
    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Invalid number input for addition.' });
    }

    const ress=num1+num2;
    res.json({
        ress:ress
    });
}

app.post('/sub'),(req,res)=>{
    const num1=parseFloat(req.body.num1);
    const num2=parseFloat(req.body.num2);

   
    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Invalid number input for addition.' });
    }

    const ress=num1-num2;
    res.json({
        ress:ress
    });
}

app.post('/mul'),(req,res)=>{
    const num1=parseFloat(req.body.num1);
    const num2=parseFloat(req.body.num2);

   
    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Invalid number input for addition.' });
    }

    const ress=num*num2;
    res.json({
        ress:ress
    });
}

app.post('/div'),(req,res)=>{
    const num1=parseFloat(req.body.num1);
    const num2=parseFloat(req.body.num2);

   
    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Invalid number input for addition.' });
    }

    const ress=num1/num2;
    res.json({
        ress:ress
    });
}

app.listen(port,()=>{
    console.log(`server running at  http://localhost:${port}`);
    
})