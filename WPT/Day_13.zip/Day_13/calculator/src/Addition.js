
export default function Addition() {

    const cal = function (event) {

        event.preventDefault();
        var num1 = event.target.num1.value;
        var num2 = event.target.num2.value;
        var resultEle=documen.getElementById("res");

        var result = {
            num1: num1,
            num2: num2
        };


        fetch("/add", {
            method: "POST",
            body: JSON.stringify(result),
            headers: {
                "Content-type": "application.json",
            },
        }).then((res) => res.json())
            .then((data) => {
                console.log(data);
            })
            .catch((err) => console.log(err));






        fetch("/sub", {
            method: "POST",
            body: JSON.stringify(result),
            headers: {
                "Content-type": "application.json",
            },
        }).then((res) => res.json())
            .then((data) => {
                console.log(data);
            })
            .catch((err) => console.log(err));




        fetch("/mul", {
            method: "POST",
            body: JSON.stringify(result),
            headers: {
                "Content-type": "application.json",
            },
        }).then((res) => res.json())
            .then((data) => {
                console.log(data);
            })
            .catch((err) => console.log(err));




        fetch("/div", {
            method: "POST",
            body: JSON.stringify(result),
            headers: {
                "Content-type": "application.json",
            },
        }).then((res) => res.json())
            .then((data) => {
                resultEle.textContent = data.result;
            })
            .catch((err) => console.log(err));
    };


    return (
        <div>
            <form onSubmit={cal}>
                Enter Number A : <input type="Number" id="Num1" name="num1" placeholder="Enter Number" /><br>
                </br>
                Enter Number B : <input type="Number" id="Num2" name="num2" placeholder="Enter Number" /><br>
                </br>
                <button type="submit" >Additon
                    <span id="res"></span>
                </button>
                <button type="submit">Substraction</button>
                <button type="submit">Multiplication</button>
                <button type="submit">Division</button>
            </form>

        </div>
    )
}