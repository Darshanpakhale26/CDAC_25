// function print(){
 
//     result (
//         <div>
//             <table borer={1}>
//                 <th>
//                   <td>result</td>
//                 </th>
//                 <tr>
//                     {
//                         <td>{result}</td>
//                     }
//                 </tr>
//             </table>
//         </div>
//     )
// }