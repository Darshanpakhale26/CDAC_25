function B() {
    return (
        <div>
            
            <h2> this is B </h2>

        </div>
    );
}

export default B;