import A from './A'
import B from './B'
import C from './C'
function App() {
  return (
     <div>
      <h2>Hello world</h2>
      <A />
      <B />
      <C />
    </div>
  );
}

export default App;
