function C() {
    return (
        <div>
            <h2> this is C </h2>
        </div>
    );
}

export default C;