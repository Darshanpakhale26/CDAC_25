// import B from './B'
// import C from './C'

function A() {
    return (
        <div>
            <h2> this is A </h2>
            {/* <B />
            <C /> */}

        </div>
    );
}

export default A;