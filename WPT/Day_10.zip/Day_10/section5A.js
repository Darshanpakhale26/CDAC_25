function greet() {
  return new Promise((resolve) => {
    const hour = new Date().getHours();
    let message;

    if (hour >= 5 && hour < 12) {
      message = "Good Morning";
    } else if (hour >= 12 && hour < 17) {
      message = "Good Afternoon";
    } else {
      message = "Good Evening";
    }

    resolve(message);
  });
}

async function main() {
  const greetingMessage = await greet();
  console.log(`The current greeting is: ${greetingMessage}!`);
}

main();
