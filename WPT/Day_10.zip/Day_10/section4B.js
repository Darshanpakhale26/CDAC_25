let arr = [
  [1, 2, 3],
  [3, 4, 5],
  [7, 8, 9]
];

function calculateSum(nestedArray) {
  return new Promise(resolve => {
    setTimeout(() => {
      const sum = nestedArray.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
      resolve(sum);
    }, 0); 
  });
}

const promises = arr.map(nestedArray => {
  return calculateSum(nestedArray);
});

Promise.all(promises)
  .then(results => {
    arr = results;
    console.log("Output Array: arr =", arr);
  })
  .catch(error => {
    console.error("An error occurred:", error);
  });