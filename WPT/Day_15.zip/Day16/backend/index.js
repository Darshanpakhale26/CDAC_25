const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

// Middleware
app.use(cors()); // Allows frontend to make requests
app.use(express.json()); // Allows parsing of JSON request bodies

// --- In-Memory Data Store ---
// In a real application, this would be a MySQL database connection.
let todos = [
    { id: 1, taskName: 'Setup Express server', dueDate: '2025-01-01', status: 'Done' },
    { id: 2, taskName: 'Create React app', dueDate: '2025-01-02', status: 'Rejected' },
    { id: 3, taskName: 'Implement Fetch API', dueDate: '2025-01-05', status: 'Pending' }
];
let nextId = 4;

// --- API Endpoints ---

// 1. Fetch All Todos (GET /api/todos)
app.get('/api/todos', (req, res) => {
    // MySQL Query: SELECT * FROM todos;
    res.json(todos);
});

// 2. Add New Todo (POST /api/todos)
app.post('/api/todos', (req, res) => {
    const { taskName, dueDate } = req.body;
    if (!taskName || !dueDate) {
        return res.status(400).json({ message: 'taskName and dueDate are required' });
    }
    const newTodo = {
        id: nextId++,
        taskName,
        dueDate,
        status: 'Pending' // Default status
    };
    todos.push(newTodo);
    // MySQL Query: INSERT INTO todos (taskName, dueDate, status) VALUES ('taskNameValue', 'dueDateValue', 'Pending');
    res.status(201).json(newTodo);
});

// 3. Delete Todo (DELETE /api/todos/:id)
app.delete('/api/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const initialLength = todos.length;
    todos = todos.filter(todo => todo.id !== id);

    if (todos.length < initialLength) {
        // MySQL Query: DELETE FROM todos WHERE id = idValue;
        res.status(204).send(); // 204 No Content for successful deletion
    } else {
        res.status(404).json({ message: 'Todo not found' });
    }
});

// 4. Update Todo Status (PATCH /api/todos/:id/status) - Optional Requirement
app.patch('/api/todos/:id/status', (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body; // Expects 'Done' or 'Rejected'

    if (!['Done', 'Rejected', 'Pending'].includes(status)) {
        return res.status(400).json({ message: 'Status must be Done, Rejected, or Pending.' });
    }

    const todoIndex = todos.findIndex(todo => todo.id === id);

    if (todoIndex > -1) {
        todos[todoIndex].status = status;
        // MySQL Query: UPDATE todos SET status = 'newValue' WHERE id = idValue;
        res.json(todos[todoIndex]);
    } else {
        res.status(404).json({ message: 'Todo not found' });
    }
});

app.listen(port, () => {
    console.log(`Backend server listening at http://localhost:${port}`);
});