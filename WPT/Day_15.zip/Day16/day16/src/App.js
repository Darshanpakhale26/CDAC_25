import React, { useState, useEffect } from 'react';
import './App.css';

const API_URL = 'http://localhost:5000/api/todos';

function App() {
  const [todos, setTodos] = useState([]);
  const [taskName, setTaskName] = useState('');
  const [dueDate, setDueDate] = useState('');

  // --- 1. Fetch Todos ---
  const fetchTodos = async () => {
    try {
      const response = await fetch(API_URL);
      const data = await response.json();
      setTodos(data);
    } catch (error) {
      console.error('Error fetching todos:', error);
    }
  };

  useEffect(() => {
    fetchTodos();
  }, []);

  // --- 2. Add Todo ---
  const handleAddTodo = async (e) => {
    e.preventDefault();
    if (!taskName || !dueDate) return;

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ taskName, dueDate }),
      });
      const newTodo = await response.json();
      setTodos([...todos, newTodo]);
      setTaskName('');
      setDueDate('');
    } catch (error) {
      console.error('Error adding todo:', error);
    }
  };

  // --- 3. Delete Todo ---
  const handleDeleteTodo = async (id) => {
    try {
      await fetch(`${API_URL}/${id}`, {
        method: 'DELETE',
      });
      setTodos(todos.filter(todo => todo.id !== id));
    } catch (error) {
      console.error('Error deleting todo:', error);
    }
  };

  // --- 4. Update Status (Optional) ---
  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const response = await fetch(`${API_URL}/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });
      const updatedTodo = await response.json();
      
      // Update the state with the modified todo item
      setTodos(todos.map(todo => 
        todo.id === id ? updatedTodo : todo
      ));

    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  return (
    <div className="App">
      <h1>Todo List App</h1>
      
      {/* Add New Todo Form */}
      <form onSubmit={handleAddTodo}>
        <input
          type="text"
          placeholder="Task Name"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
          required
        />
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          required
        />
        <button type="submit">Add Todo</button>
      </form>

      {/* Todo List */}
      <h2>My Todos</h2>
      {todos.length === 0 ? (
        <p>No todos yet! Add one above.</p>
      ) : (
        <ul>
          {todos.map((todo) => (
            <li key={todo.id} className={`status-${todo.status.toLowerCase()}`}>
              <div>
                <strong>{todo.taskName}</strong> 
                <small>(Due: {todo.dueDate})</small>
                <span className="status-badge">Status: {todo.status}</span>
              </div>
              <div>
                {/* Optional Status Update Buttons */}
                <select 
                  value={todo.status}
                  onChange={(e) => handleUpdateStatus(todo.id, e.target.value)}
                >
                  <option value="Pending">Pending</option>
                  <option value="Done">Done</option>
                  <option value="Rejected">Rejected</option>
                </select>
                
                {/* Delete Button */}
                <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;