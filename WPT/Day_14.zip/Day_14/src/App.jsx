import { useState } from 'react';
import './App.css'

function App() {
    const [fruits, setFruits] = useState([])
    const [fruitName, setFruitName] = useState('')
    const handleInputChange = (e) =>{
      setFruitName(e.target.value);
    }
    const handleAddFruit = () => {
      if(fruitName.trim() !== ''){
        setFruits([...fruits,fruitName.trim()])
        setFruitName('');
      }
    };
  
  return (
    <>
    <h3>Fruit List</h3>
      <div className="inputDiv">
        <label htmlFor="fruits">Fruit Name: </label>
        <input type="text" placeholder="Enter fruit name" onChange={handleInputChange}/>
        <br />
        <button onClick={handleAddFruit}>Add to List</button>
      </div>

      {fruits.length > 0 ? (
        <table>
            <thead>
                <tr>
                    <th>Fruit Name</th>
                </tr>
            </thead>
            <tbody>
                {fruits.map((fruit, index) => (
                    <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{fruit}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    ) : (
        <p>No fruits.</p>
    )}
    </>
  )
}

export default App
