function Student(name, email, department, dob, marks) {
  // Properties
  this.name = name;
  this.email = email;
  this.department = department;
  this.dob = dob;
  this.marks = marks;
}

// Method added to the prototype for efficiency
Student.prototype.calculateTotalMarks = function () {
  let totalMarks = 0;

  // Check if the marks array exists and is an array
  if (Array.isArray(this.marks)) {
    // Use the reduce method to sum up the 'mark' property of each object
    totalMarks = this.marks.reduce((accumulator, currentMark) => {
      // Ensure the 'mark' is a valid number before adding
      const markValue =
        typeof currentMark.mark === "number" ? currentMark.mark : 0;
      return accumulator + markValue;
    }, 0); // Start the accumulator at 0
  }

  return totalMarks;
};

// --- Hard Coded Data and Usage ---
const studentMarks = [
  { subject: "Mathematics", mark: 95 },
  { subject: "Physics", mark: 88 },
  { subject: "Chemistry", mark: 92 },
  { subject: "Computer Science", mark: 98 },
];

// 1. Create a Student object (instantiate the constructor)
const student1 = new Student(
  "Darshan Pakhale",
  "darshan.pakhale@cdac.in",
  "Engineering",
  "2025-11-15",
  studentMarks
);

// 2. Display the created object and calculated marks
console.log("--- Student Object Details ---");
console.log(student1);

console.log("\n--- Calculated Data ---");
const totalMarks = student1.calculateTotalMarks();
console.log(`${student1.name}'s Total Marks: ${totalMarks}`);
